<?php
/**
 * PluginProjectreportsReport
 *
 * Backend de dados para o dashboard de projetos.
 * Tabelas utilizadas (GLPI 11):
 *   glpi_projects              — projetos
 *   glpi_projectstates         — estados personalizados de projeto
 *   glpi_projecttypes          — tipos de projeto
 *   glpi_projectteams          — equipe do projeto (users/groups)
 *   glpi_projecttasks          — tarefas
 *   glpi_projecttaskteams      — equipe da tarefa
 *   glpi_projecttasktypes      — tipos de tarefa
 *   glpi_projecttasklinks      — dependências entre tarefas
 *   glpi_projecttasks_tickets  — tickets vinculados a tarefas
 *   glpi_projectcosts          — custos do projeto
 */
class PluginProjectreportsReport
{
    // -----------------------------------------------------------------------
    // Mapeamentos estáticos
    // -----------------------------------------------------------------------

    /** global_state do glpi_projects (campo nativo GLPI) */
    private const STATE_LABELS = [
        0 => 'Novo',
        1 => 'Em Andamento',
        2 => 'Pendente',
        3 => 'Concluído',
        4 => 'Cancelado',
    ];

    private const STATE_COLORS = [
        0 => '#6c757d',
        1 => '#0d6efd',
        2 => '#ffc107',
        3 => '#198754',
        4 => '#dc3545',
    ];

    /** priority do glpi_projects */
    private const PRIORITY_LABELS = [
        1 => 'Muito Baixa',
        2 => 'Baixa',
        3 => 'Média',
        4 => 'Alta',
        5 => 'Muito Alta',
        6 => 'Crítica',
    ];

    // -----------------------------------------------------------------------
    // KPIs
    // -----------------------------------------------------------------------

    public static function getKPIs(): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'entities_id', '', true);

        $base = $er + ['is_deleted' => 0];

        $total       = (int) countElementsInTable('glpi_projects', $base);
        $in_progress = (int) countElementsInTable('glpi_projects', $base + ['global_state' => 1]);
        $new         = (int) countElementsInTable('glpi_projects', $base + ['global_state' => 0]);
        $done        = (int) countElementsInTable('glpi_projects', $base + ['global_state' => 3]);
        $cancelled   = (int) countElementsInTable('glpi_projects', $base + ['global_state' => 4]);
        $pending     = (int) countElementsInTable('glpi_projects', $base + ['global_state' => 2]);

        // Vencidos: planned_end_date < hoje, não concluídos nem cancelados
        $today = date('Y-m-d');
        $overdue = 0;
        $it = $DB->request([
            'COUNT' => 'id',
            'FROM'  => 'glpi_projects',
            'WHERE' => $base + [
                ['global_state'     => ['<>', 3]],
                ['global_state'     => ['<>', 4]],
                ['planned_end_date' => ['<',  $today]],
                ['planned_end_date' => ['<>', null]],
            ],
        ]);
        foreach ($it as $r) { $overdue = (int)($r['COUNT'] ?? 0); }

        // Média de progresso (projetos ativos)
        $avg_progress = 0.0;
        $it2 = $DB->request([
            'SELECT' => [new QueryExpression('COALESCE(AVG(percent_done),0) AS avg')],
            'FROM'   => 'glpi_projects',
            'WHERE'  => $base + [['global_state' => ['<>', 4]]],
        ]);
        foreach ($it2 as $r) { $avg_progress = round((float)$r['avg'], 1); }

        // Total de tarefas e tarefas concluídas
        $er_tasks = getEntitiesRestrictCriteria('glpi_projecttasks', 'entities_id', '', true);
        $total_tasks = (int) countElementsInTable('glpi_projecttasks', $er_tasks + ['is_deleted' => 0]);
        $done_tasks  = (int) countElementsInTable('glpi_projecttasks', $er_tasks + ['is_deleted' => 0, 'percent_done' => 100]);

        // Custo total (glpi_projectcosts)
        $total_cost = 0.0;
        $it3 = $DB->request([
            'SELECT' => [new QueryExpression('COALESCE(SUM(cost),0) AS total')],
            'FROM'   => 'glpi_projectcosts',
        ]);
        foreach ($it3 as $r) { $total_cost = round((float)$r['total'], 2); }

        return [
            'total'           => $total,
            'in_progress'     => $in_progress,
            'new'             => $new,
            'done'            => $done,
            'cancelled'       => $cancelled,
            'pending'         => $pending,
            'overdue'         => $overdue,
            'completion_rate' => $total > 0 ? round(($done / $total) * 100, 1) : 0,
            'avg_progress'    => $avg_progress,
            'total_tasks'     => $total_tasks,
            'done_tasks'      => $done_tasks,
            'total_cost'      => $total_cost,
        ];
    }

    // -----------------------------------------------------------------------
    // Projetos — lista completa
    // -----------------------------------------------------------------------

    public static function getProjectsList(int $limit = 100): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'p.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                'p.id',
                'p.name',
                'p.content',
                'p.global_state',
                'p.percent_done',
                'p.priority',
                'p.planned_start_date',
                'p.planned_end_date',
                'p.real_end_date',
                'p.date',
                // gerente
                'u.name      AS manager_name',
                'u.firstname AS manager_firstname',
                // tipo de projeto
                'pt.name AS type_name',
                // estado personalizado
                'ps.name  AS state_name',
                'ps.color AS state_color_custom',
                // contagem de tarefas via subquery
                new QueryExpression(
                    '(SELECT COUNT(t.id) FROM glpi_projecttasks t
                      WHERE t.projects_id = p.id AND t.is_deleted = 0) AS task_total'
                ),
                new QueryExpression(
                    '(SELECT COUNT(t2.id) FROM glpi_projecttasks t2
                      WHERE t2.projects_id = p.id AND t2.is_deleted = 0
                      AND t2.percent_done = 100) AS task_done'
                ),
                // custo total via subquery
                new QueryExpression(
                    '(SELECT COALESCE(SUM(pc.cost),0) FROM glpi_projectcosts pc
                      WHERE pc.projects_id = p.id) AS total_cost'
                ),
                // tickets vinculados via tarefas
                new QueryExpression(
                    '(SELECT COUNT(DISTINCT ptt.tickets_id) FROM glpi_projecttasks_tickets ptt
                      INNER JOIN glpi_projecttasks tk ON tk.id = ptt.projecttasks_id
                      WHERE tk.projects_id = p.id AND tk.is_deleted = 0) AS linked_tickets'
                ),
            ],
            'FROM'      => 'glpi_projects AS p',
            'LEFT JOIN' => [
                'glpi_users AS u'         => ['FKEY' => ['p' => 'users_id',         'u'  => 'id']],
                'glpi_projecttypes AS pt' => ['FKEY' => ['p' => 'projecttypes_id',  'pt' => 'id']],
                'glpi_projectstates AS ps'=> ['FKEY' => ['p' => 'projectstates_id', 'ps' => 'id']],
            ],
            'WHERE' => $er + ['p.is_deleted' => 0],
            'ORDER' => ['p.planned_end_date ASC', 'p.priority DESC'],
            'LIMIT' => $limit,
        ]);

        $today    = new \DateTime('today');
        $projects = [];

        foreach ($iter as $row) {
            $state      = (int)$row['global_state'];
            $end_date   = $row['planned_end_date'] ?? null;
            $is_overdue = false;

            if ($end_date) {
                $is_overdue = (new \DateTime($end_date)) < $today
                    && !in_array($state, [3, 4], true);
            }

            // Cor: usa cor do estado personalizado se existir, caso contrário usa mapa interno
            $color = !empty($row['state_color_custom'])
                ? $row['state_color_custom']
                : (self::STATE_COLORS[$state] ?? '#6c757d');

            $task_total = (int)($row['task_total'] ?? 0);
            $task_done  = (int)($row['task_done']  ?? 0);

            $projects[] = [
                'id'            => (int)$row['id'],
                'name'          => $row['name'],
                'description'   => strip_tags($row['content'] ?? ''),
                'state'         => $state,
                'state_label'   => $row['state_name'] ?: (self::STATE_LABELS[$state] ?? 'Desconhecido'),
                'state_color'   => $color,
                'percent_done'  => (int)$row['percent_done'],
                'priority'      => (int)$row['priority'],
                'priority_label'=> self::PRIORITY_LABELS[(int)$row['priority']] ?? '',
                'start_date'    => $row['planned_start_date'],
                'end_date'      => $end_date,
                'real_end_date' => $row['real_end_date'],
                'created_at'    => $row['date'],
                'manager'       => trim(($row['manager_firstname'] ?? '') . ' ' . ($row['manager_name'] ?? '')) ?: 'Sem gerente',
                'type'          => $row['type_name'] ?? 'Sem tipo',
                'task_total'    => $task_total,
                'task_done'     => $task_done,
                'task_rate'     => $task_total > 0 ? round(($task_done / $task_total) * 100) : 0,
                'total_cost'    => (float)($row['total_cost'] ?? 0),
                'linked_tickets'=> (int)($row['linked_tickets'] ?? 0),
                'is_overdue'    => $is_overdue,
            ];
        }

        return $projects;
    }

    // -----------------------------------------------------------------------
    // Tarefas
    // -----------------------------------------------------------------------

    public static function getTasksList(int $limit = 200): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projecttasks', 'pt.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                'pt.id',
                'pt.name',
                'pt.content',
                'pt.state',
                'pt.percent_done',
                'pt.plan_start_date',
                'pt.plan_end_date',
                'pt.real_start_date',
                'pt.real_end_date',
                'pt.planned_duration',
                'pt.effective_duration',
                'pt.projects_id',
                // projeto pai
                'p.name AS project_name',
                // tipo de tarefa
                'ptt.name AS task_type',
                // responsável (primeiro user da equipe)
                new QueryExpression(
                    '(SELECT u.firstname FROM glpi_projecttaskteams tm
                      INNER JOIN glpi_users u ON u.id = tm.items_id
                      WHERE tm.projecttasks_id = pt.id AND tm.itemtype = \'User\'
                      LIMIT 1) AS user_firstname'
                ),
                new QueryExpression(
                    '(SELECT u.name FROM glpi_projecttaskteams tm
                      INNER JOIN glpi_users u ON u.id = tm.items_id
                      WHERE tm.projecttasks_id = pt.id AND tm.itemtype = \'User\'
                      LIMIT 1) AS user_name'
                ),
                // tickets vinculados
                new QueryExpression(
                    '(SELECT COUNT(ptt2.tickets_id) FROM glpi_projecttasks_tickets ptt2
                      WHERE ptt2.projecttasks_id = pt.id) AS linked_tickets'
                ),
            ],
            'FROM'      => 'glpi_projecttasks AS pt',
            'INNER JOIN'=> [
                'glpi_projects AS p' => ['FKEY' => ['pt' => 'projects_id', 'p' => 'id']],
            ],
            'LEFT JOIN' => [
                'glpi_projecttasktypes AS ptt' => ['FKEY' => ['pt' => 'projecttasktypes_id', 'ptt' => 'id']],
            ],
            'WHERE' => $er + ['pt.is_deleted' => 0, 'p.is_deleted' => 0],
            'ORDER' => ['pt.plan_end_date ASC'],
            'LIMIT' => $limit,
        ]);

        $today = new \DateTime('today');
        $tasks = [];

        foreach ($iter as $row) {
            $state = (int)$row['state'];
            $end   = $row['plan_end_date'] ?? null;
            $is_overdue = $end
                && (new \DateTime($end)) < $today
                && !in_array($state, [3, 4], true);

            // duração planejada em horas
            $planned_h   = $row['planned_duration']  ? round($row['planned_duration']  / 3600, 1) : null;
            $effective_h = $row['effective_duration'] ? round($row['effective_duration'] / 3600, 1) : null;

            $tasks[] = [
                'id'              => (int)$row['id'],
                'name'            => $row['name'],
                'project_id'      => (int)$row['projects_id'],
                'project_name'    => $row['project_name'],
                'state'           => $state,
                'state_label'     => self::STATE_LABELS[$state] ?? 'Desconhecido',
                'state_color'     => self::STATE_COLORS[$state] ?? '#6c757d',
                'percent_done'    => (int)$row['percent_done'],
                'task_type'       => $row['task_type'] ?? 'Sem tipo',
                'start_date'      => $row['plan_start_date'],
                'end_date'        => $end,
                'real_start_date' => $row['real_start_date'],
                'real_end_date'   => $row['real_end_date'],
                'planned_hours'   => $planned_h,
                'effective_hours' => $effective_h,
                'user'            => trim(($row['user_firstname'] ?? '') . ' ' . ($row['user_name'] ?? '')) ?: 'Não atribuído',
                'linked_tickets'  => (int)($row['linked_tickets'] ?? 0),
                'is_overdue'      => $is_overdue,
            ];
        }

        return $tasks;
    }

    // -----------------------------------------------------------------------
    // Gráfico: projetos criados vs concluídos por mês (6 meses)
    // -----------------------------------------------------------------------

    public static function getProjectsByMonth(): array
    {
        $er = getEntitiesRestrictCriteria('glpi_projects', 'entities_id', '', true);
        $result = [];

        for ($i = 5; $i >= 0; $i--) {
            $dt    = new \DateTime("first day of -$i month");
            $start = $dt->format('Y-m-01 00:00:00');
            $end   = $dt->format('Y-m-t 23:59:59');

            $created = (int) countElementsInTable('glpi_projects', $er + [
                'is_deleted' => 0,
                ['date'      => ['>=', $start]],
                ['date'      => ['<=', $end]],
            ]);

            $closed = (int) countElementsInTable('glpi_projects', $er + [
                'is_deleted'   => 0,
                'global_state' => 3,
                ['date_mod'    => ['>=', $start]],
                ['date_mod'    => ['<=', $end]],
            ]);

            $result[] = [
                'month'   => $dt->format('M/y'),
                'created' => $created,
                'closed'  => $closed,
            ];
        }

        return $result;
    }

    // -----------------------------------------------------------------------
    // Gráfico: distribuição por estado (donut)
    // -----------------------------------------------------------------------

    public static function getProjectsByState(): array
    {
        $er = getEntitiesRestrictCriteria('glpi_projects', 'entities_id', '', true);
        $result = [];

        foreach (self::STATE_LABELS as $state_id => $label) {
            $count = (int) countElementsInTable('glpi_projects', $er + [
                'is_deleted'   => 0,
                'global_state' => $state_id,
            ]);
            $result[] = [
                'label' => $label,
                'count' => $count,
                'color' => self::STATE_COLORS[$state_id],
            ];
        }

        return $result;
    }

    // -----------------------------------------------------------------------
    // Gráfico: distribuição por tipo (glpi_projecttypes)
    // -----------------------------------------------------------------------

    public static function getProjectsByType(): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'p.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                new QueryExpression('COALESCE(pt.name, \'Sem tipo\') AS type_name'),
                new QueryExpression('COUNT(p.id) AS total'),
            ],
            'FROM'      => 'glpi_projects AS p',
            'LEFT JOIN' => [
                'glpi_projecttypes AS pt' => ['FKEY' => ['p' => 'projecttypes_id', 'pt' => 'id']],
            ],
            'WHERE'   => $er + ['p.is_deleted' => 0],
            'GROUPBY' => ['pt.name'],
            'ORDER'   => ['total DESC'],
        ]);

        $result = [];
        $palette = ['#0d6efd','#198754','#ffc107','#dc3545','#6f42c1','#0dcaf0','#fd7e14','#6c757d'];
        $i = 0;
        foreach ($iter as $row) {
            $result[] = [
                'label' => $row['type_name'],
                'count' => (int)$row['total'],
                'color' => $palette[$i % count($palette)],
            ];
            $i++;
        }

        return $result;
    }

    // -----------------------------------------------------------------------
    // Ranking de gerentes de projeto
    // -----------------------------------------------------------------------

    public static function getManagerRanking(): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'p.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                'u.id',
                'u.name',
                'u.firstname',
                new QueryExpression('COUNT(p.id) AS total'),
                new QueryExpression('SUM(CASE WHEN p.global_state = 3 THEN 1 ELSE 0 END) AS done'),
                new QueryExpression('COALESCE(AVG(p.percent_done), 0) AS avg_progress'),
            ],
            'FROM'       => 'glpi_projects AS p',
            'INNER JOIN' => [
                'glpi_users AS u' => ['FKEY' => ['p' => 'users_id', 'u' => 'id']],
            ],
            'WHERE'   => $er + ['p.is_deleted' => 0],
            'GROUPBY' => ['u.id'],
            'ORDER'   => ['done DESC', 'avg_progress DESC'],
            'LIMIT'   => 10,
        ]);

        $medal_colors = ['#FFD700','#C0C0C0','#CD7F32'];
        $def_colors   = ['#0d6efd','#198754','#6f42c1','#fd7e14','#20c997','#0dcaf0','#6c757d'];

        $ranking = [];
        $pos = 0;
        foreach ($iter as $row) {
            $total = (int)$row['total'];
            $done  = (int)$row['done'];
            $color = $pos < 3 ? $medal_colors[$pos] : $def_colors[($pos - 3) % count($def_colors)];

            $ranking[] = [
                'position'    => $pos + 1,
                'name'        => trim($row['firstname'] . ' ' . $row['name']),
                'total'       => $total,
                'done'        => $done,
                'avg_progress'=> round((float)$row['avg_progress'], 1),
                'rate'        => $total > 0 ? round(($done / $total) * 100) : 0,
                'points'      => ($done * 10) + (int)round((float)$row['avg_progress']),
                'color'       => $color,
            ];
            $pos++;
        }

        return $ranking;
    }

    // -----------------------------------------------------------------------
    // Custos por projeto (glpi_projectcosts)
    // -----------------------------------------------------------------------

    public static function getProjectCosts(): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'p.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                'p.id',
                'p.name',
                new QueryExpression('COALESCE(SUM(pc.cost), 0) AS total_cost'),
                new QueryExpression('COUNT(pc.id) AS cost_entries'),
            ],
            'FROM'       => 'glpi_projects AS p',
            'LEFT JOIN'  => [
                'glpi_projectcosts AS pc' => ['FKEY' => ['p' => 'id', 'pc' => 'projects_id']],
            ],
            'WHERE'   => $er + ['p.is_deleted' => 0],
            'GROUPBY' => ['p.id'],
            'HAVING'  => [new QueryExpression('total_cost > 0')],
            'ORDER'   => ['total_cost DESC'],
            'LIMIT'   => 15,
        ]);

        $result = [];
        foreach ($iter as $row) {
            $result[] = [
                'project_id'   => (int)$row['id'],
                'project_name' => $row['name'],
                'total_cost'   => round((float)$row['total_cost'], 2),
                'cost_entries' => (int)$row['cost_entries'],
            ];
        }

        return $result;
    }

    // -----------------------------------------------------------------------
    // Projetos com prazo próximo (30 dias)
    // -----------------------------------------------------------------------

    public static function getUpcomingDeadlines(): array
    {
        global $DB;

        $er    = getEntitiesRestrictCriteria('glpi_projects', 'entities_id', '', true);
        $today = date('Y-m-d');
        $in30  = date('Y-m-d', strtotime('+30 days'));

        $iter = $DB->request([
            'SELECT' => ['id','name','percent_done','global_state','planned_end_date'],
            'FROM'   => 'glpi_projects',
            'WHERE'  => $er + [
                'is_deleted'          => 0,
                ['global_state'       => ['<>', 3]],
                ['global_state'       => ['<>', 4]],
                ['planned_end_date'   => ['>=', $today]],
                ['planned_end_date'   => ['<=', $in30]],
            ],
            'ORDER' => ['planned_end_date ASC'],
            'LIMIT' => 10,
        ]);

        $result = [];
        foreach ($iter as $row) {
            $end_dt     = new \DateTime($row['planned_end_date']);
            $today_dt   = new \DateTime('today');
            $diff_days  = (int)$today_dt->diff($end_dt)->days;

            $result[] = [
                'id'           => (int)$row['id'],
                'name'         => $row['name'],
                'percent_done' => (int)$row['percent_done'],
                'state_label'  => self::STATE_LABELS[(int)$row['global_state']] ?? '',
                'end_date'     => $row['planned_end_date'],
                'days_left'    => $diff_days,
                'urgency'      => $diff_days <= 7 ? 'critical' : ($diff_days <= 15 ? 'warning' : 'ok'),
            ];
        }

        return $result;
    }

    // -----------------------------------------------------------------------
    // Tickets vinculados a tarefas (glpi_projecttasks_tickets)
    // -----------------------------------------------------------------------

    public static function getLinkedTickets(): array
    {
        global $DB;

        $er = getEntitiesRestrictCriteria('glpi_projects', 'p.entities_id', '', true);

        $iter = $DB->request([
            'SELECT' => [
                'p.id   AS project_id',
                'p.name AS project_name',
                'pt.id  AS task_id',
                'pt.name AS task_name',
                'ptt.tickets_id',
                't.name AS ticket_name',
                't.status AS ticket_status',
            ],
            'FROM'       => 'glpi_projecttasks_tickets AS ptt',
            'INNER JOIN' => [
                'glpi_projecttasks AS pt' => ['FKEY' => ['ptt' => 'projecttasks_id', 'pt' => 'id']],
                'glpi_projects AS p'      => ['FKEY' => ['pt'  => 'projects_id',     'p'  => 'id']],
                'glpi_tickets AS t'       => ['FKEY' => ['ptt' => 'tickets_id',       't'  => 'id']],
            ],
            'WHERE' => $er + ['pt.is_deleted' => 0, 'p.is_deleted' => 0],
            'ORDER' => ['p.name ASC', 'pt.name ASC'],
            'LIMIT' => 200,
        ]);

        $result = [];
        foreach ($iter as $row) {
            $result[] = [
                'project_id'    => (int)$row['project_id'],
                'project_name'  => $row['project_name'],
                'task_id'       => (int)$row['task_id'],
                'task_name'     => $row['task_name'],
                'ticket_id'     => (int)$row['tickets_id'],
                'ticket_name'   => $row['ticket_name'],
                'ticket_status' => (int)$row['ticket_status'],
            ];
        }

        return $result;
    }
}
