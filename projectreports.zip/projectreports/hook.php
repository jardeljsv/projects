<?php
/**
 * Plugin ProjectReports — Hooks de instalação e menu
 */

function plugin_projectreports_install(): bool   { return true; }
function plugin_projectreports_uninstall(): bool { return true; }

/**
 * Injeta "Relatório de Projetos" no menu Ferramentas do GLPI
 */
function plugin_projectreports_redefine_menus(array $menus): array
{
    if (!Session::getLoginUserID()) {
        return $menus;
    }

    $url = Plugin::getWebDir('projectreports', false) . '/front/report.php';

    $menus['tools']['content']['projectreports'] = [
        'title' => 'Relatório de Projetos',
        'page'  => $url,
        'icon'  => 'ti ti-chart-gantt',
    ];

    return $menus;
}
