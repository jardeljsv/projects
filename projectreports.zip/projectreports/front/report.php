<?php
/**
 * Plugin ProjectReports — Página principal (standalone)
 *
 * Renderiza HTML completo independente do layout do GLPI.
 * Autenticação garantida por Session::checkLoginUser().
 */

include('../../../inc/includes.php');
Session::checkLoginUser();

$plugin_web_dir = Plugin::getWebDir('projectreports', false);
$ajax_url       = $plugin_web_dir . '/ajax/report.php';
$css_url        = $plugin_web_dir . '/public/css/style.css';
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Projetos — GLPI</title>

    <!-- Bootstrap 5 + FontAwesome (via CDN local fallback) -->
    <link rel="stylesheet" href="<?= $plugin_web_dir ?>/public/vendor/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $plugin_web_dir ?>/public/vendor/css/fontawesome.min.css">

    <!-- Estilos do plugin -->
    <link rel="stylesheet" href="<?= $css_url ?>">
</head>
<body class="dark-mode">

<!-- ======================================================
     HEADER
====================================================== -->
<header class="pr-header d-flex align-items-center justify-content-between px-4 py-2">
    <div class="d-flex align-items-center gap-3">
        <i class="fa fa-chart-gantt fa-lg text-primary"></i>
        <span class="fw-bold fs-5">Relatório de Projetos</span>
        <span class="badge bg-secondary ms-2" id="last-update">—</span>
    </div>
    <div class="d-flex align-items-center gap-3">
        <!-- Abas de navegação -->
        <nav class="pr-nav" id="main-nav">
            <button class="pr-nav-btn active" data-section="overview">
                <i class="fa fa-gauge-high"></i> Visão Geral
            </button>
            <button class="pr-nav-btn" data-section="projects">
                <i class="fa fa-folder-open"></i> Projetos
            </button>
            <button class="pr-nav-btn" data-section="tasks">
                <i class="fa fa-list-check"></i> Tarefas
            </button>
            <button class="pr-nav-btn" data-section="costs">
                <i class="fa fa-dollar-sign"></i> Custos
            </button>
            <button class="pr-nav-btn" data-section="team">
                <i class="fa fa-users"></i> Equipe
            </button>
        </nav>

        <!-- Controles -->
        <button class="btn btn-sm btn-outline-secondary" id="btn-refresh" title="Atualizar dados">
            <i class="fa fa-rotate-right"></i>
        </button>
        <button class="btn btn-sm btn-outline-secondary" id="btn-theme" title="Alternar tema">
            <i class="fa fa-moon"></i>
        </button>
        <div id="clock" class="text-muted small"></div>
    </div>
</header>

<!-- ======================================================
     SEÇÃO: VISÃO GERAL
====================================================== -->
<section class="pr-section active" id="section-overview">
    <div class="container-fluid px-4 pt-3">

        <!-- KPI Cards -->
        <div class="row g-3 mb-4" id="kpi-cards">
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-primary"><i class="fa fa-folder"></i></div>
                    <div class="kpi-value" id="kpi-total">—</div>
                    <div class="kpi-label">Total de Projetos</div>
                </div>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-info"><i class="fa fa-spinner"></i></div>
                    <div class="kpi-value text-info" id="kpi-in-progress">—</div>
                    <div class="kpi-label">Em Andamento</div>
                </div>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-success"><i class="fa fa-circle-check"></i></div>
                    <div class="kpi-value text-success" id="kpi-done">—</div>
                    <div class="kpi-label">Concluídos</div>
                </div>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-danger"><i class="fa fa-triangle-exclamation"></i></div>
                    <div class="kpi-value text-danger" id="kpi-overdue">—</div>
                    <div class="kpi-label">Vencidos</div>
                </div>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-warning"><i class="fa fa-percent"></i></div>
                    <div class="kpi-value text-warning" id="kpi-completion">—</div>
                    <div class="kpi-label">Taxa Conclusão</div>
                </div>
            </div>
            <div class="col-6 col-md-3 col-xl-2">
                <div class="pr-card kpi-card">
                    <div class="kpi-icon text-purple"><i class="fa fa-list-check"></i></div>
                    <div class="kpi-value" id="kpi-tasks">—</div>
                    <div class="kpi-label">Tarefas Concluídas</div>
                </div>
            </div>
        </div>

        <!-- Gráficos -->
        <div class="row g-3 mb-4">
            <!-- Linha: criados vs concluídos -->
            <div class="col-12 col-xl-6">
                <div class="pr-card h-100">
                    <div class="pr-card-title">
                        <i class="fa fa-chart-line text-primary me-2"></i>
                        Projetos por Mês (últimos 6 meses)
                    </div>
                    <canvas id="chart-monthly" height="200"></canvas>
                </div>
            </div>
            <!-- Donut: por estado -->
            <div class="col-12 col-md-6 col-xl-3">
                <div class="pr-card h-100">
                    <div class="pr-card-title">
                        <i class="fa fa-chart-pie text-info me-2"></i>
                        Por Estado
                    </div>
                    <canvas id="chart-state" height="200"></canvas>
                </div>
            </div>
            <!-- Donut: por tipo -->
            <div class="col-12 col-md-6 col-xl-3">
                <div class="pr-card h-100">
                    <div class="pr-card-title">
                        <i class="fa fa-tags text-warning me-2"></i>
                        Por Tipo
                    </div>
                    <canvas id="chart-type" height="200"></canvas>
                </div>
            </div>
        </div>

        <!-- Prazos próximos -->
        <div class="row g-3">
            <div class="col-12">
                <div class="pr-card">
                    <div class="pr-card-title">
                        <i class="fa fa-calendar-days text-warning me-2"></i>
                        Prazos nos Próximos 30 Dias
                    </div>
                    <div id="upcoming-deadlines-list">
                        <div class="text-muted text-center py-3"><i class="fa fa-spinner fa-spin"></i> Carregando...</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- ======================================================
     SEÇÃO: PROJETOS
====================================================== -->
<section class="pr-section" id="section-projects">
    <div class="container-fluid px-4 pt-3">
        <div class="pr-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="pr-card-title mb-0">
                    <i class="fa fa-folder-open text-primary me-2"></i>
                    Todos os Projetos
                </div>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control form-control-sm search-input"
                           id="search-projects" placeholder="🔍 Filtrar projetos...">
                    <select class="form-select form-select-sm" id="filter-state" style="width:auto">
                        <option value="">Todos os estados</option>
                        <option value="0">Novo</option>
                        <option value="1">Em Andamento</option>
                        <option value="2">Pendente</option>
                        <option value="3">Concluído</option>
                        <option value="4">Cancelado</option>
                    </select>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover pr-table" id="projects-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Projeto</th>
                            <th>Estado</th>
                            <th>Progresso</th>
                            <th>Gerente</th>
                            <th>Tipo</th>
                            <th>Prazo</th>
                            <th>Tarefas</th>
                            <th>Custo</th>
                            <th>Tickets</th>
                        </tr>
                    </thead>
                    <tbody id="projects-tbody">
                        <tr><td colspan="10" class="text-center text-muted py-4">
                            <i class="fa fa-spinner fa-spin"></i> Carregando...
                        </td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================
     SEÇÃO: TAREFAS
====================================================== -->
<section class="pr-section" id="section-tasks">
    <div class="container-fluid px-4 pt-3">
        <div class="pr-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="pr-card-title mb-0">
                    <i class="fa fa-list-check text-info me-2"></i>
                    Tarefas de Projetos
                </div>
                <input type="text" class="form-control form-control-sm search-input"
                       id="search-tasks" placeholder="🔍 Filtrar tarefas..." style="max-width:250px">
            </div>
            <div class="table-responsive">
                <table class="table table-hover pr-table" id="tasks-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tarefa</th>
                            <th>Projeto</th>
                            <th>Estado</th>
                            <th>Progresso</th>
                            <th>Responsável</th>
                            <th>Tipo</th>
                            <th>Prazo</th>
                            <th>Duração (h)</th>
                            <th>Tickets</th>
                        </tr>
                    </thead>
                    <tbody id="tasks-tbody">
                        <tr><td colspan="10" class="text-center text-muted py-4">
                            <i class="fa fa-spinner fa-spin"></i> Carregando...
                        </td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================
     SEÇÃO: CUSTOS
====================================================== -->
<section class="pr-section" id="section-costs">
    <div class="container-fluid px-4 pt-3">
        <div class="row g-3">
            <div class="col-12 col-xl-8">
                <div class="pr-card">
                    <div class="pr-card-title">
                        <i class="fa fa-dollar-sign text-success me-2"></i>
                        Custo por Projeto
                    </div>
                    <canvas id="chart-costs" height="300"></canvas>
                </div>
            </div>
            <div class="col-12 col-xl-4">
                <div class="pr-card h-100">
                    <div class="pr-card-title">
                        <i class="fa fa-table text-success me-2"></i>
                        Detalhamento
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm pr-table">
                            <thead>
                                <tr><th>Projeto</th><th>Custo (R$)</th><th>Lançamentos</th></tr>
                            </thead>
                            <tbody id="costs-tbody">
                                <tr><td colspan="3" class="text-muted text-center py-3">
                                    <i class="fa fa-spinner fa-spin"></i>
                                </td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================
     SEÇÃO: EQUIPE (Ranking)
====================================================== -->
<section class="pr-section" id="section-team">
    <div class="container-fluid px-4 pt-3">
        <div class="pr-card">
            <div class="pr-card-title">
                <i class="fa fa-trophy text-warning me-2"></i>
                Ranking de Gerentes de Projeto
            </div>
            <div id="ranking-list">
                <div class="text-muted text-center py-4">
                    <i class="fa fa-spinner fa-spin"></i> Carregando...
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================
     SCRIPTS
====================================================== -->
<script src="<?= $plugin_web_dir ?>/public/vendor/js/chart.umd.min.js"></script>
<script>
    const AJAX_URL = '<?= $ajax_url ?>';
</script>
<script src="<?= $plugin_web_dir ?>/public/js/script.js"></script>

</body>
</html>
