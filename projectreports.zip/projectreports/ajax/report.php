<?php
/**
 * Plugin ProjectReports — Endpoint AJAX
 *
 * Todas as actions retornam JSON.
 * Requer sessão GLPI autenticada.
 */

include('../../../inc/includes.php');

Session::checkLoginUser();

header('Content-Type: application/json; charset=utf-8');

// Inclui a classe de backend
include_once(Plugin::getPhpDir('projectreports') . '/inc/report.class.php');

$action = $_GET['action'] ?? '';

try {
    switch ($action) {

        case 'kpis':
            echo json_encode(PluginProjectreportsReport::getKPIs());
            break;

        case 'projects_list':
            $limit = min((int)($_GET['limit'] ?? 100), 500);
            echo json_encode(PluginProjectreportsReport::getProjectsList($limit));
            break;

        case 'tasks_list':
            $limit = min((int)($_GET['limit'] ?? 200), 1000);
            echo json_encode(PluginProjectreportsReport::getTasksList($limit));
            break;

        case 'projects_by_month':
            echo json_encode(PluginProjectreportsReport::getProjectsByMonth());
            break;

        case 'projects_by_state':
            echo json_encode(PluginProjectreportsReport::getProjectsByState());
            break;

        case 'projects_by_type':
            echo json_encode(PluginProjectreportsReport::getProjectsByType());
            break;

        case 'manager_ranking':
            echo json_encode(PluginProjectreportsReport::getManagerRanking());
            break;

        case 'project_costs':
            echo json_encode(PluginProjectreportsReport::getProjectCosts());
            break;

        case 'upcoming_deadlines':
            echo json_encode(PluginProjectreportsReport::getUpcomingDeadlines());
            break;

        case 'linked_tickets':
            echo json_encode(PluginProjectreportsReport::getLinkedTickets());
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação inválida.']);
            break;
    }
} catch (\Throwable $e) {
    Toolbox::logError('ProjectReports AJAX error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor.']);
}
