<?php
/**
 * Plugin ProjectReports — Dashboard de Projetos para GLPI 11
 *
 * @license GPLv3+
 */

define('PLUGIN_PROJECTREPORTS_VERSION',  '1.0.0');
define('PLUGIN_PROJECTREPORTS_MIN_GLPI', '11.0.0');
define('PLUGIN_PROJECTREPORTS_MAX_GLPI', '11.0.99');

function plugin_version_projectreports(): array
{
    return [
        'name'         => 'Project Reports',
        'version'      => PLUGIN_PROJECTREPORTS_VERSION,
        'author'       => 'Seu Nome',
        'license'      => 'GPLv3+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_PROJECTREPORTS_MIN_GLPI,
                'max' => PLUGIN_PROJECTREPORTS_MAX_GLPI,
            ],
        ],
    ];
}

function plugin_init_projectreports(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['projectreports'] = true;

    if (Session::getLoginUserID()) {
        $PLUGIN_HOOKS['redefine_menus']['projectreports'] = 'plugin_projectreports_redefine_menus';
        $PLUGIN_HOOKS['add_javascript']['projectreports']  = 'public/js/menu.js';
    }
}

function plugin_projectreports_check_prerequisites(): bool { return true; }
function plugin_projectreports_check_config(): bool        { return true; }
