/* ProjectReports — força link do menu abrir em nova aba */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('a[href*="projectreports"]').forEach(function (a) {
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener noreferrer');
    });
});
