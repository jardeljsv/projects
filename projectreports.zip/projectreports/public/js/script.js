/* ================================================================
   ProjectReports Plugin — Frontend JS
   Requer: Chart.js (UMD), AJAX_URL definido no PHP
   ================================================================ */

'use strict';

// ── Estado global ────────────────────────────────────────────────
const State = {
    projects:    [],
    tasks:       [],
    costs:       [],
    ranking:     [],
    deadlines:   [],
    kpis:        {},
    charts:      {},
    activeSection: 'overview',
};

// ── Helpers ──────────────────────────────────────────────────────

function escHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function fmtDate(d) {
    if (!d) return '—';
    const dt = new Date(d.replace(' ', 'T'));
    return dt.toLocaleDateString('pt-BR');
}

function fmtCurrency(v) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v ?? 0);
}

async function fetchJson(action, params = {}) {
    const qs  = new URLSearchParams({ action, ...params }).toString();
    const res = await fetch(`${AJAX_URL}?${qs}`);
    if (!res.ok) throw new Error(`HTTP ${res.status} — ${action}`);
    return res.json();
}

// ── Relógio ──────────────────────────────────────────────────────

function startClock() {
    const el = document.getElementById('clock');
    const tick = () => {
        el.textContent = new Date().toLocaleTimeString('pt-BR');
    };
    tick();
    setInterval(tick, 1000);
}

// ── Tema ─────────────────────────────────────────────────────────

function initTheme() {
    const saved = localStorage.getItem('pr_theme') || 'dark';
    applyTheme(saved);
    document.getElementById('btn-theme').addEventListener('click', () => {
        const next = document.body.classList.contains('light-mode') ? 'dark' : 'light';
        applyTheme(next);
        localStorage.setItem('pr_theme', next);
    });
}

function applyTheme(mode) {
    document.body.classList.toggle('light-mode', mode === 'light');
    const icon = document.querySelector('#btn-theme i');
    if (icon) icon.className = mode === 'light' ? 'fa fa-moon' : 'fa fa-sun';
}

// ── Navegação por seções ─────────────────────────────────────────

function initNav() {
    document.querySelectorAll('.pr-nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const sec = btn.dataset.section;
            showSection(sec);
        });
    });
}

function showSection(name) {
    State.activeSection = name;

    document.querySelectorAll('.pr-nav-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.section === name);
    });
    document.querySelectorAll('.pr-section').forEach(s => {
        s.classList.toggle('active', s.id === `section-${name}`);
    });

    // Carregar dados sob demanda
    if (name === 'projects'  && !State.projects.length)  loadProjects();
    if (name === 'tasks'     && !State.tasks.length)      loadTasks();
    if (name === 'costs'     && !State.costs.length)      loadCosts();
    if (name === 'team'      && !State.ranking.length)    loadRanking();
}

// ── KPIs ─────────────────────────────────────────────────────────

async function loadKPIs() {
    const data = await fetchJson('kpis');
    State.kpis = data;

    setText('kpi-total',      data.total);
    setText('kpi-in-progress',data.in_progress);
    setText('kpi-done',       data.done);
    setText('kpi-overdue',    data.overdue);
    setText('kpi-completion', data.completion_rate + '%');
    setText('kpi-tasks',      `${data.done_tasks} / ${data.total_tasks}`);
}

function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
}

// ── Gráfico: mensal (linha) ───────────────────────────────────────

async function loadMonthlyChart() {
    const data = await fetchJson('projects_by_month');

    const labels   = data.map(d => d.month);
    const created  = data.map(d => d.created);
    const closed   = data.map(d => d.closed);

    destroyChart('chart-monthly');

    State.charts['chart-monthly'] = new Chart(
        document.getElementById('chart-monthly'),
        {
            type: 'line',
            data: {
                labels,
                datasets: [
                    {
                        label: 'Criados',
                        data: created,
                        borderColor: '#2f81f7',
                        backgroundColor: 'rgba(47,129,247,.12)',
                        tension: .4,
                        fill: true,
                    },
                    {
                        label: 'Concluídos',
                        data: closed,
                        borderColor: '#238636',
                        backgroundColor: 'rgba(35,134,54,.12)',
                        tension: .4,
                        fill: true,
                    },
                ],
            },
            options: chartDefaults(),
        }
    );
}

// ── Gráfico: por estado (donut) ───────────────────────────────────

async function loadStateChart() {
    const data = await fetchJson('projects_by_state');

    destroyChart('chart-state');

    State.charts['chart-state'] = new Chart(
        document.getElementById('chart-state'),
        {
            type: 'doughnut',
            data: {
                labels:   data.map(d => d.label),
                datasets: [{
                    data:            data.map(d => d.count),
                    backgroundColor: data.map(d => d.color),
                    borderWidth: 2,
                    borderColor: 'transparent',
                }],
            },
            options: { ...chartDefaults(), cutout: '65%' },
        }
    );
}

// ── Gráfico: por tipo (donut) ─────────────────────────────────────

async function loadTypeChart() {
    const data = await fetchJson('projects_by_type');

    destroyChart('chart-type');

    State.charts['chart-type'] = new Chart(
        document.getElementById('chart-type'),
        {
            type: 'doughnut',
            data: {
                labels:   data.map(d => d.label),
                datasets: [{
                    data:            data.map(d => d.count),
                    backgroundColor: data.map(d => d.color),
                    borderWidth: 2,
                    borderColor: 'transparent',
                }],
            },
            options: { ...chartDefaults(), cutout: '65%' },
        }
    );
}

// ── Gráfico: custos (barras) ──────────────────────────────────────

async function loadCostChart() {
    destroyChart('chart-costs');

    State.charts['chart-costs'] = new Chart(
        document.getElementById('chart-costs'),
        {
            type: 'bar',
            data: {
                labels:   State.costs.map(d => d.project_name),
                datasets: [{
                    label: 'Custo Total (R$)',
                    data:  State.costs.map(d => d.total_cost),
                    backgroundColor: 'rgba(35,134,54,.7)',
                    borderColor: '#238636',
                    borderWidth: 1,
                    borderRadius: 6,
                }],
            },
            options: {
                ...chartDefaults(),
                indexAxis: 'y',
                plugins: { ...chartDefaults().plugins, legend: { display: false } },
                scales: {
                    x: {
                        ticks: {
                            color: '#8b949e',
                            callback: v => 'R$ ' + v.toLocaleString('pt-BR'),
                        },
                        grid: { color: 'rgba(255,255,255,.05)' },
                    },
                    y: { ticks: { color: '#8b949e' }, grid: { display: false } },
                },
            },
        }
    );
}

// ── Prazos próximos ───────────────────────────────────────────────

async function loadDeadlines() {
    const data = await fetchJson('upcoming_deadlines');
    State.deadlines = data;

    const el = document.getElementById('upcoming-deadlines-list');

    if (!data.length) {
        el.innerHTML = '<p class="text-muted text-center py-3">Nenhum prazo nos próximos 30 dias.</p>';
        return;
    }

    el.innerHTML = data.map(p => `
        <div class="deadline-item ${escHtml(p.urgency)}">
            <div>
                <div class="deadline-name">${escHtml(p.name)}</div>
                <small class="text-muted">${escHtml(p.state_label)}</small>
            </div>
            <div class="deadline-days text-${p.urgency === 'critical' ? 'danger' : p.urgency === 'warning' ? 'warning' : 'success'}">
                ${p.days_left === 0 ? 'Hoje!' : p.days_left + ' dias'}
            </div>
            <div style="width:120px">
                <div class="pr-progress">
                    <div class="pr-progress-bar ${progressClass(p.percent_done)}"
                         style="width:${p.percent_done}%"></div>
                </div>
                <small class="text-muted">${p.percent_done}%</small>
            </div>
            <small class="text-muted">${fmtDate(p.end_date)}</small>
        </div>
    `).join('');
}

// ── Tabela de Projetos ────────────────────────────────────────────

async function loadProjects() {
    if (!State.projects.length) {
        const data = await fetchJson('projects_list');
        State.projects = data;
    }
    renderProjectsTable(State.projects);
    initProjectFilters();
}

function renderProjectsTable(list) {
    const tbody = document.getElementById('projects-tbody');
    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">Nenhum projeto encontrado.</td></tr>';
        return;
    }

    tbody.innerHTML = list.map(p => `
        <tr class="${p.is_overdue ? 'overdue-row' : ''}">
            <td class="text-muted">${p.id}</td>
            <td>
                <div class="fw-semibold">${escHtml(p.name)}</div>
                ${p.is_overdue ? '<span class="pr-badge" style="background:rgba(218,54,51,.2);color:#da3633;">Vencido</span>' : ''}
            </td>
            <td>
                <span class="pr-badge" style="background:${escHtml(p.state_color)}22;color:${escHtml(p.state_color)}">
                    ${escHtml(p.state_label)}
                </span>
            </td>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="pr-progress" style="width:80px">
                        <div class="pr-progress-bar ${progressClass(p.percent_done)}"
                             style="width:${p.percent_done}%"></div>
                    </div>
                    <small>${p.percent_done}%</small>
                </div>
            </td>
            <td>${escHtml(p.manager)}</td>
            <td><small class="text-muted">${escHtml(p.type)}</small></td>
            <td class="${p.is_overdue ? 'text-danger' : ''}">${fmtDate(p.end_date)}</td>
            <td>
                <span class="text-success">${p.task_done}</span>/<span>${p.task_total}</span>
            </td>
            <td>${p.total_cost > 0 ? fmtCurrency(p.total_cost) : '<span class="text-muted">—</span>'}</td>
            <td>${p.linked_tickets > 0
                ? `<span class="pr-badge" style="background:rgba(47,129,247,.15);color:#2f81f7;">${p.linked_tickets}</span>`
                : '<span class="text-muted">—</span>'}</td>
        </tr>
    `).join('');
}

function initProjectFilters() {
    const searchEl  = document.getElementById('search-projects');
    const filterEl  = document.getElementById('filter-state');

    const apply = () => {
        const q     = (searchEl.value || '').toLowerCase();
        const state = filterEl.value;
        const filtered = State.projects.filter(p => {
            const matchQ = !q || p.name.toLowerCase().includes(q) || p.manager.toLowerCase().includes(q);
            const matchS = !state || String(p.state) === state;
            return matchQ && matchS;
        });
        renderProjectsTable(filtered);
    };

    searchEl.addEventListener('input', apply);
    filterEl.addEventListener('change', apply);
}

// ── Tabela de Tarefas ─────────────────────────────────────────────

async function loadTasks() {
    if (!State.tasks.length) {
        const data = await fetchJson('tasks_list');
        State.tasks = data;
    }
    renderTasksTable(State.tasks);
    initTaskFilters();
}

function renderTasksTable(list) {
    const tbody = document.getElementById('tasks-tbody');
    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">Nenhuma tarefa encontrada.</td></tr>';
        return;
    }

    tbody.innerHTML = list.map(t => `
        <tr class="${t.is_overdue ? 'overdue-row' : ''}">
            <td class="text-muted">${t.id}</td>
            <td>
                <div class="fw-semibold">${escHtml(t.name)}</div>
                ${t.is_overdue ? '<span class="pr-badge" style="background:rgba(218,54,51,.2);color:#da3633;">Vencida</span>' : ''}
            </td>
            <td><small>${escHtml(t.project_name)}</small></td>
            <td>
                <span class="pr-badge" style="background:${escHtml(t.state_color)}22;color:${escHtml(t.state_color)}">
                    ${escHtml(t.state_label)}
                </span>
            </td>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="pr-progress" style="width:70px">
                        <div class="pr-progress-bar ${progressClass(t.percent_done)}"
                             style="width:${t.percent_done}%"></div>
                    </div>
                    <small>${t.percent_done}%</small>
                </div>
            </td>
            <td>${escHtml(t.user)}</td>
            <td><small class="text-muted">${escHtml(t.task_type)}</small></td>
            <td class="${t.is_overdue ? 'text-danger' : ''}">${fmtDate(t.end_date)}</td>
            <td>${t.planned_hours !== null ? t.planned_hours + 'h' : '<span class="text-muted">—</span>'}</td>
            <td>${t.linked_tickets > 0
                ? `<span class="pr-badge" style="background:rgba(47,129,247,.15);color:#2f81f7;">${t.linked_tickets}</span>`
                : '<span class="text-muted">—</span>'}</td>
        </tr>
    `).join('');
}

function initTaskFilters() {
    const searchEl = document.getElementById('search-tasks');
    searchEl.addEventListener('input', () => {
        const q = searchEl.value.toLowerCase();
        const filtered = State.tasks.filter(t =>
            t.name.toLowerCase().includes(q) ||
            t.project_name.toLowerCase().includes(q) ||
            t.user.toLowerCase().includes(q)
        );
        renderTasksTable(filtered);
    });
}

// ── Custos ────────────────────────────────────────────────────────

async function loadCosts() {
    if (!State.costs.length) {
        const data = await fetchJson('project_costs');
        State.costs = data;
    }

    // Tabela
    const tbody = document.getElementById('costs-tbody');
    if (!State.costs.length) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted py-3">Nenhum custo registrado.</td></tr>';
    } else {
        tbody.innerHTML = State.costs.map(c => `
            <tr>
                <td>${escHtml(c.project_name)}</td>
                <td class="text-success fw-bold">${fmtCurrency(c.total_cost)}</td>
                <td class="text-muted">${c.cost_entries}</td>
            </tr>
        `).join('');
    }

    loadCostChart();
}

// ── Ranking ───────────────────────────────────────────────────────

async function loadRanking() {
    const data = await fetchJson('manager_ranking');
    State.ranking = data;

    const el = document.getElementById('ranking-list');

    if (!data.length) {
        el.innerHTML = '<p class="text-muted text-center py-4">Nenhum gerente encontrado.</p>';
        return;
    }

    const medals = ['🥇','🥈','🥉'];
    const maxPts = data[0]?.points || 1;

    el.innerHTML = data.map((m, i) => `
        <div class="ranking-item">
            <div class="rank-position" style="background:${m.color}22;color:${m.color}">
                ${i < 3 ? medals[i] : i + 1}
            </div>
            <div style="flex:1">
                <div class="rank-name">${escHtml(m.name)}</div>
                <div class="rank-stats">
                    ${m.done} concluídos · ${m.total} total · ${m.avg_progress}% progresso médio
                </div>
            </div>
            <div class="rank-bar">
                <div class="rank-bar-fill" style="width:${Math.round((m.points/maxPts)*100)}%;background:${m.color}"></div>
            </div>
            <div class="rank-points" style="color:${m.color}">${m.points}<small class="text-muted fs-6"> pts</small></div>
        </div>
    `).join('');
}

// ── Utilitários de gráfico ────────────────────────────────────────

function chartDefaults() {
    return {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: '#8b949e', padding: 12, boxWidth: 12 },
            },
            tooltip: {
                backgroundColor: 'rgba(22,27,34,.95)',
                titleColor: '#e6edf3',
                bodyColor: '#8b949e',
                borderColor: 'rgba(255,255,255,.1)',
                borderWidth: 1,
            },
        },
        scales: {
            x: {
                ticks: { color: '#8b949e' },
                grid:  { color: 'rgba(255,255,255,.05)' },
            },
            y: {
                ticks: { color: '#8b949e' },
                grid:  { color: 'rgba(255,255,255,.05)' },
            },
        },
    };
}

function destroyChart(id) {
    if (State.charts[id]) {
        State.charts[id].destroy();
        delete State.charts[id];
    }
}

function progressClass(pct) {
    if (pct >= 100) return 'done';
    if (pct >= 60)  return '';
    if (pct >= 30)  return 'warning';
    return 'danger';
}

// ── Atualização automática ────────────────────────────────────────

function updateLastUpdated() {
    const el = document.getElementById('last-update');
    if (el) el.textContent = 'Atualizado: ' + new Date().toLocaleTimeString('pt-BR');
}

async function refreshAll() {
    try {
        await Promise.all([
            loadKPIs(),
            loadMonthlyChart(),
            loadStateChart(),
            loadTypeChart(),
            loadDeadlines(),
        ]);

        // Resetar cache de sub-seções para forçar recarga
        State.projects = [];
        State.tasks    = [];
        State.costs    = [];
        State.ranking  = [];

        if (State.activeSection === 'projects') loadProjects();
        if (State.activeSection === 'tasks')    loadTasks();
        if (State.activeSection === 'costs')    loadCosts();
        if (State.activeSection === 'team')     loadRanking();

        updateLastUpdated();
    } catch (err) {
        console.error('ProjectReports refresh error:', err);
    }
}

// ── Inicialização ─────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
    startClock();
    initTheme();
    initNav();

    // Botão de refresh manual
    document.getElementById('btn-refresh').addEventListener('click', refreshAll);

    // Carga inicial da seção overview
    await refreshAll();

    // Auto-refresh a cada 60 s
    setInterval(refreshAll, 60_000);
});
