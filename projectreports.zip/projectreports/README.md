# ProjectReports — Dashboard de Projetos para GLPI 11

Plugin standalone de relatórios para o módulo de **Projetos** do GLPI 11, inspirado na arquitetura do [dashglpi](https://github.com/diberlanda95/dashglpi).

**Compatibilidade:** GLPI 11.0.x  
**Licença:** GPLv3+

---

## Funcionalidades

### Visão Geral (Overview)
- **6 KPIs em tempo real:** Total, Em Andamento, Concluídos, Vencidos, Taxa de Conclusão, Tarefas
- **Gráfico de linha:** Projetos criados vs concluídos (últimos 6 meses)
- **Donut por Estado:** Novo / Em Andamento / Pendente / Concluído / Cancelado
- **Donut por Tipo:** usando `glpi_projecttypes`
- **Prazos nos próximos 30 dias** com indicador de urgência

### Projetos
- Tabela completa com filtro de texto e filtro por estado
- Dados: estado, progresso (barra), gerente, tipo, prazo, tarefas, custo, tickets vinculados
- Destaque visual para projetos vencidos

### Tarefas
- Tabela de todas as tarefas (`glpi_projecttasks`) com projeto pai
- Responsável (de `glpi_projecttaskteams`), tipo (`glpi_projecttasktypes`)
- Duração planejada em horas, tickets vinculados (`glpi_projecttasks_tickets`)
- Filtro de texto em tempo real

### Custos
- Gráfico de barras horizontais com custo total por projeto (`glpi_projectcosts`)
- Tabela detalhada com número de lançamentos

### Equipe (Ranking)
- Ranking de gerentes por projetos concluídos + progresso médio
- Sistema de pontos (10 pts por projeto concluído + média de progresso)
- Destaque 🥇🥈🥉 para os três primeiros

### Recursos Gerais
- Modo escuro / claro com persistência (`localStorage`)
- Atualização automática a cada 60 segundos
- Relógio em tempo real
- Design glassmorphism responsivo

---

## Tabelas utilizadas

| Tabela | Uso |
|---|---|
| `glpi_projects` | Dados principais dos projetos |
| `glpi_projectstates` | Estados personalizados (nome + cor) |
| `glpi_projecttypes` | Tipos de projeto |
| `glpi_projectteams` | Equipe do projeto |
| `glpi_projecttasks` | Tarefas |
| `glpi_projecttaskteams` | Responsáveis pelas tarefas |
| `glpi_projecttasktypes` | Tipos de tarefa |
| `glpi_projecttasklinks` | Dependências (futuro) |
| `glpi_projecttasks_tickets` | Tickets vinculados às tarefas |
| `glpi_projectcosts` | Custos lançados por projeto |

---

## Instalação

```bash
# 1. Copie a pasta para o diretório de plugins do GLPI
cp -r projectreports/ /usr/share/glpi/plugins/

# 2. Se usar OPcache com validate_timestamps=Off
pkill -USR2 php-fpm
```

3. Acesse o GLPI como administrador
4. Vá em **Configurar > Plugins**
5. Localize **Project Reports** → **Instalar** → **Ativar**
6. Acesse pelo menu **Ferramentas > Relatório de Projetos**

> O dashboard abre em **nova aba** para visualização fullscreen.

---

## Estrutura

```
projectreports/
├── setup.php                     # Registro do plugin
├── hook.php                      # Install/uninstall/menu
├── front/
│   └── report.php                # Página standalone (HTML completo)
├── ajax/
│   └── report.php                # Endpoint AJAX (10 actions, retorna JSON)
├── inc/
│   └── report.class.php          # Backend: queries via $DB->request()
├── public/
│   ├── css/
│   │   └── style.css             # Glassmorphism dark/light
│   ├── js/
│   │   ├── script.js             # Lógica frontend (charts, tabelas, filtros)
│   │   └── menu.js               # JS mínimo global (abre em nova aba)
│   └── vendor/
│       ├── css/
│       │   ├── bootstrap.min.css
│       │   └── fontawesome.min.css
│       └── js/
│           └── chart.umd.min.js
└── README.md
```

---

## API AJAX

Endpoint: `plugins/projectreports/ajax/report.php`

| Action | Descrição |
|---|---|
| `kpis` | KPIs gerais |
| `projects_list` | Lista de projetos |
| `tasks_list` | Lista de tarefas |
| `projects_by_month` | Projetos por mês (6 meses) |
| `projects_by_state` | Distribuição por estado |
| `projects_by_type` | Distribuição por tipo |
| `manager_ranking` | Ranking de gerentes |
| `project_costs` | Custos por projeto |
| `upcoming_deadlines` | Prazos nos próximos 30 dias |
| `linked_tickets` | Tickets vinculados a tarefas |

---

## Vendor (arquivos necessários)

Coloque estes arquivos em `public/vendor/`:

- `css/bootstrap.min.css` — Bootstrap 5
- `css/fontawesome.min.css` — FontAwesome 6 Free
- `js/chart.umd.min.js` — Chart.js 4

Baixe de:
- Bootstrap: https://getbootstrap.com/docs/5.3/getting-started/download/
- FontAwesome: https://fontawesome.com/download
- Chart.js: https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js
