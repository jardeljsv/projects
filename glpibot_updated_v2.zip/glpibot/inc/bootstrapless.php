<?php
// Bootstrapless GLPIBot runtime helpers for public plugin endpoints.

if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/common.php';

if (!function_exists('glpibot_json_response')) {
    function glpibot_json_response(int $status, array $payload): void {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('glpibot_files_log_path')) {
    function glpibot_files_log_path(?string $glpiRoot): string {
        if ($glpiRoot) {
            $candidate = rtrim($glpiRoot, '/\\') . '/files/_log/glpibot-plugin.log';
            $dir = dirname($candidate);
            if (is_dir($dir) && is_writable($dir)) {
                return $candidate;
            }
        }
        return '/tmp/glpibot-plugin.log';
    }
}

if (!function_exists('glpibot_log')) {
    function glpibot_log(?string $glpiRoot, string $message): void {
        $file = glpibot_files_log_path($glpiRoot);
        $ts = date('Y-m-d H:i:s');
        @file_put_contents($file, '[' . $ts . '] ' . $message . "\n", FILE_APPEND);
    }
}

if (!function_exists('glpibot_find_glpi_root')) {
    function glpibot_find_glpi_root(): ?string {
        $candidates = [
            dirname(__DIR__, 3),
            dirname(__DIR__, 2),
            dirname(__DIR__, 1),
        ];
        foreach ($candidates as $cand) {
            if ($cand && is_dir($cand) && is_file($cand . '/config/config_db.php')) {
                return $cand;
            }
        }
        return null;
    }
}

if (!function_exists('glpibot_include_glpi_db_config')) {
    function glpibot_include_glpi_db_config(string $glpiRoot): bool {
        $configPath = rtrim($glpiRoot, '/\\') . '/config/config_db.php';
        if (!is_file($configPath)) {
            return false;
        }
        if (!class_exists('DBmysql')) {
            class DBmysql {}
        }
        require_once $configPath;
        return class_exists('DB');
    }
}

if (!function_exists('glpibot_open_plugin_mysqli')) {
    function glpibot_open_plugin_mysqli(?string &$glpiRootOut = null, ?array &$dbInfoOut = null): ?mysqli {
        if (function_exists('mysqli_report')) {
            @mysqli_report(MYSQLI_REPORT_OFF);
        }

        $glpiRoot = glpibot_find_glpi_root();
        $glpiRootOut = $glpiRoot;
        if ($glpiRoot === null) {
            return null;
        }

        try {
            if (!glpibot_include_glpi_db_config($glpiRoot)) {
                return null;
            }
        } catch (Throwable $e) {
            glpibot_log($glpiRoot, 'DB_CONFIG_INCLUDE_ERROR ' . $e->getMessage());
            return null;
        }

        try {
            $dbobj = new DB();
        } catch (Throwable $e) {
            glpibot_log($glpiRoot, 'DB_OBJECT_ERROR ' . $e->getMessage());
            return null;
        }

        $dbHost = property_exists($dbobj, 'dbhost') ? (string)$dbobj->dbhost : 'localhost';
        $dbUser = property_exists($dbobj, 'dbuser') ? (string)$dbobj->dbuser : '';
        $dbPass = property_exists($dbobj, 'dbpassword') ? (string)$dbobj->dbpassword : '';
        $dbName = property_exists($dbobj, 'dbdefault') ? (string)$dbobj->dbdefault : '';
        $dbPort = property_exists($dbobj, 'dbport') ? (int)$dbobj->dbport : 3306;

        $dbInfoOut = [
            'dbhost' => $dbHost,
            'dbuser' => $dbUser,
            'dbdefault' => $dbName,
            'dbport' => $dbPort,
        ];

        if ($dbUser === '' || $dbName === '') {
            glpibot_log($glpiRoot, 'DB_CREDENTIALS_INCOMPLETE');
            return null;
        }

        $mysqli = @mysqli_connect($dbHost, $dbUser, $dbPass, $dbName, $dbPort);
        if (!$mysqli) {
            glpibot_log($glpiRoot, 'DB_CONNECT_FAILED ' . (string)mysqli_connect_error());
            return null;
        }

        @mysqli_set_charset($mysqli, 'utf8mb4');
        return $mysqli;
    }
}

if (!function_exists('glpibot_load_plugin_config_from_mysqli')) {
    function glpibot_load_plugin_config_from_mysqli(mysqli $mysqli): array {
        $cfg = [];
        $sql = "SELECT name, value FROM glpi_configs WHERE context = 'plugin:glpibot'";
        $res = @mysqli_query($mysqli, $sql);
        if ($res) {
            while ($row = mysqli_fetch_assoc($res)) {
                $cfg[(string)$row['name']] = (string)$row['value'];
            }
            mysqli_free_result($res);
        }
        return $cfg;
    }
}

if (!function_exists('glpibot_pick_glpi_session_cookie_name')) {
    function glpibot_pick_glpi_session_cookie_name(): ?string {
        $names = array_keys($_COOKIE);

        $best = null;
        foreach ($names as $n) {
            if (!is_string($n)) continue;
            if (substr($n, -11) === '_rememberme') continue;
            if (stripos($n, 'glpi_') === 0) {
                if ($best === null || strlen($n) > strlen($best)) {
                    $best = $n;
                }
            }
        }
        if ($best !== null) {
            return $best;
        }

        foreach ($names as $n) {
            if (!is_string($n)) continue;
            if (substr($n, -11) === '_rememberme') continue;
            if (stripos($n, 'glpi') === 0) {
                return $n;
            }
        }

        if (isset($_COOKIE['PHPSESSID'])) {
            return 'PHPSESSID';
        }

        return null;
    }
}

if (!function_exists('glpibot_resolve_uid_from_php_session')) {
    function glpibot_resolve_uid_from_php_session(array &$debug = []): int {
        $cookieName = glpibot_pick_glpi_session_cookie_name();
        $debug['picked_cookie_name'] = $cookieName;
        if ($cookieName === null) {
            return 0;
        }

        $sid = $_COOKIE[$cookieName] ?? '';
        if (!is_string($sid)) {
            return 0;
        }
        $sid = trim(urldecode($sid));
        $debug['picked_cookie_value_len'] = strlen($sid);
        if ($sid === '' || strlen($sid) < 6 || strlen($sid) > 256) {
            return 0;
        }

        if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
            @session_write_close();
        }

        @session_name($cookieName);
        @session_id($sid);

        if (PHP_VERSION_ID >= 70000) {
            @session_start(['read_and_close' => true]);
        } else {
            @session_start();
            @session_write_close();
        }

        $uid = 0;
        if (isset($_SESSION) && is_array($_SESSION)) {
            foreach (['glpiID', 'glpiId', 'GLPI_ID'] as $k) {
                if (isset($_SESSION[$k])) {
                    $uid = (int)$_SESSION[$k];
                    break;
                }
            }
        }

        $debug['uid_from_session'] = $uid;
        return $uid > 0 ? $uid : 0;
    }
}

if (!function_exists('glpibot_get_user_groups_mysqli')) {
    function glpibot_get_user_groups_mysqli(mysqli $mysqli, int $uid): array {
        $ids = [];
        if ($uid <= 0) {
            return [];
        }
        $sql = 'SELECT `groups_id` FROM `glpi_groups_users` WHERE `users_id` = ' . (int)$uid;
        $res = @mysqli_query($mysqli, $sql);
        if ($res) {
            while ($row = mysqli_fetch_assoc($res)) {
                $gid = (int)($row['groups_id'] ?? 0);
                if ($gid > 0) {
                    $ids[$gid] = true;
                }
            }
            mysqli_free_result($res);
        }
        return array_keys($ids);
    }
}

if (!function_exists('glpibot_expand_group_ancestors_with_distance')) {
    function glpibot_expand_group_ancestors_with_distance(mysqli $mysqli, array $groupIds): array {
        $dist = [];
        $frontier = [];
        foreach ($groupIds as $gid) {
            $gid = (int)$gid;
            if ($gid > 0 && !isset($dist[$gid])) {
                $dist[$gid] = 0;
                $frontier[$gid] = 0;
            }
        }

        $depth = 0;
        while (!empty($frontier) && $depth < 20) {
            $depth++;
            $ids = implode(',', array_map('intval', array_keys($frontier)));
            $next = [];
            $sql = 'SELECT `id`, `groups_id` FROM `glpi_groups` WHERE `id` IN (' . $ids . ')';
            $res = @mysqli_query($mysqli, $sql);
            if (!$res) {
                break;
            }
            while ($row = mysqli_fetch_assoc($res)) {
                $id = (int)($row['id'] ?? 0);
                $parent = (int)($row['groups_id'] ?? 0);
                if ($id <= 0 || $parent <= 0) {
                    continue;
                }
                $candidateDistance = ((int)($dist[$id] ?? 0)) + 1;
                if (!isset($dist[$parent]) || $candidateDistance < (int)$dist[$parent]) {
                    $dist[$parent] = $candidateDistance;
                    $next[$parent] = $candidateDistance;
                }
            }
            mysqli_free_result($res);
            $frontier = $next;
        }

        return $dist;
    }
}

if (!function_exists('glpibot_match_route_for_uid')) {
    function glpibot_match_route_for_uid(mysqli $mysqli, array $cfg, int $uid): array {
        $routes = glpibot_parse_group_routes_json($cfg['group_routes_json'] ?? '');
        $enabledRoutes = [];
        foreach ($routes as $route) {
            if (!empty($route['enabled'])) {
                $enabledRoutes[] = $route;
            }
        }

        $userGroups = glpibot_get_user_groups_mysqli($mysqli, $uid);
        $expanded = glpibot_expand_group_ancestors_with_distance($mysqli, $userGroups);

        $best = null;
        foreach ($enabledRoutes as $route) {
            $gid = (int)$route['group_id'];
            if ($gid <= 0 || !isset($expanded[$gid])) {
                continue;
            }
            $distance = (int)$expanded[$gid];
            if (empty($route['include_children']) && $distance > 0) {
                continue;
            }

            $candidate = [
                'route' => $route,
                'distance' => $distance,
                'direct_groups' => $userGroups,
                'expanded_groups' => array_keys($expanded),
                'expanded_distances' => $expanded,
            ];

            if ($best === null) {
                $best = $candidate;
                continue;
            }

            $cmp = 0;
            $aPriority = (int)$candidate['route']['priority'];
            $bPriority = (int)$best['route']['priority'];
            if ($aPriority !== $bPriority) {
                $cmp = $aPriority <=> $bPriority;
            } elseif ((int)$candidate['distance'] !== (int)$best['distance']) {
                $cmp = ((int)$candidate['distance']) <=> ((int)$best['distance']);
            } elseif ((int)$candidate['route']['group_id'] !== (int)$best['route']['group_id']) {
                $cmp = ((int)$candidate['route']['group_id']) <=> ((int)$best['route']['group_id']);
            } else {
                $cmp = strcmp((string)$candidate['route']['id'], (string)$best['route']['id']);
            }

            if ($cmp < 0) {
                $best = $candidate;
            }
        }

        return [
            'route_mode' => !empty($enabledRoutes),
            'matched' => $best !== null,
            'match' => $best,
            'user_groups' => $userGroups,
            'expanded_groups' => $best['expanded_groups'] ?? array_keys($expanded),
            'expanded_distances' => $best['expanded_distances'] ?? $expanded,
        ];
    }
}

if (!function_exists('glpibot_profile_from_route_match')) {
    function glpibot_profile_from_route_match(array $cfg, ?array $match): ?array {
        if ($match === null || !isset($match['route']) || !is_array($match['route'])) {
            return null;
        }
        $profileId = glpibot_string($match['route']['profile_id'] ?? '__default__', '__default__');
        $profiles = glpibot_profiles_with_default($cfg);
        $profile = $profiles[$profileId] ?? null;
        if (!is_array($profile)) {
            return null;
        }
        if (!empty($profile['is_default'])) {
            return $profile;
        }
        if (empty($profile['enabled'])) {
            return null;
        }
        return $profile;
    }
}

if (!function_exists('glpibot_resolve_legacy_visibility')) {
    function glpibot_resolve_legacy_visibility(mysqli $mysqli, array $cfg, int $uid): array {
        $allowedGroups = glpibot_parse_id_list($cfg['allowed_groups'] ?? '');
        if (empty($allowedGroups)) {
            return [
                'allowed' => true,
                'restricted' => false,
                'uncertain' => false,
                'reason' => 'all_users',
                'user_groups' => [],
                'expanded_groups' => [],
            ];
        }
        if ($uid <= 0) {
            return [
                'allowed' => true,
                'restricted' => true,
                'uncertain' => true,
                'reason' => 'uncertain_uid_not_found',
                'user_groups' => [],
                'expanded_groups' => [],
            ];
        }
        $userGroups = glpibot_get_user_groups_mysqli($mysqli, $uid);
        $expanded = glpibot_expand_group_ancestors_with_distance($mysqli, $userGroups);
        $allowedMap = [];
        foreach ($allowedGroups as $gid) {
            $allowedMap[(int)$gid] = true;
        }
        $hit = false;
        foreach (array_keys($expanded) as $gid) {
            if (isset($allowedMap[(int)$gid])) {
                $hit = true;
                break;
            }
        }
        return [
            'allowed' => $hit,
            'restricted' => true,
            'uncertain' => false,
            'reason' => $hit ? 'in_allowed_group' : 'not_in_allowed_groups',
            'user_groups' => $userGroups,
            'expanded_groups' => array_keys($expanded),
        ];
    }
}

if (!function_exists('glpibot_resolve_widget_visibility')) {
    function glpibot_resolve_widget_visibility(mysqli $mysqli, array $cfg, int $uid): array {
        $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
        if (!$enabled) {
            return [
                'enabled' => false,
                'restricted' => false,
                'allowed' => false,
                'uncertain' => false,
                'reason' => 'disabled',
                'route_mode' => false,
                'matched_route' => null,
                'profile_name' => null,
            ];
        }

        $routeProbe = glpibot_match_route_for_uid($mysqli, $cfg, max(0, $uid));
        if (!empty($routeProbe['route_mode'])) {
            if ($uid <= 0) {
                return [
                    'enabled' => true,
                    'restricted' => true,
                    'allowed' => true,
                    'uncertain' => true,
                    'reason' => 'uncertain_uid_not_found',
                    'route_mode' => true,
                    'matched_route' => null,
                    'profile_name' => null,
                ];
            }
            if (!empty($routeProbe['matched'])) {
                $profile = glpibot_profile_from_route_match($cfg, $routeProbe['match']);
                if (!is_array($profile)) {
                    return [
                        'enabled' => true,
                        'restricted' => true,
                        'allowed' => false,
                        'uncertain' => false,
                        'reason' => 'route_profile_missing_or_disabled',
                        'route_mode' => true,
                        'matched_route' => $routeProbe['match']['route'],
                        'profile_name' => null,
                    ];
                }
                return [
                    'enabled' => true,
                    'restricted' => true,
                    'allowed' => true,
                    'uncertain' => false,
                    'reason' => 'matched_group_route',
                    'route_mode' => true,
                    'matched_route' => $routeProbe['match']['route'],
                    'profile_name' => (string)($profile['name'] ?? ''),
                ];
            }
            return [
                'enabled' => true,
                'restricted' => true,
                'allowed' => false,
                'uncertain' => false,
                'reason' => 'no_matching_route',
                'route_mode' => true,
                'matched_route' => null,
                'profile_name' => null,
            ];
        }

        $legacy = glpibot_resolve_legacy_visibility($mysqli, $cfg, $uid);
        return [
            'enabled' => true,
            'restricted' => (bool)$legacy['restricted'],
            'allowed' => (bool)$legacy['allowed'],
            'uncertain' => (bool)$legacy['uncertain'],
            'reason' => (string)$legacy['reason'],
            'route_mode' => false,
            'matched_route' => null,
            'profile_name' => null,
        ];
    }
}

if (!function_exists('glpibot_resolve_runtime_profile')) {
    function glpibot_resolve_runtime_profile(mysqli $mysqli, array $cfg, int $uid): array {
        $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
        if (!$enabled) {
            return [
                'ok' => false,
                'reason' => 'disabled',
                'route_mode' => false,
                'profile' => null,
                'uid_required' => false,
            ];
        }

        $routeProbe = glpibot_match_route_for_uid($mysqli, $cfg, max(0, $uid));
        if (!empty($routeProbe['route_mode'])) {
            if ($uid <= 0) {
                return [
                    'ok' => false,
                    'reason' => 'uid_not_found_for_route_mode',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }
            if (empty($routeProbe['matched'])) {
                return [
                    'ok' => false,
                    'reason' => 'no_matching_route',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }
            $profile = glpibot_profile_from_route_match($cfg, $routeProbe['match']);
            if (!is_array($profile)) {
                return [
                    'ok' => false,
                    'reason' => 'route_profile_missing_or_disabled',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }
            return [
                'ok' => true,
                'reason' => 'matched_group_route',
                'route_mode' => true,
                'profile' => $profile,
                'matched_route' => $routeProbe['match']['route'],
                'uid_required' => true,
            ];
        }

        $legacy = glpibot_resolve_legacy_visibility($mysqli, $cfg, $uid);
        if (!empty($legacy['uncertain'])) {
            return [
                'ok' => false,
                'reason' => 'uid_not_found_for_legacy_group_mode',
                'route_mode' => false,
                'profile' => null,
                'uid_required' => true,
            ];
        }
        if (empty($legacy['allowed'])) {
            return [
                'ok' => false,
                'reason' => (string)$legacy['reason'],
                'route_mode' => false,
                'profile' => null,
                'uid_required' => !empty($legacy['restricted']),
            ];
        }

        return [
            'ok' => true,
            'reason' => 'legacy_default_profile',
            'route_mode' => false,
            'profile' => glpibot_default_profile_from_config($cfg),
            'uid_required' => false,
        ];
    }
}

if (!function_exists('glpibot_http_json_request')) {
    function glpibot_http_json_request(string $method, string $url, array $headers = [], $body = null, int $timeoutMs = 60000): array {
        $ch = curl_init();
        if ($ch === false) {
            return [
                'ok' => false,
                'http_code' => 0,
                'curl_error' => 'curl_init_failed',
                'body_raw' => '',
                'json' => null,
            ];
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $method = strtoupper(trim($method));
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
            }
        } elseif ($method !== 'GET') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
            }
        } else {
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        }

        $timeoutMs = max(1000, min($timeoutMs, 600000));
        if (defined('CURLOPT_TIMEOUT_MS')) {
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, $timeoutMs);
        } else {
            curl_setopt($ch, CURLOPT_TIMEOUT, (int)ceil($timeoutMs / 1000));
        }

        $bodyRaw = curl_exec($ch);
        $curlErr = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $json = null;
        if (is_string($bodyRaw) && $bodyRaw !== '') {
            $parsed = json_decode($bodyRaw, true);
            if (is_array($parsed)) {
                $json = $parsed;
            }
        }

        return [
            'ok' => ($bodyRaw !== false && $curlErr === '' && $httpCode >= 200 && $httpCode < 300),
            'http_code' => $httpCode,
            'curl_error' => $curlErr,
            'body_raw' => is_string($bodyRaw) ? $bodyRaw : '',
            'json' => $json,
        ];
    }
}
