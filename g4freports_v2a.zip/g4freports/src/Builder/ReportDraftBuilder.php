<?php

namespace GlpiPlugin\G4freports\Builder;

use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Api\SearchOptionResolver;
use GlpiPlugin\G4freports\Util\DateHelper;
use GlpiPlugin\G4freports\Util\TextNormalizer;

class ReportDraftBuilder
{
    private array $cfg;
    private array $profile;
    private GlpiApiClient $client;
    private SearchOptionResolver $resolver;
    private array $warnings = [];
    private bool $maskSensitive = true;
    private int $maxItems = 200;
    private int $candidateLimit = 60;
    private int $subitemLimit = 20;
    private int $maxAutoGroups = 5;
    private int $timeLimitSeconds = 22;
    private float $startedAt = 0.0;
    private bool $budgetExceeded = false;
    private string $agentName = '';
    private array $labelCache = [];
    private array $subitemCache = [];
    private int $rangeStart = 0;
    private int $rangeLimit = 0;
    private string $batchContext = '';
    private array $sourceTotals = [];
    private array $sourceReturned = [];
    private bool $batchHasMore = false;

    public function __construct(array $cfg, array $profile)
    {
        $this->cfg = $cfg;
        $this->profile = $profile;

        // Report extraction must fail fast. In the target GLPI deployment the
        // web server can return 504 before PHP finishes if one GLPI API search
        // waits too long. Keep per-request timeouts shorter than the page
        // timeout and return a partial draft with warnings instead of hanging.
        $extractTimeout = max(3000, min(20000, (int)($cfg['extract_request_timeout_ms'] ?? 12000)));
        $profile['timeout_ms'] = min(max(1000, (int)($profile['timeout_ms'] ?? $extractTimeout)), $extractTimeout);
        $profile['connect_timeout_ms'] = min(max(1000, (int)($profile['connect_timeout_ms'] ?? 5000)), 5000);

        $this->client = new GlpiApiClient($profile);
        $overrides = json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true);
        $this->resolver = new SearchOptionResolver($this->client, is_array($overrides) ? $overrides : []);
        $this->maskSensitive = ((int)($cfg['mask_sensitive_data'] ?? 1)) === 1;
        $this->maxItems = max(10, min(1000, (int)($cfg['max_items'] ?? 200)));
        $this->candidateLimit = max(10, min($this->maxItems, (int)($cfg['max_candidates'] ?? 60)));
        $this->subitemLimit = max(10, min(100, (int)($cfg['subitem_limit'] ?? 50)));
        $this->maxAutoGroups = max(0, min(20, (int)($cfg['max_auto_groups'] ?? 5)));
        $this->timeLimitSeconds = max(5, min(45, (int)($cfg['max_runtime_seconds'] ?? 22)));
    }

    public function build(array $request): array
    {
        $this->startedAt = microtime(true);
        $this->budgetExceeded = false;
        $this->subitemCache = [];
        $this->sourceTotals = [];
        $this->sourceReturned = [];
        $this->batchHasMore = false;
        $this->batchContext = trim((string)($request['batch_context'] ?? ''));
        $this->rangeStart = max(0, (int)($request['batch_offset'] ?? 0));
        $this->rangeLimit = max(0, min(100, (int)($request['batch_limit'] ?? 0)));

        $requestedLimit = (int)($request['max_items'] ?? 0);
        if ($requestedLimit > 0 && $this->batchContext === '') {
            $this->maxItems = max(10, min($this->maxItems, $requestedLimit));
            $this->candidateLimit = max(10, min($this->candidateLimit, $this->maxItems));
        }
        if ($this->batchContext !== '') {
            if ($this->rangeLimit <= 0) {
                $this->rangeLimit = 50;
            }
            // One browser batch must stay small enough to survive nginx/PHP
            // timeouts. The browser will request the next page if has_more=true.
            $this->candidateLimit = $this->rangeLimit;
            $this->maxItems = max($this->rangeLimit * 5, $this->rangeLimit + 20);
        }

        $start = DateHelper::normalizeDate((string)($request['period_start'] ?? ''), date('Y-m-01'));
        $end   = DateHelper::normalizeDate((string)($request['period_end'] ?? ''), date('Y-m-t'));
        if (strtotime($end) < strtotime($start)) {
            [$start, $end] = [$end, $start];
        }

        $agentId = (int)($request['agent_id'] ?? 0);
        $contexts = $request['contexts'] ?? [];
        if (!is_array($contexts)) {
            $contexts = preg_split('/[,\s]+/', (string)$contexts) ?: [];
        }
        $contexts = array_values(array_unique(array_filter(array_map('strval', $contexts))));
        if ($this->batchContext !== '') {
            $contexts = [$this->batchContext];
        }
        if (empty($contexts)) {
            $contexts = ['tickets_assigned_user', 'ticket_tasks_by_user', 'ticket_followups_by_user', 'ticket_solutions_by_user', 'manual_entries'];
        }

        $manualGroupIds = $this->parseIdList($request['group_ids'] ?? '');
        $template = trim((string)($request['template'] ?? 'operational')) ?: 'operational';

        $agent = ['id' => $agentId, 'name' => trim((string)($request['agent_name'] ?? ''))];
        if ($agentId > 0) {
            try {
                $item = $this->client->getItem('User', $agentId, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                $agent['raw'] = $item;
                $agent['name'] = TextNormalizer::firstNonEmpty($item['name'] ?? '', $item['realname'] ?? '', $item['firstname'] ?? '', $agent['name']);
                if (isset($item['firstname']) || isset($item['realname'])) {
                    $full = trim((string)($item['firstname'] ?? '') . ' ' . (string)($item['realname'] ?? ''));
                    if ($full !== '') {
                        $agent['name'] = $full;
                    }
                }
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível obter dados completos do agente via API: ' . $e->getMessage();
            }
        }
        if ($agent['name'] === '') {
            $agent['name'] = $agentId > 0 ? ('Usuário ID ' . $agentId) : 'Profissional não informado';
        }
        $this->agentName = (string)$agent['name'];

        // Important operational rule: group contexts are explicit. The plugin no
        // longer falls back to every group linked to the selected agent, because
        // some contracts have groups with very large queues and that automatic
        // expansion can make even a one-day report time out. If the user wants
        // group data, they must select the group in the searchable group field.
        $groupIds = array_values(array_unique(array_map('intval', $manualGroupIds)));
        $groups = $this->resolveGroups($groupIds);
        if (empty($groupIds) && $this->hasAny($contexts, ['tickets_assigned_groups','projects_managed_by_groups','project_tasks_groups'])) {
            $this->warnings[] = 'Contexto por grupo selecionado, mas nenhum grupo foi escolhido no campo "Grupos selecionados". A extração por grupo foi ignorada para evitar varredura automática de filas grandes.';
        }

        $entries = [];
        $seen = [];

        if ($agentId <= 0 && $this->requiresAgent($contexts)) {
            $this->warnings[] = 'Nenhum agente foi informado. Os contextos vinculados a usuário podem retornar poucos dados.';
        }

        if ($this->hasAny($contexts, ['tickets_assigned_user','tickets_requested_by_user','tickets_assigned_groups','ticket_tasks_by_user','ticket_followups_by_user','ticket_solutions_by_user'])) {
            $tickets = $this->collectTickets($agentId, $groupIds, $contexts, $start, $end);
            foreach ($tickets as $ticketId => $ticket) {
                $ticketEntries = $this->ticketToEntries((int)$ticketId, $ticket, $agentId, $contexts, $start, $end);
                foreach ($ticketEntries as $entry) {
                    $this->addEntry($entries, $seen, $entry);
                }
                if (count($entries) >= $this->maxItems) {
                    $this->warnings[] = 'Limite máximo de entradas atingido durante a leitura de chamados. Ajuste o período, os contextos ou o limite nas configurações.';
                    break;
                }
            }
        }

        if ($this->budgetExceeded) {
            // Keep whatever was already collected and skip expensive stages.
        } elseif ($this->hasAny($contexts, ['projects_managed_by_user','projects_managed_by_groups','projects_member_user','project_tasks_user','project_tasks_groups'])) {
            $projects = $this->collectProjects($agentId, $groupIds, $contexts, $start, $end);
            foreach ($projects as $projectId => $project) {
                $projectEntries = $this->projectToEntries((int)$projectId, $project, $agentId, $groupIds, $contexts, $start, $end);
                foreach ($projectEntries as $entry) {
                    $this->addEntry($entries, $seen, $entry);
                }
                if (count($entries) >= $this->maxItems) {
                    $this->warnings[] = 'Limite máximo de entradas atingido durante a leitura de projetos. Ajuste o período, os contextos ou o limite nas configurações.';
                    break;
                }
            }
        }

        if ($this->budgetExceeded) {
            $this->warnings[] = 'A extração foi interrompida pelo limite de segurança antes do timeout do servidor. O rascunho pode estar parcial; reduza o período/contextos ou aumente o limite somente se o ambiente suportar.';
        }

        usort($entries, static function ($a, $b) {
            $d = strcmp((string)($a['date'] ?? ''), (string)($b['date'] ?? ''));
            if ($d !== 0) return $d;
            return strcmp((string)($a['title'] ?? ''), (string)($b['title'] ?? ''));
        });

        $metrics = $this->calculateMetrics($entries);
        $daily = $this->groupByDay($entries);
        $validations = $this->validateDraft($entries, $contexts, $start, $end);

        return [
            'schema_version' => 1,
            'created_at' => date('c'),
            'connection' => [
                'id' => (string)($this->profile['id'] ?? 'default'),
                'name' => (string)($this->profile['name'] ?? 'GLPI')
            ],
            'contract_label' => (string)($this->cfg['contract_label'] ?? ''),
            'report_title' => trim((string)($request['report_title'] ?? '')) ?: (string)($this->cfg['default_report_title'] ?? 'Relatório Gerencial de Atividades'),
            'template' => $template,
            'period_start' => $start,
            'period_end' => $end,
            'subject' => [
                'type' => 'user',
                'id' => $agentId,
                'name' => $agent['name']
            ],
            'groups' => array_values($groups),
            'contexts' => $contexts,
            'scope_text' => (string)($request['scope_text'] ?? ($this->cfg['default_scope_text'] ?? '')),
            'objective_text' => (string)($request['objective_text'] ?? ($this->cfg['default_objective_text'] ?? '')),
            'executive_summary' => $this->defaultExecutiveSummary($entries, $agent['name'], $start, $end),
            'metrics' => $metrics,
            'entries' => $entries,
            'daily_groups' => $daily,
            'validations' => $validations,
            'warnings' => array_values(array_unique($this->warnings)),
            'source_totals' => $this->sourceTotals,
            'batch' => [
                'context' => $this->batchContext,
                'offset' => $this->rangeStart,
                'limit' => $this->rangeLimit,
                'returned_candidates' => array_sum($this->sourceReturned),
                'total_candidates' => $this->batchTotalCandidates(),
                'has_more' => $this->batchHasMore,
            ],
            'footer' => (string)($this->cfg['default_footer'] ?? '')
        ];
    }

    private function collectTickets(int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $fields = $this->resolver->fields('Ticket', [
            'id' => [2], 'name' => [1], 'status' => [12], 'date' => [15], 'date_mod' => [19],
            'closedate' => [16], 'solvedate' => [18], 'users_id_assign' => [5],
            'groups_id_assign' => [8], 'users_id_recipient' => [4], 'itilcategories_id' => [7], 'priority' => [3], 'content' => [21, 1]
        ]);
        $display = array_values(array_filter($fields));
        $tickets = [];

        if ($agentId > 0 && in_array('tickets_assigned_user', $contexts, true) && $fields['users_id_assign'] > 0) {
            $this->mergeSearchRows($tickets, 'Ticket', [
                $this->crit($fields['users_id_assign'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'tickets_assigned_user');
        }

        if ($agentId > 0 && in_array('tickets_requested_by_user', $contexts, true) && $fields['users_id_recipient'] > 0) {
            $this->mergeSearchRows($tickets, 'Ticket', [
                $this->crit($fields['users_id_recipient'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'tickets_requested_by_user');
        }

        if (in_array('tickets_assigned_groups', $contexts, true) && $fields['groups_id_assign'] > 0) {
            if (empty($groupIds)) {
                $this->warnings[] = 'Chamados por grupo ignorados: selecione pelo menos um grupo no campo de grupos.';
            }
            foreach ($groupIds as $gid) {
                if (!$this->checkBudget('pesquisa de chamados por grupo') || count($tickets) >= $this->candidateLimit) { break; }
                $this->mergeSearchRows($tickets, 'Ticket', [
                    $this->crit($fields['groups_id_assign'], 'equals', (int)$gid),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
                ], $display, 'tickets_assigned_groups');
            }
        }

        // Direct subitem searches can discover work performed by the agent even when the ticket is not assigned to them.
        if ($agentId > 0 && in_array('ticket_tasks_by_user', $contexts, true) && count($tickets) < $this->candidateLimit && $this->checkBudget('pesquisa de tarefas de chamado')) {
            foreach ($this->searchSubitemParents('TicketTask', 'tickets_id', $agentId, $start, $end) as $ticketId) {
                if (count($tickets) >= $this->candidateLimit) { break; }
                $tickets[$ticketId]['_sources']['ticket_tasks_by_user'] = true;
            }
        }
        if ($agentId > 0 && in_array('ticket_followups_by_user', $contexts, true) && count($tickets) < $this->candidateLimit && $this->checkBudget('pesquisa de acompanhamentos')) {
            foreach ($this->searchSubitemParents('ITILFollowup', 'items_id', $agentId, $start, $end, 'Ticket') as $ticketId) {
                if (count($tickets) >= $this->candidateLimit) { break; }
                $tickets[$ticketId]['_sources']['ticket_followups_by_user'] = true;
            }
        }
        if ($agentId > 0 && in_array('ticket_solutions_by_user', $contexts, true) && count($tickets) < $this->candidateLimit && $this->checkBudget('pesquisa de soluções')) {
            foreach ($this->searchSubitemParents('ITILSolution', 'items_id', $agentId, $start, $end, 'Ticket') as $ticketId) {
                if (count($tickets) >= $this->candidateLimit) { break; }
                $tickets[$ticketId]['_sources']['ticket_solutions_by_user'] = true;
            }
        }

        // Enrich each ticket item. Keep candidate set bounded; ticket subitems
        // are fetched later only for records that really need them.
        if (count($tickets) > $this->candidateLimit) {
            $this->warnings[] = 'Foram encontrados mais chamados do que o limite seguro deste rascunho. Apenas os primeiros ' . $this->candidateLimit . ' candidatos foram detalhados.';
            $tickets = array_slice($tickets, 0, $this->candidateLimit, true);
        }
        foreach (array_keys($tickets) as $id) {
            if (!$this->checkBudget('detalhamento de chamados')) { break; }
            try {
                $tickets[$id]['item'] = $this->client->getItem('Ticket', (int)$id, ['expand_dropdowns' => true, 'get_hateoas' => false]);
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível detalhar o chamado ' . $id . ': ' . $e->getMessage();
            }
        }

        return $tickets;
    }

    private function collectProjects(int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $fields = $this->resolver->fields('Project', [
            'id' => [2], 'name' => [1], 'status' => [12], 'date_mod' => [19], 'date' => [15],
            'manager_user' => [4], 'manager_group' => [8], 'percent_done' => [86], 'code' => [3], 'content' => [21, 1]
        ]);
        $display = array_values(array_filter($fields));
        $projects = [];

        if ($agentId > 0 && in_array('projects_managed_by_user', $contexts, true) && $fields['manager_user'] > 0) {
            $this->mergeSearchRows($projects, 'Project', [
                $this->crit($fields['manager_user'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'projects_managed_by_user');
        }

        if (in_array('projects_managed_by_groups', $contexts, true) && $fields['manager_group'] > 0) {
            if (empty($groupIds)) {
                $this->warnings[] = 'Projetos por grupo ignorados: selecione pelo menos um grupo no campo de grupos.';
            }
            foreach ($groupIds as $gid) {
                if (!$this->checkBudget('pesquisa de projetos por grupo') || count($projects) >= $this->candidateLimit) { break; }
                $this->mergeSearchRows($projects, 'Project', [
                    $this->crit($fields['manager_group'], 'equals', (int)$gid),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
                ], $display, 'projects_managed_by_groups');
            }
        }

        if ($agentId > 0 && in_array('project_tasks_user', $contexts, true) && count($projects) < $this->candidateLimit && $this->checkBudget('pesquisa de tarefas de projeto')) {
            foreach ($this->searchSubitemParents('ProjectTask', 'projects_id', $agentId, $start, $end) as $projectId) {
                if (count($projects) >= $this->candidateLimit) { break; }
                $projects[$projectId]['_sources']['project_tasks_user'] = true;
            }
        }

        if (in_array('project_tasks_groups', $contexts, true) && empty($groupIds)) {
            $this->warnings[] = 'Tarefas de projeto por grupo ignoradas: selecione pelo menos um grupo no campo de grupos.';
        }

        // Do not probe all projects in the period. That was the main cause of 504
        // errors in larger GLPI instances. Try direct membership/searchable team
        // tables only; if the API does not expose them, return a warning and let
        // the user use managed projects, project tasks, or manual entries.
        if ($agentId > 0 && in_array('projects_member_user', $contexts, true) && count($projects) < $this->candidateLimit && $this->checkBudget('pesquisa de participação em projetos')) {
            $foundMemberProject = false;
            foreach (['ProjectTeam', 'Project_User'] as $teamType) {
                foreach ($this->searchSubitemParents($teamType, 'projects_id', $agentId, $start, $end) as $projectId) {
                    if (count($projects) >= $this->candidateLimit) { break 2; }
                    $projects[$projectId]['_sources']['projects_member_user'] = true;
                    $foundMemberProject = true;
                }
            }
            if (!$foundMemberProject && empty($projects)) {
                $this->warnings[] = 'O contexto "projetos em que o agente participa" depende de campos de equipe pesquisáveis pela API. Nesta instância, use projetos gerenciados, tarefas de projeto ou adicione a narrativa manualmente se a API não expuser essa relação.';
            }
        }

        if (count($projects) > $this->candidateLimit) {
            $this->warnings[] = 'Foram encontrados mais projetos do que o limite seguro deste rascunho. Apenas os primeiros ' . $this->candidateLimit . ' candidatos foram detalhados.';
            $projects = array_slice($projects, 0, $this->candidateLimit, true);
        }
        foreach (array_keys($projects) as $id) {
            if (!$this->checkBudget('detalhamento de projetos')) { break; }
            try {
                $projects[$id]['item'] = $this->client->getItem('Project', (int)$id, ['expand_dropdowns' => true, 'get_hateoas' => false]);
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível detalhar o projeto ' . $id . ': ' . $e->getMessage();
            }
        }

        return $projects;
    }

    private function ticketToEntries(int $ticketId, array $ticket, int $agentId, array $contexts, string $start, string $end): array
    {
        $item = $ticket['item'] ?? [];
        $row = $ticket['row'] ?? [];
        $title = TextNormalizer::firstNonEmpty($item['name'] ?? '', $this->rowVal($row, 1), 'Chamado ' . $ticketId);
        $statusRaw = TextNormalizer::firstNonEmpty($item['status'] ?? '', $this->rowVal($row, 12));
        $status = $this->ticketStatusLabel($statusRaw);
        $fallbackDate = TextNormalizer::firstNonEmpty($item['date_mod'] ?? '', $item['date'] ?? '', $this->rowVal($row, 19), $this->rowVal($row, 15), $start);
        $entries = [];

        $content = TextNormalizer::clean($item['content'] ?? '', $this->maskSensitive);
        $latest = [];
        $ticketCameFromAgentActivity = !empty($ticket['_sources']['ticket_tasks_by_user'])
            || !empty($ticket['_sources']['ticket_followups_by_user'])
            || !empty($ticket['_sources']['ticket_solutions_by_user']);
        // Looking for the latest agent comment/task/solution requires subitem API
        // calls. Do it for tickets tied to the agent or directly discovered from
        // agent activity, but do not scan every ticket from a large group queue.
        if ($ticketCameFromAgentActivity || !empty($ticket['_sources']['tickets_assigned_user'])) {
            $latest = $this->latestTicketActivity($ticketId, $agentId, $start, $end);
        }
        $solutionSummary = '';
        if (empty($latest['text']) && (!empty($ticket['_sources']['ticket_solutions_by_user']) || !empty($ticket['_sources']['tickets_assigned_user']))) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILSolution') as $sol) {
                $solutionSummary .= "\n" . TextNormalizer::clean($sol['content'] ?? ($sol['solution'] ?? ''), $this->maskSensitive);
            }
        }
        $baseText = trim((string)($latest['text'] ?? '')) ?: (trim($solutionSummary) ?: $content);
        $date = TextNormalizer::firstNonEmpty($latest['date'] ?? '', $fallbackDate);
        $baseReference = TextNormalizer::firstNonEmpty($latest['reference'] ?? '', 'Chamado ' . $ticketId);

        if (!empty($ticket['_sources']['tickets_assigned_user']) || !empty($ticket['_sources']['tickets_requested_by_user']) || !empty($ticket['_sources']['tickets_assigned_groups'])) {
            $entries[] = $this->entry([
                'date' => $date,
                'source_type' => 'ticket',
                'source_itemtype' => 'Ticket',
                'source_id' => $ticketId,
                'source_reference' => $baseReference,
                'title' => 'Chamado ' . $ticketId . ' - ' . $title,
                'status' => $status,
                'category' => $this->dropdownLabel('ITILCategory', TextNormalizer::firstNonEmpty($item['itilcategories_id'] ?? '', $this->rowVal($row, 7))),
                'activity_performed' => TextNormalizer::summarize($baseText ?: 'Registro localizado no GLPI dentro do contexto selecionado. Complementar a narrativa técnica, se necessário.', 1800),
                'result' => $this->resultFromStatus($status),
                'next_steps' => '',
                'observations' => trim((string)($latest['note'] ?? '')) ?: 'Origem: chamado vinculado ao contexto selecionado.'
            ]);
        }

        if (in_array('ticket_tasks_by_user', $contexts, true) && (!empty($ticket['_sources']['ticket_tasks_by_user']) || !empty($ticket['_sources']['tickets_assigned_user']))) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'TicketTask') as $task) {
                $taskDate = TextNormalizer::firstNonEmpty($task['date'] ?? '', $task['begin'] ?? '', $task['date_creation'] ?? '', $task['date_mod'] ?? '', $fallbackDate);
                if (!DateHelper::within($taskDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($task, $agentId)) continue;
                $txt = TextNormalizer::clean($task['content'] ?? ($task['name'] ?? ''), $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $taskDate,
                    'source_type' => 'ticket_task',
                    'source_itemtype' => 'TicketTask',
                    'source_id' => (int)($task['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Tarefa ' . (int)($task['id'] ?? 0),
                    'title' => 'Tarefa do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Tarefa registrada no chamado.',
                    'result' => $this->resultFromStatus($status),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de tarefa do GLPI.'
                ]);
            }
        }

        if (in_array('ticket_followups_by_user', $contexts, true) && (!empty($ticket['_sources']['ticket_followups_by_user']) || !empty($ticket['_sources']['tickets_assigned_user']))) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILFollowup') as $follow) {
                $fDate = TextNormalizer::firstNonEmpty($follow['date'] ?? '', $follow['date_creation'] ?? '', $follow['date_mod'] ?? '', $fallbackDate);
                if (!DateHelper::within($fDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($follow, $agentId)) continue;
                $txt = TextNormalizer::clean($follow['content'] ?? '', $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $fDate,
                    'source_type' => 'ticket_followup',
                    'source_itemtype' => 'ITILFollowup',
                    'source_id' => (int)($follow['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Acompanhamento ' . (int)($follow['id'] ?? 0),
                    'title' => 'Acompanhamento do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Acompanhamento registrado no chamado.',
                    'result' => $this->resultFromStatus($status),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de acompanhamento do GLPI.'
                ]);
            }
        }

        if (in_array('ticket_solutions_by_user', $contexts, true) && (!empty($ticket['_sources']['ticket_solutions_by_user']) || !empty($ticket['_sources']['tickets_assigned_user']))) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILSolution') as $sol) {
                $sDate = TextNormalizer::firstNonEmpty($sol['date_approval'] ?? '', $sol['date_creation'] ?? '', $sol['date_mod'] ?? '', $item['solvedate'] ?? '', $fallbackDate);
                if (!DateHelper::within($sDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($sol, $agentId)) {
                    if ($this->hasExplicitUserField($sol)) {
                        continue;
                    }
                }
                $txt = TextNormalizer::clean($sol['content'] ?? ($sol['solution'] ?? ''), $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $sDate,
                    'source_type' => 'ticket_solution',
                    'source_itemtype' => 'ITILSolution',
                    'source_id' => (int)($sol['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Solução ' . (int)($sol['id'] ?? 0),
                    'title' => 'Solução do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Solução registrada no chamado.',
                    'result' => 'Solução registrada no GLPI.',
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de solução do GLPI.'
                ]);
            }
        }

        return $entries;
    }

    private function projectToEntries(int $projectId, array $project, int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $item = $project['item'] ?? [];
        $row = $project['row'] ?? [];
        $title = TextNormalizer::firstNonEmpty($item['name'] ?? '', $this->rowVal($row, 1), 'Projeto ' . $projectId);
        $statusRaw = TextNormalizer::firstNonEmpty($item['projectstates_id'] ?? '', $item['status'] ?? '', $this->rowVal($row, 12));
        $status = $this->projectStatusLabel($statusRaw);
        $fallbackDate = TextNormalizer::firstNonEmpty($item['date_mod'] ?? '', $item['date_creation'] ?? '', $this->rowVal($row, 19), $start);
        $entries = [];

        $isMember = !in_array('projects_member_user', $contexts, true)
            || !empty($project['_sources']['projects_member_user'])
            || !empty($project['_sources']['projects_managed_by_user'])
            || !empty($project['_sources']['projects_managed_by_groups'])
            || !empty($project['_sources']['project_tasks_user']);
        if ($agentId > 0 && in_array('projects_member_user', $contexts, true) && !$isMember) {
            return [];
        }

        if (!empty($project['_sources']['projects_managed_by_user']) || !empty($project['_sources']['projects_managed_by_groups']) || ($isMember && in_array('projects_member_user', $contexts, true))) {
            $content = TextNormalizer::clean($item['content'] ?? ($item['comment'] ?? ''), $this->maskSensitive);
            $latest = $this->latestProjectActivity($projectId, $agentId, $start, $end);
            $activityText = trim((string)($latest['text'] ?? '')) ?: $content;
            $entries[] = $this->entry([
                'date' => TextNormalizer::firstNonEmpty($latest['date'] ?? '', $fallbackDate),
                'source_type' => 'project',
                'source_itemtype' => 'Project',
                'source_id' => $projectId,
                'source_reference' => TextNormalizer::firstNonEmpty($latest['reference'] ?? '', 'Projeto ' . $projectId),
                'title' => 'Projeto ' . $projectId . ' - ' . $title,
                'status' => $status,
                'category' => $this->dropdownLabel('ProjectType', TextNormalizer::firstNonEmpty($item['projecttypes_id'] ?? '', $item['type'] ?? '')),
                'activity_performed' => TextNormalizer::summarize($activityText ?: 'Projeto localizado no GLPI dentro do contexto selecionado. Complementar a narrativa técnica, se necessário.', 1800),
                'result' => $this->projectResult($item),
                'next_steps' => '',
                'observations' => trim((string)($latest['note'] ?? '')) ?: 'Origem: projeto vinculado ao contexto selecionado.'
            ]);
        }

        $shouldScanProjectTasks = !empty($project['_sources']['project_tasks_user'])
            || !empty($project['_sources']['projects_managed_by_user'])
            || (in_array('project_tasks_groups', $contexts, true) && !empty($project['_sources']['projects_managed_by_groups']));
        if ($this->hasAny($contexts, ['project_tasks_user','project_tasks_groups']) && $shouldScanProjectTasks) {
            foreach ($this->safeSubitems('Project', $projectId, 'ProjectTask') as $task) {
                $taskDate = TextNormalizer::firstNonEmpty($task['real_start_date'] ?? '', $task['plan_start_date'] ?? '', $task['date_creation'] ?? '', $task['date_mod'] ?? '', $fallbackDate);
                if (!DateHelper::within($taskDate, $start, $end)) continue;
                $belongs = false;
                if (in_array('project_tasks_user', $contexts, true) && ($agentId <= 0 || $this->subitemBelongsToUser($task, $agentId))) {
                    $belongs = true;
                }
                if (!$belongs && in_array('project_tasks_groups', $contexts, true) && $this->subitemBelongsToAnyGroup($task, $groupIds)) {
                    $belongs = true;
                }
                if (!$belongs && !$this->hasExplicitOwnerField($task)) {
                    // Some APIs omit task team; include tasks from already selected project as fallback.
                    $belongs = true;
                }
                if (!$belongs) continue;

                $txt = TextNormalizer::clean(($task['content'] ?? '') ?: ($task['name'] ?? ''), $this->maskSensitive);
                $taskStatus = $this->projectTaskStatusLabel(TextNormalizer::firstNonEmpty($task['projecttaskstates_id'] ?? '', $task['state'] ?? '', $status));
                $entries[] = $this->entry([
                    'date' => $taskDate,
                    'source_type' => 'project_task',
                    'source_itemtype' => 'ProjectTask',
                    'source_id' => (int)($task['id'] ?? 0),
                    'source_reference' => 'Projeto ' . $projectId . ' / Tarefa ' . (int)($task['id'] ?? 0),
                    'title' => 'Tarefa de projeto - ' . TextNormalizer::firstNonEmpty($task['name'] ?? '', $title),
                    'status' => $taskStatus,
                    'activity_performed' => $txt ?: 'Tarefa de projeto registrada no GLPI.',
                    'result' => $this->projectTaskResult($task),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de tarefa de projeto.'
                ]);
            }
        }

        return $entries;
    }

    private function latestTicketActivity(int $ticketId, int $agentId, string $start, string $end): array
    {
        return $this->latestActivityFromSubitems('Ticket', $ticketId, [
            'ITILFollowup' => ['label' => 'Acompanhamento', 'text' => ['content'], 'date' => ['date', 'date_creation', 'date_mod']],
            'TicketTask'   => ['label' => 'Tarefa', 'text' => ['content', 'name'], 'date' => ['date', 'begin', 'date_creation', 'date_mod']],
            'ITILSolution' => ['label' => 'Solução', 'text' => ['content', 'solution'], 'date' => ['date_approval', 'date_creation', 'date_mod']],
        ], $agentId, $start, $end, 'Chamado ' . $ticketId);
    }

    private function latestProjectActivity(int $projectId, int $agentId, string $start, string $end): array
    {
        return $this->latestActivityFromSubitems('Project', $projectId, [
            'ProjectTask' => ['label' => 'Tarefa de projeto', 'text' => ['content', 'name'], 'date' => ['real_start_date', 'plan_start_date', 'date_creation', 'date_mod']],
        ], $agentId, $start, $end, 'Projeto ' . $projectId);
    }

    private function latestActivityFromSubitems(string $parentType, int $parentId, array $subtypes, int $agentId, string $start, string $end, string $baseRef): array
    {
        $candidates = [];
        foreach ($subtypes as $subtype => $meta) {
            if (!$this->checkBudget('leitura de atividades relacionadas')) { break; }
            $rows = $this->safeSubitems($parentType, $parentId, (string)$subtype);
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $date = $this->firstField($row, $meta['date'] ?? ['date_mod', 'date_creation']);
                if ($date === '') {
                    $date = date('Y-m-d');
                }
                if (!DateHelper::within($date, $start, $end)) continue;
                $text = TextNormalizer::clean($this->firstField($row, $meta['text'] ?? ['content', 'name']), $this->maskSensitive);
                if ($text === '') continue;
                $belongs = $agentId <= 0 || $this->subitemBelongsToUser($row, $agentId);
                $hasOwner = $this->hasExplicitUserField($row);
                $score = $belongs ? 2 : ($hasOwner ? 0 : 1);
                if ($score <= 0) continue;
                $id = (int)($row['id'] ?? 0);
                $label = (string)($meta['label'] ?? $subtype);
                $candidates[] = [
                    'date' => DateHelper::normalizeDate($date, date('Y-m-d')),
                    'datetime' => (string)$date,
                    'text' => $text,
                    'score' => $score,
                    'reference' => $baseRef . ' / último ' . $label . ($id > 0 ? ' ' . $id : ''),
                    'note' => $score === 2 ? 'Narrativa baseada na última atividade registrada pelo agente no período.' : 'Narrativa baseada na última atividade encontrada no período; a API não expôs autoria numérica suficiente para validação pelo agente.'
                ];
            }
        }
        if (empty($candidates)) {
            return [];
        }
        usort($candidates, static function ($a, $b) {
            $score = ((int)$b['score']) <=> ((int)$a['score']);
            if ($score !== 0) return $score;
            return strcmp((string)$b['datetime'], (string)$a['datetime']);
        });
        return $candidates[0];
    }

    private function firstField(array $row, array $keys): string
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && trim((string)$row[$key]) !== '') {
                return (string)$row[$key];
            }
        }
        return '';
    }

    private function ticketStatusLabel($status): string
    {
        if (is_array($status)) {
            $label = TextNormalizer::firstNonEmpty($status['name'] ?? '', $status['completename'] ?? '');
            if ($label !== '') return $label;
            $status = $status['id'] ?? '';
        }
        $s = trim((string)$status);
        if ($s === '') return '';
        if (!is_numeric($s)) return TextNormalizer::clean($s, $this->maskSensitive);
        $map = [
            1 => 'Novo',
            2 => 'Em atendimento (atribuído)',
            3 => 'Em atendimento (planejado)',
            4 => 'Pendente',
            5 => 'Solucionado',
            6 => 'Fechado'
        ];
        return $map[(int)$s] ?? ('Status ' . (int)$s);
    }

    private function projectStatusLabel($status): string
    {
        $label = $this->dropdownLabel('ProjectState', $status);
        $s = trim((string)(is_array($status) ? ($status['id'] ?? '') : $status));
        $map = [
            1 => 'Novo',
            2 => 'Em andamento',
            17 => 'Em andamento',
            20 => 'Concluído'
        ];
        if (preg_match('/^ProjectState #([0-9]+)$/', $label, $m)) {
            return $map[(int)$m[1]] ?? $label;
        }
        return $label !== '' ? $label : ($map[(int)$s] ?? '');
    }

    private function projectTaskStatusLabel($status): string
    {
        $label = $this->dropdownLabel('ProjectTaskState', $status);
        if (preg_match('/^ProjectTaskState #([0-9]+)$/', $label, $m)) {
            $map = [1 => 'Novo', 2 => 'Em andamento', 17 => 'Em andamento', 20 => 'Concluído'];
            return $map[(int)$m[1]] ?? $label;
        }
        return $label;
    }

    private function dropdownLabel(string $itemtype, $value): string
    {
        if (is_array($value)) {
            $label = TextNormalizer::firstNonEmpty($value['completename'] ?? '', $value['name'] ?? '', $value['comment'] ?? '');
            if ($label !== '') {
                return TextNormalizer::clean($label, $this->maskSensitive);
            }
            $value = $value['id'] ?? $value['items_id'] ?? '';
        } elseif (is_object($value)) {
            $value = (array)$value;
            return $this->dropdownLabel($itemtype, $value);
        }
        $s = trim((string)$value);
        if ($s === '') return '';
        if (!is_numeric($s)) return TextNormalizer::clean($s, $this->maskSensitive);
        $id = (int)$s;
        if ($id <= 0) return '';
        $cacheKey = $itemtype . ':' . $id;
        if (isset($this->labelCache[$cacheKey])) {
            return $this->labelCache[$cacheKey];
        }
        try {
            $item = $this->client->getItem($itemtype, $id, ['expand_dropdowns' => true, 'get_hateoas' => false]);
            if (is_array($item)) {
                $label = TextNormalizer::firstNonEmpty($item['completename'] ?? '', $item['name'] ?? '', $item['comment'] ?? '');
                if ($label !== '') {
                    return $this->labelCache[$cacheKey] = TextNormalizer::clean($label, $this->maskSensitive);
                }
            }
        } catch (\Throwable $e) {
            // Keep numeric fallback below.
        }
        return $this->labelCache[$cacheKey] = ($itemtype . ' #' . $id);
    }

    private function hasExplicitUserField(array $row): bool
    {
        foreach (['users_id', 'users_id_tech', 'users_id_editor', 'users_id_recipient', 'users_id_validate', 'users_id_approval'] as $k) {
            if (array_key_exists($k, $row) && trim((string)$row[$k]) !== '') {
                return true;
            }
        }
        if (isset($row['itemtype']) && strtolower((string)$row['itemtype']) === 'user' && isset($row['items_id'])) {
            return true;
        }
        return false;
    }

    private function hasExplicitOwnerField(array $row): bool
    {
        return $this->hasExplicitUserField($row)
            || array_key_exists('groups_id', $row)
            || array_key_exists('groups_id_tech', $row)
            || array_key_exists('groups_id_assign', $row)
            || array_key_exists('groups_id_recipient', $row)
            || (isset($row['itemtype']) && in_array(strtolower((string)$row['itemtype']), ['user', 'group'], true) && isset($row['items_id']));
    }

    private function mergeSearchRows(array &$bucket, string $itemtype, array $criteria, array $display, string $source): void
    {
        $display = array_values(array_unique(array_filter($display)));
        if (!$this->checkBudget('pesquisa ' . $itemtype)) {
            return;
        }
        try {
            $start = $this->rangeLimit > 0 ? $this->rangeStart : 0;
            $limit = $this->rangeLimit > 0 ? $this->rangeLimit : $this->candidateLimit;
            $range = $start . '-' . max($start, $start + $limit - 1);
            $res = $this->client->search($itemtype, $criteria, $display, $range, ['sort' => $display[0] ?? 2, 'order' => 'DESC']);
            $rows = is_array($res['data'] ?? null) ? $res['data'] : [];
            $this->recordSearchMeta($source, $res, count($rows), $start, $limit);
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $id = $this->rowId($row);
                if ($id <= 0) continue;
                if (!isset($bucket[$id])) {
                    if (count($bucket) >= max($limit, $this->candidateLimit)) { break; }
                    $bucket[$id] = ['row' => $row, '_sources' => []];
                }
                $bucket[$id]['_sources'][$source] = true;
            }
        } catch (\Throwable $e) {
            $this->warnings[] = 'Falha ao pesquisar ' . $itemtype . ' para o contexto ' . $source . ': ' . $e->getMessage();
        }
    }

    private function searchSubitemParents(string $itemtype, string $parentFieldLogical, int $agentId, string $start, string $end, string $requiredItemtype = ''): array
    {
        $risky = in_array($itemtype, ['ProjectTeam', 'Project_User', 'ProjectTaskTeam'], true);
        if ($risky) {
            $idField = $this->resolver->fieldStrict($itemtype, 'id') ?: 2;
            $parentField = $this->resolver->fieldStrict($itemtype, $parentFieldLogical);
            $userField = $this->resolver->fieldStrict($itemtype, 'users_id');
            $dateField = $this->resolver->fieldStrict($itemtype, 'date_mod') ?: $this->resolver->fieldStrict($itemtype, 'date');
            if ($parentField <= 0 || $userField <= 0) {
                $this->warnings[] = 'O contexto baseado em ' . $itemtype . ' foi ignorado porque a API não expôs campos pesquisáveis seguros para usuário/projeto. Configure overrides somente se necessário.';
                return [];
            }
        } else {
            $fields = $this->resolver->fields($itemtype, [
                'id' => [2], 'date' => [15, 3], 'date_mod' => [19], 'users_id' => [5, 4], 'content' => [1], $parentFieldLogical => [7, 6, 13]
            ]);
            $idField = (int)($fields['id'] ?? 2);
            $parentField = (int)($fields[$parentFieldLogical] ?? 0);
            $dateField = (int)($fields['date_mod'] ?: $fields['date']);
            $userField = (int)$fields['users_id'];
            if ($parentField <= 0 || $dateField <= 0 || $userField <= 0) {
                return [];
            }
        }

        $parents = [];
        if (!$this->checkBudget('pesquisa ' . $itemtype)) {
            return [];
        }
        try {
            $criteria = [$this->crit($userField, 'equals', $agentId)];
            if ($dateField > 0) {
                $criteria[] = $this->crit($dateField, 'morethan', $start . ' 00:00:00', 'AND');
                $criteria[] = $this->crit($dateField, 'lessthan', $end . ' 23:59:59', 'AND');
            }
            if ($requiredItemtype !== '') {
                $itField = $risky ? $this->resolver->fieldStrict($itemtype, 'itemtype') : $this->resolver->field($itemtype, 'itemtype', [4]);
                if ($itField > 0) {
                    $criteria[] = $this->crit($itField, 'equals', $requiredItemtype, 'AND');
                }
            }
            $startAt = $this->rangeLimit > 0 ? $this->rangeStart : 0;
            $limit = $this->rangeLimit > 0 ? $this->rangeLimit : $this->candidateLimit;
            $range = $startAt . '-' . max($startAt, $startAt + $limit - 1);
            $res = $this->client->search($itemtype, $criteria, array_values(array_filter([$idField, $parentField])), $range);
            $rows = is_array($res['data'] ?? null) ? $res['data'] : [];
            $this->recordSearchMeta($itemtype . ':' . $parentFieldLogical, $res, count($rows), $startAt, $limit);
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $pid = (int)$this->rowVal($row, $parentField);
                if ($pid > 0) {
                    if (count($parents) >= $limit) { break; }
                    $parents[$pid] = $pid;
                }
            }
        } catch (\Throwable $e) {
            $this->warnings[] = 'Falha ao pesquisar atividades em ' . $itemtype . ': ' . $e->getMessage();
        }
        return array_values($parents);
    }

    private function resolveUserGroups(int $userId): array
    {
        $ids = [];
        foreach (['Group_User', 'Group'] as $sub) {
            if (!$this->checkBudget('resolução de grupos do usuário')) { break; }
            try {
                $rows = $this->client->getSubItems('User', $userId, $sub, ['expand_dropdowns' => false, 'get_hateoas' => false]);
                if (!is_array($rows)) continue;
                foreach ($rows as $row) {
                    if (!is_array($row)) continue;
                    foreach (['groups_id', 'id'] as $k) {
                        if (isset($row[$k]) && is_numeric($row[$k])) {
                            $ids[(int)$row[$k]] = true;
                        }
                    }
                }
                if (!empty($ids)) break;
            } catch (\Throwable $e) {
                // Try next route.
            }
        }
        return array_keys($ids);
    }

    private function resolveGroups(array $groupIds): array
    {
        $out = [];
        foreach ($groupIds as $gid) {
            if (!$this->checkBudget('resolução de nomes de grupos')) { break; }
            $gid = (int)$gid;
            if ($gid <= 0) continue;
            $name = 'Grupo ID ' . $gid;
            try {
                $item = $this->client->getItem('Group', $gid, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                $name = TextNormalizer::firstNonEmpty($item['name'] ?? '', $name);
            } catch (\Throwable $e) {
                // keep fallback
            }
            $out[$gid] = ['id' => $gid, 'name' => $name];
        }
        return $out;
    }

    private function safeSubitems(string $itemtype, int $id, string $subitemtype): array
    {
        $cacheKey = $itemtype . ':' . $id . ':' . $subitemtype;
        if (array_key_exists($cacheKey, $this->subitemCache)) {
            return $this->subitemCache[$cacheKey];
        }
        if (!$this->checkBudget('leitura de ' . $subitemtype)) {
            return $this->subitemCache[$cacheKey] = [];
        }
        try {
            // Keep this to one API call per parent/subitem. The previous fallback
            // attempted the expanded route after any failure, doubling calls on
            // unavailable subitems and contributing to 504s.
            $rows = $this->client->getSubItems($itemtype, $id, $subitemtype, [
                'expand_dropdowns' => false,
                'get_hateoas' => false,
                'range' => '0-' . ($this->subitemLimit - 1)
            ]);
            return $this->subitemCache[$cacheKey] = (is_array($rows) ? $rows : []);
        } catch (\Throwable $e) {
            return $this->subitemCache[$cacheKey] = [];
        }
    }

    private function projectHasUser(int $projectId, int $agentId): bool
    {
        if ($agentId <= 0) return true;
        foreach (['ProjectTeam', 'Project_User', 'ProjectTaskTeam'] as $sub) {
            if (!$this->checkBudget('verificação de equipe do projeto')) { break; }
            foreach ($this->safeSubitems('Project', $projectId, $sub) as $row) {
                if ($this->subitemBelongsToUser($row, $agentId)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function subitemBelongsToUser(array $row, int $userId): bool
    {
        if ($userId <= 0) return true;
        foreach (['users_id', 'users_id_tech', 'users_id_editor', 'users_id_recipient', 'users_id_validate', 'users_id_approval'] as $k) {
            if (!array_key_exists($k, $row)) {
                continue;
            }
            if ($this->valueMatchesUser($row[$k], $userId)) {
                return true;
            }
        }
        if (isset($row['items_id']) && isset($row['itemtype']) && strtolower((string)$row['itemtype']) === 'user') {
            return $this->valueMatchesUser($row['items_id'], $userId);
        }
        return false;
    }

    private function valueMatchesUser($value, int $userId): bool
    {
        if (is_array($value)) {
            foreach (['id', 'items_id', 'users_id'] as $key) {
                if (isset($value[$key]) && is_numeric($value[$key]) && (int)$value[$key] === $userId) {
                    return true;
                }
            }
            foreach (['name', 'completename', 'realname'] as $key) {
                if (isset($value[$key]) && $this->agentName !== '' && $this->sameText((string)$value[$key], $this->agentName)) {
                    return true;
                }
            }
            return false;
        }
        if (is_object($value)) {
            return $this->valueMatchesUser((array)$value, $userId);
        }
        if (is_numeric($value) && (int)$value === $userId) {
            return true;
        }
        return !is_numeric($value) && $this->agentName !== '' && $this->sameText((string)$value, $this->agentName);
    }

    private function subitemBelongsToAnyGroup(array $row, array $groupIds): bool
    {
        if (empty($groupIds)) return false;
        $map = array_flip(array_map('intval', $groupIds));
        foreach (['groups_id', 'groups_id_tech', 'groups_id_assign', 'groups_id_recipient'] as $k) {
            if (isset($row[$k]) && $this->valueMatchesAnyGroup($row[$k], $map)) {
                return true;
            }
        }
        if (isset($row['items_id']) && isset($row['itemtype']) && strtolower((string)$row['itemtype']) === 'group' && $this->valueMatchesAnyGroup($row['items_id'], $map)) {
            return true;
        }
        return false;
    }

    private function valueMatchesAnyGroup($value, array $groupMap): bool
    {
        if (is_array($value)) {
            foreach (['id', 'items_id', 'groups_id'] as $key) {
                if (isset($value[$key]) && is_numeric($value[$key]) && isset($groupMap[(int)$value[$key]])) {
                    return true;
                }
            }
            return false;
        }
        if (is_object($value)) {
            return $this->valueMatchesAnyGroup((array)$value, $groupMap);
        }
        return is_numeric($value) && isset($groupMap[(int)$value]);
    }

    private function addEntry(array &$entries, array &$seen, array $entry): void
    {
        if (count($entries) >= $this->maxItems) return;
        $key = implode('|', [
            $entry['source_type'] ?? '',
            $entry['source_itemtype'] ?? '',
            $entry['source_id'] ?? '',
            $entry['date'] ?? '',
            md5((string)($entry['title'] ?? '') . '|' . (string)($entry['activity_performed'] ?? ''))
        ]);
        if (isset($seen[$key])) {
            return;
        }
        $seen[$key] = true;
        $entries[] = $entry;
    }

    private function entry(array $data): array
    {
        $date = TextNormalizer::firstNonEmpty($data['date'] ?? '', date('Y-m-d'));
        $date = DateHelper::normalizeDate($date, date('Y-m-d'));
        return [
            'date' => $date,
            'source_type' => (string)($data['source_type'] ?? 'manual'),
            'source_itemtype' => (string)($data['source_itemtype'] ?? ''),
            'source_id' => (int)($data['source_id'] ?? 0),
            'source_reference' => TextNormalizer::clean($data['source_reference'] ?? '', $this->maskSensitive),
            'professional' => '',
            'title' => TextNormalizer::clean($data['title'] ?? 'Atividade', $this->maskSensitive),
            'status' => TextNormalizer::clean($data['status'] ?? '', $this->maskSensitive),
            'category' => TextNormalizer::clean($data['category'] ?? '', $this->maskSensitive),
            'activity_performed' => TextNormalizer::clean($data['activity_performed'] ?? '', $this->maskSensitive),
            'result' => TextNormalizer::clean($data['result'] ?? '', $this->maskSensitive),
            'next_steps' => TextNormalizer::clean($data['next_steps'] ?? '', $this->maskSensitive),
            'observations' => TextNormalizer::clean($data['observations'] ?? '', $this->maskSensitive),
            'include_in_report' => true
        ];
    }

    private function calculateMetrics(array $entries): array
    {
        $total = count($entries);
        $tickets = 0; $projects = 0; $tasks = 0; $closed = 0;
        foreach ($entries as $e) {
            $stype = (string)($e['source_type'] ?? '');
            if (strpos($stype, 'ticket') === 0) $tickets++;
            if (strpos($stype, 'project') === 0) $projects++;
            if (strpos($stype, 'task') !== false) $tasks++;
            $status = self::lower((string)($e['status'] ?? ''));
            if (preg_match('/fech|soluc|conclu|closed|solved|done/', $status)) $closed++;
        }
        $rate = $total > 0 ? round(($closed / $total) * 100, 1) : 0;
        return [
            ['key' => 'entries', 'label' => 'Entradas do relatório', 'value' => $total],
            ['key' => 'tickets', 'label' => 'Entradas de chamados', 'value' => $tickets],
            ['key' => 'projects', 'label' => 'Entradas de projetos', 'value' => $projects],
            ['key' => 'closed_rate', 'label' => 'Taxa de encerramento/conclusão', 'value' => $rate . '%']
        ];
    }

    private function groupByDay(array $entries): array
    {
        $groups = [];
        foreach ($entries as $entry) {
            if (empty($entry['include_in_report'])) continue;
            $date = (string)($entry['date'] ?? '');
            if ($date === '') $date = date('Y-m-d');
            if (!isset($groups[$date])) {
                $groups[$date] = ['date' => $date, 'display_date' => DateHelper::displayDate($date), 'entries' => []];
            }
            $groups[$date]['entries'][] = $entry;
        }
        ksort($groups);
        return array_values($groups);
    }

    private function validateDraft(array $entries, array $contexts, string $start, string $end): array
    {
        $out = [];
        if (empty($entries)) {
            $out[] = ['level' => 'warning', 'message' => 'Nenhuma atividade foi retornada pela API para o período e contextos selecionados. Verifique credenciais, campos de pesquisa e escopo do agente.'];
        }
        if (count($entries) > 80) {
            $out[] = ['level' => 'warning', 'message' => 'O rascunho possui mais de 80 entradas. Considere usar o relatório gerencial resumido e anexar evidência completa separadamente.'];
        }
        foreach ($entries as $idx => $entry) {
            if (!DateHelper::within((string)($entry['date'] ?? ''), $start, $end)) {
                $out[] = ['level' => 'warning', 'message' => 'Entrada fora do período selecionado: ' . (($entry['title'] ?? 'Atividade') ?: 'Atividade')];
                break;
            }
            if (trim((string)($entry['activity_performed'] ?? '')) === '') {
                $out[] = ['level' => 'warning', 'message' => 'Há entradas sem descrição de atividade realizada. Complete a narrativa antes do DOCX final.'];
                break;
            }
        }
        if (in_array('manual_entries', $contexts, true)) {
            $out[] = ['level' => 'info', 'message' => 'Contexto manual habilitado. Use o editor para adicionar atividades que não estejam bem representadas em tickets ou projetos.'];
        }
        return $out;
    }

    private function defaultExecutiveSummary(array $entries, string $agentName, string $start, string $end): string
    {
        $total = count($entries);
        return 'No período de ' . DateHelper::displayDate($start) . ' a ' . DateHelper::displayDate($end) . ', foram consolidadas ' . $total . ' entradas de atividade relacionadas a ' . $agentName . '. O rascunho combina registros extraídos da API do GLPI com espaço para complementações narrativas, permitindo revisão técnica antes da exportação em DOCX.';
    }

    private function resultFromStatus(string $status): string
    {
        $s = self::lower($status);
        if (preg_match('/fech|soluc|conclu|closed|solved|done/', $s)) {
            return 'Atividade registrada como concluída/solucionada no GLPI.';
        }
        if (preg_match('/pend|andamento|novo|process/', $s)) {
            return 'Atividade em acompanhamento, com continuidade conforme tratamento registrado.';
        }
        return '';
    }

    private function projectResult(array $item): string
    {
        $pct = TextNormalizer::firstNonEmpty($item['percent_done'] ?? '', $item['percent'] ?? '');
        if ($pct !== '') return 'Percentual de evolução registrado: ' . $pct . '.';
        return '';
    }

    private function projectTaskResult(array $task): string
    {
        $pct = TextNormalizer::firstNonEmpty($task['percent_done'] ?? '', $task['percent'] ?? '');
        if ($pct !== '') return 'Percentual de execução da tarefa: ' . $pct . '.';
        return '';
    }


    private function recordSearchMeta(string $source, array $res, int $returned, int $offset, int $limit): void
    {
        $total = 0;
        foreach (['totalcount', 'total_count', 'total', 'count'] as $k) {
            if (isset($res[$k]) && is_numeric($res[$k])) {
                $total = max($total, (int)$res[$k]);
            }
        }
        // GLPI normally provides totalcount. If it does not, infer enough to
        // let the browser continue while pages are full.
        if ($total <= 0) {
            $total = $offset + $returned;
            if ($limit > 0 && $returned >= $limit) {
                $total = $offset + $returned + 1;
            }
        }
        $this->sourceTotals[$source] = max((int)($this->sourceTotals[$source] ?? 0), $total);
        $this->sourceReturned[$source] = (int)($this->sourceReturned[$source] ?? 0) + $returned;
        if ($limit > 0 && $returned > 0 && ($offset + $returned) < $total) {
            $this->batchHasMore = true;
        }
    }

    private function batchTotalCandidates(): int
    {
        $total = 0;
        foreach ($this->sourceTotals as $value) {
            $total += (int)$value;
        }
        return $total;
    }

    private function checkBudget(string $stage = ''): bool
    {
        if ($this->startedAt <= 0) {
            return true;
        }
        if ((microtime(true) - $this->startedAt) <= $this->timeLimitSeconds) {
            return true;
        }
        if (!$this->budgetExceeded) {
            $this->budgetExceeded = true;
            $msg = 'Limite interno de tempo atingido';
            if ($stage !== '') {
                $msg .= ' durante: ' . $stage;
            }
            $this->warnings[] = $msg . '. A extração foi encerrada de forma controlada para evitar erro 504.';
        }
        return false;
    }

    private function requiresAgent(array $contexts): bool
    {
        foreach ($contexts as $ctx) {
            if (strpos($ctx, '_user') !== false || strpos($ctx, '_by_user') !== false || strpos($ctx, '_member_user') !== false) {
                return true;
            }
        }
        return false;
    }

    private function hasAny(array $contexts, array $needles): bool
    {
        foreach ($needles as $n) {
            if (in_array($n, $contexts, true)) return true;
        }
        return false;
    }

    private function crit(int $field, string $searchtype, $value, string $link = ''): array
    {
        $c = ['field' => $field, 'searchtype' => $searchtype, 'value' => (string)$value];
        if ($link !== '') $c['link'] = $link;
        return $c;
    }

    private function rowId(array $row): int
    {
        foreach (['2', 2, 'id', 'ID'] as $k) {
            if (isset($row[$k]) && is_numeric($row[$k])) return (int)$row[$k];
        }
        foreach ($row as $v) {
            if (is_numeric($v) && (int)$v > 0) return (int)$v;
        }
        return 0;
    }

    private function rowVal(array $row, int $field)
    {
        if ($field <= 0) return '';
        foreach ([(string)$field, $field] as $k) {
            if (array_key_exists($k, $row)) return $row[$k];
        }
        return '';
    }

    private function sameText(string $a, string $b): bool
    {
        $a = trim($a);
        $b = trim($b);
        if ($a === '' || $b === '') return false;
        $la = self::lower($a);
        $lb = self::lower($b);
        return $la === $lb || strpos($la, $lb) !== false || strpos($lb, $la) !== false;
    }

    private function parseIdList($raw): array
    {
        if (is_array($raw)) {
            $ids = [];
            foreach ($raw as $v) {
                $id = (int)$v;
                if ($id > 0) $ids[$id] = $id;
            }
            return array_values($ids);
        }
        $ids = [];
        foreach (preg_split('/[^0-9]+/', (string)$raw) as $p) {
            $id = (int)$p;
            if ($id > 0) $ids[$id] = $id;
        }
        return array_values($ids);
    }
    private static function lower(string $text): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
    }

}
