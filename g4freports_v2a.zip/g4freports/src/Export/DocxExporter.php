<?php

namespace GlpiPlugin\G4freports\Export;

use GlpiPlugin\G4freports\Util\DateHelper;
use GlpiPlugin\G4freports\Util\TextNormalizer;

class DocxExporter
{
    private string $navy = '002B49';
    private string $blue = '2F6FED';
    private string $teal = '188DA1';
    private string $light = 'EAF1F8';
    private string $border = 'B8C7D9';
    private string $yellow = 'FFF4CC';
    private string $green = 'E9F7EF';

    public function __construct(string $unusedLogoPath = '')
    {
        // Kept for backward compatibility with older export.php calls.
        // v0.5 renders the G4F identity with editable Word text/tables/shading,
        // not by inserting binary images into the document body.
    }

    public function toBinary(array $draft): string
    {
        $files = [
            '[Content_Types].xml' => $this->contentTypesXml(),
            '_rels/.rels' => $this->rootRelsXml(),
            'docProps/core.xml' => $this->coreXml($draft),
            'docProps/app.xml' => $this->appXml(),
            'word/document.xml' => $this->documentXml($draft),
            'word/_rels/document.xml.rels' => $this->documentRelsXml(),
            'word/styles.xml' => $this->stylesXml(),
            'word/settings.xml' => $this->settingsXml(),
            'word/header1.xml' => $this->headerXml(),
            'word/footer1.xml' => $this->footerXml((string)($draft['footer'] ?? '')),
        ];
        return $this->zipStore($files);
    }

    public function filename(array $draft): string
    {
        $title = (string)($draft['report_title'] ?? 'relatorio-g4f');
        $subject = (string)($draft['subject']['name'] ?? 'profissional');
        $template = (string)($draft['template'] ?? 'operational');
        $period = (string)($draft['period_start'] ?? '') . '_' . (string)($draft['period_end'] ?? '');
        $base = $title . '-' . $template . '-' . $subject . '-' . $period;
        $base = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base) ?: $base;
        $base = preg_replace('/[^A-Za-z0-9_\-]+/', '-', $base) ?? $base;
        $base = trim($base, '-_');
        if ($base === '') {
            $base = 'relatorio-g4f';
        }
        return substr($base, 0, 140) . '.docx';
    }

    private function documentXml(array $draft): string
    {
        $body = [];
        $body[] = $this->coverPage($draft);
        $body[] = $this->pageBreak();

        $template = (string)($draft['template'] ?? 'operational');
        switch ($template) {
            case 'formal_managerial':
                $body[] = $this->formalManagerialBody($draft);
                break;
            case 'project_technical':
                $body[] = $this->projectTechnicalBody($draft);
                break;
            case 'annex_full':
                $body[] = $this->annexFullBody($draft);
                break;
            case 'operational':
            default:
                $body[] = $this->operationalBody($draft);
                break;
        }

        $sectPr = '<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader"/><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<w:background w:color="FFFFFF"/><w:body>' . implode('', $body) . $sectPr . '</w:body></w:document>';
    }

    private function coverPage(array $draft): string
    {
        $title = (string)($draft['report_title'] ?? 'Relatório Gerencial de Atividades');
        $subject = (string)($draft['subject']['name'] ?? 'Profissional não informado');
        $period = DateHelper::displayDate((string)($draft['period_start'] ?? '')) . ' a ' . DateHelper::displayDate((string)($draft['period_end'] ?? ''));
        $subtitleParts = array_filter([
            (string)($draft['contract_label'] ?? ''),
            (string)($draft['connection']['name'] ?? 'GLPI'),
            $this->templateLabel((string)($draft['template'] ?? 'operational'))
        ], static fn($v) => trim((string)$v) !== '');

        $xml = '';
        $xml .= $this->brandMark(28, 'left');
        $xml .= $this->spacer(22);
        $xml .= $this->paragraph($title, 'Title', 'center', true, 48, $this->navy);
        $xml .= $this->paragraph(implode(' • ', $subtitleParts), '', 'center', false, 22, '666666');
        $xml .= $this->spacer(10);
        $xml .= $this->paragraph('Profissional responsável: ' . $subject, '', 'center', false, 22, '666666');
        $xml .= $this->paragraph('Período: ' . $period, '', 'center', false, 22, '666666');
        $xml .= $this->spacer(12);
        $xml .= $this->metricCards($draft['metrics'] ?? []);
        $xml .= $this->callout('Leitura recomendada', 'Este documento é um rascunho normalizado gerado a partir da API do GLPI e de complementações narrativas. Revise as atividades, status, comentários extraídos e pendências antes da versão final.', 'DCEBFF', $this->blue);
        $xml .= $this->spacer(18);
        $xml .= $this->paragraph('Data de emissão: ' . date('d/m/Y'), '', 'center', false, 20, '666666');
        $xml .= $this->spacer(26);
        $xml .= $this->decorativeStripes();
        return $xml;
    }

    private function operationalBody(array $draft): string
    {
        $subject = (string)($draft['subject']['name'] ?? 'Profissional responsável');
        $xml = '';
        $xml .= $this->heading('Sumário executivo', 1);
        $xml .= $this->blockParagraphs((string)($draft['executive_summary'] ?? ''), 22);
        $xml .= $this->heading('1. Abrangência', 1);
        $xml .= $this->blockParagraphs((string)($draft['scope_text'] ?? ''), 22);
        $xml .= $this->heading('2. Objetivo', 1);
        $xml .= $this->blockParagraphs((string)($draft['objective_text'] ?? ''), 22);
        $xml .= $this->heading('3. Indicadores consolidados', 1);
        $xml .= $this->indicatorTable($draft['metrics'] ?? []);
        $xml .= $this->validationsBlock($draft);
        $xml .= $this->heading('4. Detalhamento diário', 1);
        $xml .= $this->dailyDetail($draft, false);
        $xml .= $this->heading('5. Pendências e próximos passos', 1);
        $xml .= $this->blockParagraphs($this->collectNextSteps($draft) ?: 'Não foram registradas pendências específicas no rascunho. Complementar manualmente, caso aplicável.', 22);
        $xml .= $this->heading('6. Conclusão', 1);
        $xml .= $this->blockParagraphs((string)($draft['conclusion_text'] ?? 'As atividades foram consolidadas em formato padronizado para facilitar conferência, ajuste narrativo e envio gerencial. O documento deve ser revisado pelo responsável antes da formalização.'), 22);
        $xml .= $this->signatureBlock($subject);
        return $xml;
    }

    private function formalManagerialBody(array $draft): string
    {
        $subject = (string)($draft['subject']['name'] ?? 'Profissional responsável');
        $xml = '';
        $xml .= $this->heading('Sumário executivo', 1);
        $xml .= $this->blockParagraphs((string)($draft['executive_summary'] ?? ''), 22);
        $xml .= $this->callout('Regra de leitura gerencial', 'O relatório formal prioriza resultado, rastreabilidade e pendências. Detalhes integrais de chamados, tarefas e acompanhamentos devem permanecer no rascunho ou no anexo evidencial quando necessário.', $this->yellow, 'D39E00');
        $xml .= $this->heading('1. Principais entregas do período', 1);
        $xml .= $this->deliveriesTable($draft, 12);
        $xml .= $this->heading('2. Indicadores consolidados', 1);
        $xml .= $this->indicatorTable($draft['metrics'] ?? []);
        $xml .= $this->heading('3. Atividades por origem', 1);
        $xml .= $this->sourceSummaryTable($draft);
        $xml .= $this->heading('4. Riscos, pendências e encaminhamentos', 1);
        $xml .= $this->blockParagraphs($this->riskAndPendingText($draft), 22);
        $xml .= $this->heading('5. Detalhamento sintético por dia', 1);
        $xml .= $this->dailyDetail($draft, true);
        $xml .= $this->heading('6. Conclusão executiva', 1);
        $xml .= $this->blockParagraphs((string)($draft['conclusion_text'] ?? 'O período foi consolidado com foco em padronização das evidências, rastreabilidade das ações executadas e identificação de pendências para continuidade operacional.'), 22);
        $xml .= $this->signatureBlock($subject);
        return $xml;
    }

    private function projectTechnicalBody(array $draft): string
    {
        $subject = (string)($draft['subject']['name'] ?? 'Profissional responsável');
        $xml = '';
        $xml .= $this->heading('Sumário executivo técnico', 1);
        $xml .= $this->blockParagraphs((string)($draft['executive_summary'] ?? ''), 22);
        $xml .= $this->heading('1. Contexto e escopo técnico', 1);
        $xml .= $this->blockParagraphs((string)($draft['scope_text'] ?? ''), 22);
        $xml .= $this->heading('2. Objetivo', 1);
        $xml .= $this->blockParagraphs((string)($draft['objective_text'] ?? ''), 22);
        $xml .= $this->heading('3. Projetos, chamados e tarefas relacionadas', 1);
        $xml .= $this->sourceSummaryTable($draft);
        $xml .= $this->heading('4. Atividades técnicas executadas', 1);
        $xml .= $this->dailyDetail($draft, false);
        $xml .= $this->heading('5. Decisões, pendências e próximos passos', 1);
        $xml .= $this->blockParagraphs($this->collectNextSteps($draft) ?: 'Não foram registradas pendências específicas. Complementar decisões técnicas e próximos passos, caso aplicável.', 22);
        $xml .= $this->heading('6. Validações do rascunho', 1);
        $xml .= $this->validationsBlock($draft) ?: $this->paragraph('Nenhuma validação relevante registrada.', '', 'left', false, 22, '333333');
        $xml .= $this->heading('7. Conclusão técnica', 1);
        $xml .= $this->blockParagraphs((string)($draft['conclusion_text'] ?? 'As ações técnicas foram consolidadas a partir dos registros relacionados ao profissional, aos grupos e aos projetos selecionados. Recomenda-se revisão final para incluir decisões técnicas que não estejam refletidas no GLPI.'), 22);
        $xml .= $this->signatureBlock($subject);
        return $xml;
    }

    private function annexFullBody(array $draft): string
    {
        $xml = '';
        $xml .= $this->heading('Anexo evidencial completo', 1);
        $xml .= $this->blockParagraphs('Este anexo mantém o detalhamento integral das entradas incluídas no rascunho. Use este modelo quando a prioridade for evidência e rastreabilidade, não síntese gerencial.', 22);
        $xml .= $this->heading('1. Metadados do rascunho', 1);
        $xml .= $this->simpleTable(['Campo', 'Valor'], [
            ['Modelo', $this->templateLabel((string)($draft['template'] ?? 'annex_full'))],
            ['Profissional', (string)($draft['subject']['name'] ?? '')],
            ['Período', DateHelper::displayDate((string)($draft['period_start'] ?? '')) . ' a ' . DateHelper::displayDate((string)($draft['period_end'] ?? ''))],
            ['Conexão', (string)($draft['connection']['name'] ?? '')],
            ['Contextos', implode(', ', is_array($draft['contexts'] ?? null) ? $draft['contexts'] : [])],
        ]);
        $xml .= $this->heading('2. Indicadores', 1);
        $xml .= $this->indicatorTable($draft['metrics'] ?? []);
        $xml .= $this->heading('3. Evidências por data', 1);
        $xml .= $this->dailyDetail($draft, false, true);
        return $xml;
    }

    private function dailyDetail(array $draft, bool $compact = false, bool $annex = false): string
    {
        $daily = $this->dailyGroups($draft);
        if (empty($daily)) {
            return $this->paragraph('Nenhuma entrada foi incluída no relatório para o período selecionado.', '', 'left', false, 22, '333333');
        }
        $xml = '';
        foreach ($daily as $group) {
            $xml .= $this->heading(DateHelper::displayDate((string)$group['date']), 2);
            if ($compact) {
                $rows = [];
                foreach ($group['entries'] as $entry) {
                    $rows[] = [
                        (string)($entry['source_reference'] ?? ''),
                        (string)($entry['title'] ?? ''),
                        (string)($entry['status'] ?? ''),
                        TextNormalizer::summarize((string)($entry['activity_performed'] ?? ''), 260),
                    ];
                }
                $xml .= $this->simpleTable(['Referência', 'Atividade', 'Status', 'Síntese'], $rows);
                continue;
            }
            foreach ($group['entries'] as $entry) {
                $xml .= $this->entryBlock($entry, $annex);
            }
        }
        return $xml;
    }

    private function dailyGroups(array $draft): array
    {
        $groups = [];
        foreach ($this->entries($draft) as $entry) {
            $date = DateHelper::normalizeDate((string)($entry['date'] ?? ''), date('Y-m-d'));
            if (!isset($groups[$date])) {
                $groups[$date] = ['date' => $date, 'entries' => []];
            }
            $groups[$date]['entries'][] = $entry;
        }
        ksort($groups);
        return array_values($groups);
    }

    private function entries(array $draft): array
    {
        $entries = is_array($draft['entries'] ?? null) ? $draft['entries'] : [];
        return array_values(array_filter($entries, static fn($entry) => is_array($entry) && !empty($entry['include_in_report'])));
    }

    private function entryBlock(array $entry, bool $annex = false): string
    {
        $title = (string)($entry['title'] ?? 'Atividade');
        $ref = trim((string)($entry['source_reference'] ?? ''));
        $status = trim((string)($entry['status'] ?? ''));
        $category = trim((string)($entry['category'] ?? ''));
        $meta = [];
        if ($ref !== '') $meta[] = $ref;
        if ($status !== '') $meta[] = 'Status: ' . $status;
        if ($category !== '') $meta[] = 'Categoria: ' . $category;
        if ($annex) {
            $meta[] = 'Origem: ' . (string)($entry['source_type'] ?? '');
            if (!empty($entry['source_itemtype'])) $meta[] = 'Itemtype: ' . (string)$entry['source_itemtype'];
            if (!empty($entry['source_id'])) $meta[] = 'ID origem: ' . (int)$entry['source_id'];
        }

        $xml = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders($this->border) . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid>';
        $xml .= '<w:tr><w:tc><w:tcPr><w:shd w:fill="' . $this->light . '"/><w:tcW w:w="9500" w:type="dxa"/></w:tcPr>';
        $xml .= $this->paragraph($title, '', 'left', true, 22, $this->navy);
        if (!empty($meta)) {
            $xml .= $this->paragraph(implode(' | ', $meta), '', 'left', false, 18, '666666');
        }
        $xml .= '</w:tc></w:tr>';
        $xml .= '<w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/></w:tcPr>';
        $xml .= $this->labelAndBlock('Atividades realizadas', (string)($entry['activity_performed'] ?? ''));
        $xml .= $this->labelAndBlock('Resultado', (string)($entry['result'] ?? ''));
        if (trim((string)($entry['next_steps'] ?? '')) !== '') {
            $xml .= $this->labelAndBlock('Plano de tratamento / próximos passos', (string)$entry['next_steps']);
        }
        if (trim((string)($entry['observations'] ?? '')) !== '') {
            $xml .= $this->labelAndBlock('Observações', (string)$entry['observations']);
        }
        $xml .= '</w:tc></w:tr></w:tbl>';
        return $xml . $this->spacer(4);
    }

    private function labelAndBlock(string $label, string $text): string
    {
        $text = trim($text);
        if ($text === '') return '';
        return $this->paragraph($label, '', 'left', true, 20, $this->navy) . $this->blockParagraphs($text, 20);
    }

    private function deliveriesTable(array $draft, int $limit): string
    {
        $rows = [];
        foreach (array_slice($this->entries($draft), 0, $limit) as $entry) {
            $rows[] = [
                DateHelper::displayDate((string)($entry['date'] ?? '')),
                (string)($entry['source_reference'] ?? ''),
                (string)($entry['title'] ?? ''),
                TextNormalizer::summarize(TextNormalizer::firstNonEmpty($entry['result'] ?? '', $entry['activity_performed'] ?? ''), 240),
            ];
        }
        if (empty($rows)) {
            $rows[] = ['-', '-', 'Sem entregas extraídas', 'Complementar manualmente se necessário.'];
        }
        return $this->simpleTable(['Data', 'Referência', 'Entrega/atividade', 'Resultado'], $rows);
    }

    private function sourceSummaryTable(array $draft): string
    {
        $counts = [];
        foreach ($this->entries($draft) as $entry) {
            $src = (string)($entry['source_type'] ?? 'manual');
            if ($src === '') $src = 'manual';
            $counts[$src] = ($counts[$src] ?? 0) + 1;
        }
        $rows = [];
        foreach ($counts as $src => $count) {
            $rows[] = [$this->sourceLabel($src), (string)$count];
        }
        if (empty($rows)) $rows[] = ['Sem entradas', '0'];
        return $this->simpleTable(['Origem', 'Quantidade'], $rows);
    }

    private function riskAndPendingText(array $draft): string
    {
        $lines = [];
        $next = $this->collectNextSteps($draft);
        if ($next !== '') {
            $lines[] = $next;
        }
        foreach (($draft['validations'] ?? []) as $validation) {
            if (!is_array($validation)) continue;
            $lines[] = '• ' . strtoupper((string)($validation['level'] ?? 'info')) . ': ' . (string)($validation['message'] ?? '');
        }
        foreach (($draft['warnings'] ?? []) as $warning) {
            $lines[] = '• ALERTA: ' . (string)$warning;
        }
        return implode("\n", $lines) ?: 'Não foram identificadas pendências ou riscos automáticos no rascunho. Complementar manualmente, caso existam riscos operacionais fora do GLPI.';
    }

    private function collectNextSteps(array $draft): string
    {
        $lines = [];
        foreach ($this->entries($draft) as $entry) {
            $next = trim((string)($entry['next_steps'] ?? ''));
            if ($next !== '') {
                $lines[] = '• ' . ((string)($entry['title'] ?? 'Atividade')) . ': ' . $next;
            }
        }
        return implode("\n", array_slice($lines, 0, 50));
    }

    private function validationsBlock(array $draft): string
    {
        $txt = [];
        foreach (($draft['validations'] ?? []) as $validation) {
            if (!is_array($validation)) continue;
            $txt[] = strtoupper((string)($validation['level'] ?? 'info')) . ': ' . (string)($validation['message'] ?? '');
        }
        foreach (($draft['warnings'] ?? []) as $warning) {
            $txt[] = 'ALERTA: ' . (string)$warning;
        }
        if (empty($txt)) return '';
        return $this->callout('Validações do rascunho', implode("\n", $txt), $this->yellow, 'D39E00');
    }

    private function metricCards(array $metrics): string
    {
        if (empty($metrics)) return '';
        $cells = '';
        $count = 0;
        foreach (array_slice($metrics, 0, 4) as $metric) {
            if (!is_array($metric)) continue;
            $count++;
            $fill = $count === 3 ? $this->teal : $this->navy;
            $cells .= '<w:tc><w:tcPr><w:tcW w:w="2375" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>';
            $cells .= $this->paragraph((string)($metric['value'] ?? ''), '', 'center', true, 32, 'FFFFFF');
            $cells .= $this->paragraph((string)($metric['label'] ?? ''), '', 'center', false, 16, 'FFFFFF');
            $cells .= '</w:tc>';
        }
        while ($count < 4) {
            $count++;
            $cells .= '<w:tc><w:tcPr><w:tcW w:w="2375" w:type="dxa"/><w:shd w:fill="' . $this->navy . '"/></w:tcPr>' . $this->paragraph('-', '', 'center', true, 32, 'FFFFFF') . '</w:tc>';
        }
        return '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders('FFFFFF') . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/></w:tblGrid><w:tr>' . $cells . '</w:tr></w:tbl>' . $this->spacer(8);
    }

    private function indicatorTable(array $metrics): string
    {
        $rows = [];
        foreach ($metrics as $metric) {
            if (is_array($metric)) {
                $rows[] = [(string)($metric['label'] ?? ''), (string)($metric['value'] ?? '')];
            }
        }
        if (empty($rows)) $rows[] = ['Sem indicadores', '-'];
        return $this->simpleTable(['Indicador', 'Valor'], $rows);
    }

    private function simpleTable(array $headers, array $rows): string
    {
        $colCount = max(1, count($headers));
        $width = (int)floor(9500 / $colCount);
        $grid = '';
        foreach ($headers as $_) $grid .= '<w:gridCol w:w="' . $width . '"/>';
        $xml = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders($this->border) . '</w:tblBorders></w:tblPr><w:tblGrid>' . $grid . '</w:tblGrid>';
        $xml .= '<w:tr>';
        foreach ($headers as $head) {
            $xml .= $this->cell((string)$head, $this->navy, 'FFFFFF', true, $width);
        }
        $xml .= '</w:tr>';
        foreach ($rows as $row) {
            $xml .= '<w:tr>';
            for ($i = 0; $i < $colCount; $i++) {
                $xml .= $this->cell((string)($row[$i] ?? ''), 'FFFFFF', '222222', false, $width);
            }
            $xml .= '</w:tr>';
        }
        return $xml . '</w:tbl>' . $this->spacer(6);
    }

    private function cell(string $text, string $fill, string $color, bool $bold, int $width = 4750): string
    {
        return '<w:tc><w:tcPr><w:tcW w:w="' . (int)$width . '" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>' . $this->blockParagraphs($text, 18, $color, $bold, 'center') . '</w:tc>';
    }

    private function signatureBlock(string $subject): string
    {
        $xml = $this->spacer(24);
        $xml .= $this->paragraph('________________________________________', '', 'center', false, 20, '333333');
        $xml .= $this->paragraph($subject, '', 'center', true, 20, '333333');
        $xml .= $this->paragraph('Profissional responsável', '', 'center', false, 18, '666666');
        return $xml;
    }

    private function callout(string $title, string $text, string $fill, string $accent): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders($accent) . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>';
        $xml .= $this->paragraph($title, '', 'left', true, 20, $this->navy);
        $xml .= $this->blockParagraphs($text, 18);
        $xml .= '</w:tc></w:tr></w:tbl>' . $this->spacer(8);
        return $xml;
    }

    private function decorativeStripes(): string
    {
        $cells = '';
        for ($i = 0; $i < 7; $i++) {
            $cells .= '<w:tc><w:tcPr><w:tcW w:w="170" w:type="dxa"/><w:shd w:fill="' . ($i % 2 === 0 ? $this->blue : '8CC2FF') . '"/></w:tcPr>' . $this->paragraph('', '', 'center', false, 4, 'FFFFFF') . '</w:tc>';
        }
        return '<w:tbl><w:tblPr><w:tblW w:w="1190" w:type="dxa"/><w:jc w:val="left"/><w:tblBorders>' . $this->borders('FFFFFF') . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="170"/><w:gridCol w:w="170"/><w:gridCol w:w="170"/><w:gridCol w:w="170"/><w:gridCol w:w="170"/><w:gridCol w:w="170"/><w:gridCol w:w="170"/></w:tblGrid><w:tr>' . $cells . '</w:tr></w:tbl>';
    }

    private function brandMark(int $size = 24, string $align = 'left'): string
    {
        return $this->paragraph('◆ G4F', '', $align, true, $size, $this->navy);
    }

    private function heading(string $text, int $level): string
    {
        $style = $level === 1 ? 'Heading1' : 'Heading2';
        $size = $level === 1 ? 34 : 26;
        $color = $level === 1 ? $this->navy : $this->blue;
        return $this->paragraph($text, $style, 'left', false, $size, $color);
    }

    private function blockParagraphs(string $text, int $size = 22, string $color = '333333', bool $bold = false, string $align = 'left'): string
    {
        $text = TextNormalizer::clean($text, false);
        if ($text === '') {
            return $this->paragraph('', '', $align, $bold, $size, $color);
        }
        $out = [];
        foreach (preg_split('/\n+/', $text) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (preg_match('/^[•\-*]\s*(.+)$/u', $line, $m)) {
                $out[] = $this->paragraph('• ' . $m[1], '', $align, $bold, $size, $color);
            } else {
                $out[] = $this->paragraph($line, '', $align, $bold, $size, $color);
            }
        }
        return implode('', $out);
    }

    private function paragraph(string $text, string $style = '', string $align = 'left', bool $bold = false, int $size = 22, string $color = '333333'): string
    {
        $pPr = '';
        if ($style !== '') {
            $pPr .= '<w:pStyle w:val="' . $this->x($style) . '"/>';
        }
        if ($align !== '') {
            $pPr .= '<w:jc w:val="' . $this->x($align) . '"/>';
        }
        $pPr .= '<w:spacing w:after="120" w:line="276" w:lineRule="auto"/>';
        $rPr = '<w:rPr>' . ($bold ? '<w:b/>' : '') . '<w:sz w:val="' . (int)$size . '"/><w:szCs w:val="' . (int)$size . '"/><w:color w:val="' . $this->x($color) . '"/></w:rPr>';
        return '<w:p><w:pPr>' . $pPr . '</w:pPr><w:r>' . $rPr . '<w:t xml:space="preserve">' . $this->x($text) . '</w:t></w:r></w:p>';
    }

    private function spacer(int $after): string
    {
        return '<w:p><w:pPr><w:spacing w:after="' . (int)($after * 20) . '"/></w:pPr></w:p>';
    }

    private function pageBreak(): string
    {
        return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
    }

    private function borders(string $color): string
    {
        return '<w:top w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:left w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:right w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/>';
    }

    private function headerXml(): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders><w:bottom w:val="single" w:sz="6" w:space="0" w:color="' . $this->light . '"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="4750"/><w:gridCol w:w="4750"/></w:tblGrid><w:tr>';
        $xml .= '<w:tc><w:tcPr><w:tcW w:w="4750" w:type="dxa"/></w:tcPr>' . $this->brandMark(22, 'left') . '</w:tc>';
        $xml .= '<w:tc><w:tcPr><w:tcW w:w="4750" w:type="dxa"/></w:tcPr>' . $this->paragraph('Relatórios G4F', '', 'right', false, 16, '666666') . '</w:tc>';
        $xml .= '</w:tr></w:tbl>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' . $xml . '</w:hdr>';
    }

    private function footerXml(string $footer): string
    {
        $footer = trim($footer) ?: 'Brasília - DF, 70712-900 | SCN Q 2 BL A - Asa Norte, Corporate Financial Center | contato@g4f.com.br | www.g4f.com.br';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="14"/><w:color w:val="666666"/></w:rPr><w:t xml:space="preserve">' . $this->x($footer) . '</w:t></w:r></w:p></w:ftr>';
    }

    private function documentRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdHeader" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/><Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>';
    }

    private function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';
    }

    private function contentTypesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';
    }

    private function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:jc w:val="center"/><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="48"/><w:color w:val="' . $this->navy . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr><w:rPr><w:sz w:val="34"/><w:color w:val="' . $this->navy . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="180" w:after="80"/></w:pPr><w:rPr><w:b/><w:sz w:val="26"/><w:color w:val="' . $this->blue . '"/></w:rPr></w:style></w:styles>';
    }

    private function settingsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:zoom w:percent="100"/><w:defaultTabStop w:val="708"/></w:settings>';
    }

    private function coreXml(array $draft): string
    {
        $title = (string)($draft['report_title'] ?? 'Relatório G4F');
        $created = date('c');
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' . $this->x($title) . '</dc:title><dc:creator>Relatórios G4F</dc:creator><cp:lastModifiedBy>Relatórios G4F</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:modified></cp:coreProperties>';
    }

    private function appXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Relatórios G4F</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company>G4F</Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.6.0</AppVersion></Properties>';
    }

    private function templateLabel(string $template): string
    {
        return [
            'operational' => 'Operacional diário/mensal',
            'formal_managerial' => 'Gerencial formal',
            'project_technical' => 'Técnico/projeto',
            'annex_full' => 'Anexo evidencial completo',
        ][$template] ?? 'Operacional diário/mensal';
    }

    private function sourceLabel(string $source): string
    {
        return [
            'ticket' => 'Chamado',
            'ticket_task' => 'Tarefa de chamado',
            'ticket_followup' => 'Acompanhamento de chamado',
            'ticket_solution' => 'Solução de chamado',
            'project' => 'Projeto',
            'project_task' => 'Tarefa de projeto',
            'manual' => 'Entrada manual',
        ][$source] ?? $source;
    }

    private function zipStore(array $files): string
    {
        $local = '';
        $central = '';
        $offset = 0;
        $count = 0;
        foreach ($files as $name => $content) {
            $name = str_replace('\\', '/', (string)$name);
            $content = (string)$content;
            $crc = crc32($content);
            if ($crc < 0) {
                $crc += 4294967296;
            }
            $size = strlen($content);
            $time = 0;
            $date = 0;
            $nameLen = strlen($name);
            $localHeader = pack('VvvvvvVVVvv', 0x04034b50, 20, 0, 0, $time, $date, $crc, $size, $size, $nameLen, 0) . $name;
            $local .= $localHeader . $content;
            $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0, 0, $time, $date, $crc, $size, $size, $nameLen, 0, 0, 0, 0, 0, $offset) . $name;
            $offset += strlen($localHeader) + $size;
            $count++;
        }
        $end = pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($central), strlen($local), 0);
        return $local . $central . $end;
    }

    private function x($value): string
    {
        return htmlspecialchars((string)$value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }
}
