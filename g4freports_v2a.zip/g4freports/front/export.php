<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Export\DocxExporter;


$cfg = Config::merged();
if (!Security::canUse($cfg)) {
    http_response_code(403);
    echo 'Acesso negado';
    exit;
}

$raw = $_POST['draft_json'] ?? file_get_contents('php://input');
if (is_array($raw)) {
    $raw = reset($raw);
}
$draft = json_decode((string)$raw, true);
if (!is_array($draft)) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Rascunho JSON inválido.';
    exit;
}

$exporter = new DocxExporter();
$binary = $exporter->toBinary($draft);
$filename = $exporter->filename($draft);

header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $filename) . '"');
header('Content-Length: ' . strlen($binary));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
echo $binary;
exit;
