<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;

if (class_exists('Session')) {
    Session::checkLoginUser();
}

$cfg = Config::merged();
if (!Security::canUse($cfg)) {
    if (class_exists('Html')) {
        Html::displayRightError();
    }
    http_response_code(403);
    exit;
}

$profiles = Config::profilesForCurrentUser($cfg);
if (empty($profiles)) {
    if (class_exists('Html')) { Html::displayRightError(); }
    http_response_code(403);
    exit;
}

if (class_exists('Html')) {
    Html::header(__('Relatórios G4F', 'g4freports'), $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu');
}
$css = dirname(__DIR__) . '/assets/css/g4freports.css';
$js  = dirname(__DIR__) . '/assets/js/report.js';
?>
<style><?php if (is_file($css)) { readfile($css); } ?></style>
<div class="g4fr-wrap">
  <div class="g4fr-header">
    <div>
      <h1>Relatórios G4F</h1>
      <p>Gerador API-first de rascunhos editáveis com múltiplos contextos, narrativa manual e exportação DOCX.</p>
    </div>
    <div class="g4fr-step-note">
      <strong>Uso operacional</strong><br>
      Escolha o profissional, marque os contextos necessários, gere o rascunho, revise as entradas e exporte o DOCX.
    </div>
  </div>

  <div class="g4fr-card">
    <h2>1. Profissional, período e modelo</h2>
    <form id="g4fr-form">
      <div class="g4fr-grid">
        <div class="g4fr-field">
          <label>Conexão GLPI</label>
          <select name="profile_id" id="g4fr-profile" class="form-select">
            <?php foreach ($profiles as $id => $profile): ?>
              <option value="<?php echo htmlspecialchars($id, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $id === '__default__' ? 'selected' : ''; ?>><?php echo htmlspecialchars((string)($profile['name'] ?? $id), ENT_QUOTES, 'UTF-8'); ?></option>
            <?php endforeach; ?>
          </select>
          <small>Perfis liberados pela configuração administrativa.</small>
        </div>

        <div class="g4fr-field">
          <label>Pesquisar agente</label>
          <div class="input-group">
            <input type="text" id="g4fr-agent-search-q" class="form-control" placeholder="Nome, login ou parte do nome">
            <button type="button" id="g4fr-agent-search-btn" class="btn btn-outline-secondary">Buscar</button>
          </div>
          <div id="g4fr-agent-results" class="g4fr-search-results" style="display:none"></div>
        </div>

        <div class="g4fr-field">
          <label>ID do agente principal</label>
          <input type="number" name="agent_id" id="g4fr-agent-id" class="form-control" placeholder="Ex.: 20744" min="1">
        </div>

        <div class="g4fr-field">
          <label>Nome do agente</label>
          <input type="text" name="agent_name" id="g4fr-agent-name" class="form-control" placeholder="Preenchido pela busca ou manualmente">
        </div>

        <div class="g4fr-field">
          <label>Início</label>
          <input type="date" name="period_start" id="g4fr-start" class="form-control" value="<?php echo date('Y-m-01'); ?>">
        </div>

        <div class="g4fr-field">
          <label>Fim</label>
          <input type="date" name="period_end" id="g4fr-end" class="form-control" value="<?php echo date('Y-m-t'); ?>">
        </div>

        <div class="g4fr-field">
          <label>Modelo DOCX</label>
          <select name="template" id="g4fr-template" class="form-select">
            <option value="operational">Operacional diário/mensal</option>
            <option value="formal_managerial">Gerencial formal</option>
            <option value="project_technical">Técnico/projeto</option>
            <option value="annex_full">Anexo evidencial completo</option>
          </select>
        </div>

        <div class="g4fr-field g4fr-full">
          <label>Grupos adicionais</label>
          <div class="input-group">
            <input type="text" id="g4fr-group-search-q" class="form-control" placeholder="Nome do grupo ou ID">
            <button type="button" id="g4fr-group-search-btn" class="btn btn-outline-secondary">Buscar grupo</button>
          </div>
          <div id="g4fr-group-results" class="g4fr-search-results" style="display:none"></div>
          <div id="g4fr-selected-groups" class="g4fr-selected-list"></div>
          <input type="hidden" name="group_ids" id="g4fr-group-ids" value="">
          <small>Opcional. Pesquise pelo nome ou ID. Contextos por grupo usam somente os grupos escolhidos aqui; não há fallback automático para grupos do agente.</small>
        </div>
      </div>
    </form>
  </div>

  <div class="g4fr-card">
    <h2>2. Contextos incluídos no rascunho</h2>
    <p class="g4fr-muted">Marque quantos contextos forem necessários. O agente principal é a âncora. Contextos por grupo só usam os grupos selecionados no campo acima e são processados em lotes para evitar timeout.</p>
    <div class="g4fr-context-toolbar">
      <button type="button" class="btn btn-outline-secondary btn-sm" data-context-preset="operational">Operacional</button>
      <button type="button" class="btn btn-outline-secondary btn-sm" data-context-preset="project">Projeto</button>
      <button type="button" class="btn btn-outline-secondary btn-sm" data-context-preset="all">Marcar todos</button>
      <button type="button" class="btn btn-outline-secondary btn-sm" data-context-preset="none">Limpar</button>
    </div>
    <div class="g4fr-contexts" id="g4fr-contexts">
      <div class="g4fr-context-section">
        <h3>Chamados</h3>
        <label><input type="checkbox" value="tickets_assigned_user" checked> Chamados atribuídos ao agente</label>
        <label><input type="checkbox" value="tickets_requested_by_user"> Chamados solicitados pelo agente</label>
        <label><input type="checkbox" value="tickets_assigned_groups"> Chamados atribuídos aos grupos selecionados</label>
      </div>
      <div class="g4fr-context-section">
        <h3>Atividades em chamados</h3>
        <label><input type="checkbox" value="ticket_tasks_by_user" checked> Tarefas feitas pelo agente</label>
        <label><input type="checkbox" value="ticket_followups_by_user" checked> Acompanhamentos feitos pelo agente</label>
        <label><input type="checkbox" value="ticket_solutions_by_user" checked> Soluções registradas pelo agente</label>
      </div>
      <div class="g4fr-context-section">
        <h3>Projetos</h3>
        <label><input type="checkbox" value="projects_managed_by_user"> Projetos gerenciados pelo agente</label>
        <label><input type="checkbox" value="projects_managed_by_groups"> Projetos gerenciados pelos grupos selecionados</label>
        <label><input type="checkbox" value="projects_member_user"> Projetos em que o agente participa</label>
      </div>
      <div class="g4fr-context-section">
        <h3>Tarefas e narrativa</h3>
        <label><input type="checkbox" value="project_tasks_user"> Tarefas de projeto do agente</label>
        <label><input type="checkbox" value="project_tasks_groups"> Tarefas de projeto dos grupos selecionados</label>
        <label><input type="checkbox" value="manual_entries" checked> Permitir entradas narrativas manuais</label>
      </div>
    </div>
  </div>

  <div class="g4fr-card">
    <h2>3. Textos do relatório</h2>
    <div class="g4fr-grid">
      <div class="g4fr-field g4fr-full">
        <label>Título do relatório</label>
        <input type="text" name="report_title" id="g4fr-title" class="form-control" value="<?php echo htmlspecialchars((string)($cfg['default_report_title'] ?? 'Relatório Gerencial de Atividades'), ENT_QUOTES, 'UTF-8'); ?>">
      </div>
      <div class="g4fr-field">
        <label>Abrangência</label>
        <textarea name="scope_text" id="g4fr-scope" class="form-control" rows="5"><?php echo htmlspecialchars((string)($cfg['default_scope_text'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
      </div>
      <div class="g4fr-field">
        <label>Objetivo</label>
        <textarea name="objective_text" id="g4fr-objective" class="form-control" rows="5"><?php echo htmlspecialchars((string)($cfg['default_objective_text'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
      </div>
    </div>
    <div class="g4fr-sticky-actions mt-3">
      <div class="g4fr-actions">
        <button type="button" id="g4fr-build" class="btn btn-primary">Gerar rascunho pela API</button>
        <button type="button" id="g4fr-add-manual" class="btn btn-outline-secondary" disabled>Adicionar entrada manual</button>
        <button type="button" id="g4fr-download-json" class="btn btn-outline-secondary" disabled>Baixar rascunho JSON</button>
        <label class="btn btn-outline-secondary mb-0">Importar JSON <input type="file" id="g4fr-import-json" accept="application/json" hidden></label>
        <button type="button" id="g4fr-export" class="btn btn-success" disabled>Exportar DOCX</button>
      </div>
    </div>
  </div>

  <div id="g4fr-status" class="g4fr-status"></div>
  <div id="g4fr-preview"></div>
</div>
<script>
window.G4FREPORTS = { api_url: 'api.php', export_url: 'export.php', csrf: <?php echo json_encode((class_exists('Session') && method_exists('Session', 'getNewCSRFToken')) ? Session::getNewCSRFToken() : ''); ?> };
</script>
<script><?php if (is_file($js)) { readfile($js); } ?></script>
<?php
if (class_exists('Html')) {
    Html::footer();
}
