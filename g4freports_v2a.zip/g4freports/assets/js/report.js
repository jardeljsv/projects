(function () {
  'use strict';

  var apiUrl = (window.G4FREPORTS && window.G4FREPORTS.api_url) || 'api.php';
  var exportUrl = (window.G4FREPORTS && window.G4FREPORTS.export_url) || 'export.php';
  var csrfToken = (window.G4FREPORTS && window.G4FREPORTS.csrf) || '';
  var draft = null;
  var selectedGroups = {};

  function $(id) { return document.getElementById(id); }

  function html(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c];
    });
  }

  function setStatus(type, message) {
    var box = $('g4fr-status');
    if (!box) return;
    if (!message) { box.innerHTML = ''; return; }
    box.innerHTML = '<div class="alert alert-' + html(type || 'info') + '">' + html(message) + '</div>';
  }


  function applyContextPreset(preset) {
    var all = Array.prototype.slice.call(document.querySelectorAll('#g4fr-contexts input[type="checkbox"]'));
    var selected = [];
    if (preset === 'operational') {
      selected = ['tickets_assigned_user','ticket_tasks_by_user','ticket_followups_by_user','ticket_solutions_by_user','manual_entries'];
    } else if (preset === 'project') {
      selected = ['projects_managed_by_user','projects_member_user','project_tasks_user','manual_entries'];
    } else if (preset === 'all') {
      selected = all.map(function (el) { return el.value; });
    } else if (preset === 'none') {
      selected = [];
    }
    var map = {};
    selected.forEach(function (v) { map[v] = true; });
    all.forEach(function (el) { el.checked = !!map[el.value]; });
  }

  function selectedContexts() {
    var out = [];
    document.querySelectorAll('#g4fr-contexts input[type="checkbox"]:checked').forEach(function (el) { out.push(el.value); });
    return out;
  }

  function collectRequest() {
    return {
      profile_id: $('g4fr-profile').value,
      agent_id: $('g4fr-agent-id').value,
      agent_name: $('g4fr-agent-name').value,
      period_start: $('g4fr-start').value,
      period_end: $('g4fr-end').value,
      template: $('g4fr-template').value,
      group_ids: $('g4fr-group-ids').value,
      report_title: $('g4fr-title').value,
      scope_text: $('g4fr-scope').value,
      objective_text: $('g4fr-objective').value,
      contexts: selectedContexts()
    };
  }

  function callApi(action, payload) {
    var url = new URL(apiUrl, window.location.href);
    url.searchParams.set('action', action);
    url.searchParams.set('payload', JSON.stringify(payload || {}));
    url.searchParams.set('_', String(Date.now()));
    return fetch(url.toString(), {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (res) {
      return res.text().then(function (txt) {
        var data;
        try { data = JSON.parse(txt); } catch (e) { data = { ok: false, error: txt || ('HTTP ' + res.status) }; }
        if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status));
        return data;
      });
    });
  }

  function buildDraft() {
    var btn = $('g4fr-build');
    var req = collectRequest();
    var contexts = (req.contexts || []).filter(function (c) { return c !== 'manual_entries'; });
    var batchLimit = 50;
    var parts = [];
    var totalContexts = contexts.length;
    var ctxIndex = 0;

    btn.disabled = true;
    setStatus('info', 'Consultando API do GLPI em lotes seguros. Nenhum contexto por grupo será expandido automaticamente; apenas grupos selecionados serão usados.');

    function finish() {
      draft = mergeDraftParts(parts, req);
      setStatus('success', 'Rascunho gerado em lotes. Entradas carregadas: ' + ((draft.entries || []).length) + '. Revise antes de exportar.');
      $('g4fr-add-manual').disabled = false;
      $('g4fr-download-json').disabled = false;
      $('g4fr-export').disabled = false;
      renderDraft();
    }

    function nextContext() {
      if (ctxIndex >= contexts.length) {
        finish();
        return Promise.resolve();
      }
      var ctx = contexts[ctxIndex++];
      return fetchContextPage(ctx, 0, 0).then(nextContext);
    }

    function fetchContextPage(ctx, offset, page) {
      var payload = Object.assign({}, req, {
        contexts: [ctx],
        batch_context: ctx,
        batch_offset: offset,
        batch_limit: batchLimit
      });
      setStatus('info', 'Processando contexto ' + ctxIndex + '/' + totalContexts + ': ' + contextLabel(ctx) + ' • lote iniciado em ' + offset + '.');
      return callApi('build_draft', payload).then(function (data) {
        var d = data.draft || {};
        parts.push(d);
        var b = d.batch || {};
        var total = parseInt(b.total_candidates || 0, 10) || 0;
        var returned = parseInt(b.returned_candidates || 0, 10) || 0;
        var hasMore = !!b.has_more;
        if (hasMore && returned > 0 && page < 10000) {
          return fetchContextPage(ctx, offset + batchLimit, page + 1);
        }
      });
    }

    if (!contexts.length) {
      finish();
      btn.disabled = false;
      return;
    }

    nextContext().catch(function (err) {
      setStatus('danger', err.message || String(err));
    }).finally(function () {
      btn.disabled = false;
    });
  }

  function contextLabel(ctx) {
    var labels = {
      tickets_assigned_user: 'Chamados atribuídos ao agente',
      tickets_requested_by_user: 'Chamados solicitados pelo agente',
      tickets_assigned_groups: 'Chamados dos grupos selecionados',
      ticket_tasks_by_user: 'Tarefas feitas pelo agente',
      ticket_followups_by_user: 'Acompanhamentos feitos pelo agente',
      ticket_solutions_by_user: 'Soluções registradas pelo agente',
      projects_managed_by_user: 'Projetos gerenciados pelo agente',
      projects_managed_by_groups: 'Projetos dos grupos selecionados',
      projects_member_user: 'Projetos com participação do agente',
      project_tasks_user: 'Tarefas de projeto do agente',
      project_tasks_groups: 'Tarefas de projeto dos grupos selecionados'
    };
    return labels[ctx] || ctx;
  }

  function baseDraft(req) {
    return {
      schema_version: 1,
      created_at: new Date().toISOString(),
      connection: { id: req.profile_id || '__default__', name: req.profile_id || 'GLPI' },
      report_title: req.report_title || 'Relatório Gerencial de Atividades',
      template: req.template || 'operational',
      period_start: req.period_start,
      period_end: req.period_end,
      subject: { type: 'user', id: parseInt(req.agent_id || 0, 10) || 0, name: req.agent_name || 'Profissional não informado' },
      groups: [],
      contexts: req.contexts || [],
      scope_text: req.scope_text || '',
      objective_text: req.objective_text || '',
      executive_summary: '',
      metrics: [],
      entries: [],
      validations: [],
      warnings: [],
      source_totals: {}
    };
  }

  function mergeDraftParts(parts, req) {
    var out = parts.length ? Object.assign({}, parts[0]) : baseDraft(req);
    out.entries = [];
    out.contexts = req.contexts || [];
    out.period_start = req.period_start;
    out.period_end = req.period_end;
    out.report_title = req.report_title || out.report_title;
    out.template = req.template || out.template;
    out.scope_text = req.scope_text || out.scope_text || '';
    out.objective_text = req.objective_text || out.objective_text || '';
    out.subject = out.subject || { type: 'user', id: req.agent_id || 0, name: req.agent_name || '' };
    var seen = {};
    var warnings = [];
    var validations = [];
    var sourceTotals = {};
    parts.forEach(function (part) {
      (part.entries || []).forEach(function (e) {
        var key = [e.source_type || '', e.source_itemtype || '', e.source_id || '', e.date || '', e.title || '', e.activity_performed || ''].join('|');
        if (seen[key]) return;
        seen[key] = true;
        out.entries.push(e);
      });
      (part.warnings || []).forEach(function (w) { if (warnings.indexOf(w) === -1) warnings.push(w); });
      (part.validations || []).forEach(function (v) { validations.push(v); });
      Object.keys(part.source_totals || {}).forEach(function (k) { sourceTotals[k] = Math.max(sourceTotals[k] || 0, parseInt(part.source_totals[k] || 0, 10) || 0); });
    });
    out.entries.sort(function (a, b) { return String(a.date || '').localeCompare(String(b.date || '')) || String(a.title || '').localeCompare(String(b.title || '')); });
    out.source_totals = sourceTotals;
    out.total_api_candidates = Object.keys(sourceTotals).reduce(function (n, k) { return n + (parseInt(sourceTotals[k] || 0, 10) || 0); }, 0);
    out.warnings = warnings;
    out.validations = dedupeValidations(validations);
    out.metrics = computeMetrics(out.entries, out.total_api_candidates);
    if (!out.executive_summary) {
      out.executive_summary = 'No período de ' + formatDate(out.period_start) + ' a ' + formatDate(out.period_end) + ', foram consolidadas ' + out.entries.length + ' entradas de atividade relacionadas a ' + ((out.subject && out.subject.name) || 'profissional selecionado') + '. O rascunho combina dados obtidos via API do GLPI com espaço para complementação narrativa.';
    }
    return out;
  }

  function dedupeValidations(items) {
    var seen = {}, out = [];
    items.forEach(function (v) {
      var key = (v.level || '') + '|' + (v.message || '');
      if (seen[key]) return;
      seen[key] = true;
      out.push(v);
    });
    return out;
  }

  function computeMetrics(entries, apiTotal) {
    var total = entries.length, tickets = 0, projects = 0, tasks = 0, closed = 0;
    entries.forEach(function (e) {
      var stype = String(e.source_type || '');
      if (stype.indexOf('ticket') === 0) tickets++;
      if (stype.indexOf('project') === 0) projects++;
      if (stype.indexOf('task') !== -1) tasks++;
      var status = String(e.status || '').toLowerCase();
      if (/fech|soluc|conclu|closed|solved|done/.test(status)) closed++;
    });
    var rate = total ? Math.round((closed / total) * 1000) / 10 : 0;
    var metrics = [
      { key: 'entries', label: 'Entradas carregadas', value: total },
      { key: 'tickets', label: 'Entradas de chamados', value: tickets },
      { key: 'projects', label: 'Entradas de projetos', value: projects },
      { key: 'closed_rate', label: 'Taxa de encerramento/conclusão', value: rate + '%' }
    ];
    if (apiTotal && apiTotal > total) {
      metrics.unshift({ key: 'api_total', label: 'Registros encontrados na API', value: apiTotal });
    }
    return metrics;
  }

  function renderDraft() {
    var box = $('g4fr-preview');
    if (!box || !draft) return;
    var metrics = (draft.metrics || []).map(function (m) {
      return '<div class="g4fr-metric"><div class="g4fr-metric-value">' + html(m.value) + '</div><div class="g4fr-metric-label">' + html(m.label) + '</div></div>';
    }).join('');
    var validations = (draft.validations || []).concat((draft.warnings || []).map(function (w) { return { level: 'warning', message: w }; })).map(function (v) {
      return '<div class="g4fr-validation ' + html(v.level || 'info') + '">' + html(v.message || '') + '</div>';
    }).join('');

    var allEntries = draft.entries || [];
    var renderLimit = 300;
    var renderedEntries = allEntries.length > renderLimit ? allEntries.slice(0, renderLimit) : allEntries;
    var groups = groupEntries(renderedEntries);
    var entriesHtml = '';
    Object.keys(groups).sort().forEach(function (date) {
      entriesHtml += '<div class="g4fr-day-title">' + html(formatDate(date)) + '</div>';
      groups[date].forEach(function (entry, idx) {
        entriesHtml += entryHtml(entry, entry.__idx);
      });
    });
    var volumeNotice = allEntries.length > renderLimit
      ? '<div class="g4fr-validation info">Foram carregadas ' + html(allEntries.length) + ' entradas no rascunho. Para manter a tela responsiva, somente as primeiras ' + renderLimit + ' aparecem na prévia editável; a exportação DOCX usa todas as entradas carregadas.</div>'
      : '';

    box.innerHTML = '<div class="g4fr-card"><div class="g4fr-preview-header"><div><h2>3. Prévia editável</h2><p><strong>' + html(draft.report_title) + '</strong><br>' + html(draft.subject && draft.subject.name) + ' • ' + html(formatDate(draft.period_start)) + ' a ' + html(formatDate(draft.period_end)) + '</p></div></div>' +
      '<div class="g4fr-metrics">' + metrics + '</div>' + volumeNotice +
      '<h2>Validações</h2>' + (validations || '<p>Nenhuma validação relevante.</p>') +
      '<h2>Resumo executivo</h2><textarea class="form-control" id="g4fr-exec-summary" rows="4">' + html(draft.executive_summary || '') + '</textarea>' +
      '<div id="g4fr-entries">' + entriesHtml + '</div></div>';

    bindEntryEditors();
    var summary = $('g4fr-exec-summary');
    if (summary) summary.addEventListener('input', function () { draft.executive_summary = summary.value; });
  }

  function groupEntries(entries) {
    var groups = {};
    entries.forEach(function (e, i) {
      e.__idx = i;
      var d = e.date || new Date().toISOString().slice(0, 10);
      if (!groups[d]) groups[d] = [];
      groups[d].push(e);
    });
    return groups;
  }

  function entryHtml(e, idx) {
    return '<div class="g4fr-entry" data-idx="' + idx + '">' +
      '<div class="g4fr-entry-head">' +
        '<div><label>Data</label><input type="date" class="form-control g4fr-entry-input" data-field="date" value="' + html(e.date || '') + '"></div>' +
        '<div><label>Título</label><input type="text" class="form-control g4fr-entry-input" data-field="title" value="' + html(e.title || '') + '"></div>' +
        '<div><label>Status</label><input type="text" class="form-control g4fr-entry-input" data-field="status" value="' + html(e.status || '') + '"></div>' +
        '<label class="g4fr-check"><input type="checkbox" class="g4fr-entry-include" ' + (e.include_in_report !== false ? 'checked' : '') + '> Incluir</label>' +
      '</div>' +
      '<div class="g4fr-entry-body">' +
        '<div><label>Referência</label><input type="text" class="form-control g4fr-entry-input" data-field="source_reference" value="' + html(e.source_reference || '') + '"></div>' +
        '<div><label>Categoria</label><input type="text" class="form-control g4fr-entry-input" data-field="category" value="' + html(e.category || '') + '"></div>' +
        '<div class="g4fr-full"><label>Atividades realizadas</label><textarea class="form-control g4fr-entry-input" data-field="activity_performed">' + html(e.activity_performed || '') + '</textarea></div>' +
        '<div><label>Resultado</label><textarea class="form-control g4fr-entry-input" data-field="result">' + html(e.result || '') + '</textarea></div>' +
        '<div><label>Plano de tratamento / próximos passos</label><textarea class="form-control g4fr-entry-input" data-field="next_steps">' + html(e.next_steps || '') + '</textarea></div>' +
        '<div class="g4fr-full"><label>Observações</label><textarea class="form-control g4fr-entry-input" data-field="observations">' + html(e.observations || '') + '</textarea></div>' +
      '</div></div>';
  }

  function bindEntryEditors() {
    document.querySelectorAll('.g4fr-entry').forEach(function (entryEl) {
      var idx = parseInt(entryEl.getAttribute('data-idx'), 10);
      entryEl.querySelectorAll('.g4fr-entry-input').forEach(function (input) {
        input.addEventListener('input', function () {
          if (!draft || !draft.entries || !draft.entries[idx]) return;
          draft.entries[idx][input.getAttribute('data-field')] = input.value;
        });
      });
      var inc = entryEl.querySelector('.g4fr-entry-include');
      if (inc) inc.addEventListener('change', function () {
        if (!draft || !draft.entries || !draft.entries[idx]) return;
        draft.entries[idx].include_in_report = inc.checked;
      });
    });
  }

  function addManualEntry() {
    if (!draft) {
      draft = collectRequest();
      draft.entries = [];
    }
    draft.entries = draft.entries || [];
    draft.entries.push({
      date: $('g4fr-start').value || new Date().toISOString().slice(0, 10),
      source_type: 'manual',
      source_itemtype: '',
      source_id: 0,
      source_reference: 'Entrada manual',
      professional: draft.subject && draft.subject.name || $('g4fr-agent-name').value || '',
      title: 'Atividade manual',
      status: '',
      category: '',
      activity_performed: 'Descrever a atividade realizada pelo profissional nesta data.',
      result: '',
      next_steps: '',
      observations: '',
      include_in_report: true
    });
    renderDraft();
  }

  function exportDocx() {
    if (!draft) return;
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = exportUrl;
    if (csrfToken) {
      var csrf = document.createElement('input');
      csrf.type = 'hidden';
      csrf.name = '_glpi_csrf_token';
      csrf.value = csrfToken;
      form.appendChild(csrf);
    }
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'draft_json';
    input.value = JSON.stringify(draft);
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
    form.remove();
  }

  function downloadJson() {
    if (!draft) return;
    var blob = new Blob([JSON.stringify(draft, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'rascunho-relatorio-g4f.json';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  }

  function importJson(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        draft = JSON.parse(reader.result);
        $('g4fr-add-manual').disabled = false;
        $('g4fr-download-json').disabled = false;
        $('g4fr-export').disabled = false;
        setStatus('success', 'Rascunho importado.');
        renderDraft();
      } catch (e) {
        setStatus('danger', 'JSON inválido: ' + e.message);
      }
    };
    reader.readAsText(file);
  }


  function renderSelectedGroups() {
    var box = $('g4fr-selected-groups');
    var hidden = $('g4fr-group-ids');
    if (!box || !hidden) return;
    var ids = Object.keys(selectedGroups).sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
    hidden.value = ids.join(',');
    if (!ids.length) {
      box.innerHTML = '<div class="g4fr-muted">Nenhum grupo adicional selecionado.</div>';
      return;
    }
    box.innerHTML = ids.map(function (id) {
      return '<span class="g4fr-chip" data-group-id="' + html(id) + '"><strong>#' + html(id) + '</strong> ' + html(selectedGroups[id]) + ' <button type="button" title="Remover grupo">×</button></span>';
    }).join('');
    box.querySelectorAll('.g4fr-chip button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var chip = btn.closest('.g4fr-chip');
        if (!chip) return;
        delete selectedGroups[chip.getAttribute('data-group-id')];
        renderSelectedGroups();
      });
    });
  }

  function addSelectedGroup(group) {
    if (!group || !group.id) return;
    selectedGroups[String(group.id)] = group.name || ('Grupo #' + group.id);
    renderSelectedGroups();
  }

  function searchGroups() {
    var qEl = $('g4fr-group-search-q');
    var q = qEl ? qEl.value : '';
    if (!q) return;
    var resBox = $('g4fr-group-results');
    if (!resBox) return;
    resBox.style.display = 'block';
    resBox.innerHTML = '<div class="g4fr-search-result">Buscando grupos...</div>';
    callApi('search_groups', { profile_id: $('g4fr-profile').value, q: q }).then(function (data) {
      var groups = data.groups || [];
      if (!groups.length) {
        resBox.innerHTML = '<div class="g4fr-search-empty">Nenhum grupo encontrado.</div>';
        return;
      }
      resBox.innerHTML = groups.map(function (g) {
        return '<div class="g4fr-search-result" data-id="' + html(g.id) + '" data-name="' + html(g.name || '') + '"><strong>#' + html(g.id) + '</strong> ' + html(g.name || '') + '</div>';
      }).join('');
      resBox.querySelectorAll('.g4fr-search-result').forEach(function (el) {
        el.addEventListener('click', function () {
          addSelectedGroup({ id: el.getAttribute('data-id'), name: el.getAttribute('data-name') });
          if (qEl) qEl.value = '';
          resBox.innerHTML = '';
          resBox.style.display = 'none';
        });
      });
    }).catch(function (err) {
      resBox.innerHTML = '<div class="g4fr-search-result">' + html(err.message) + '</div>';
    });
  }

  function searchUsers() {
    var q = $('g4fr-agent-search-q').value;
    if (!q) return;
    var resBox = $('g4fr-agent-results');
    if (resBox) resBox.style.display = 'block';
    resBox.innerHTML = '<div class="g4fr-search-result">Buscando...</div>';
    callApi('search_users', { profile_id: $('g4fr-profile').value, q: q }).then(function (data) {
      var users = data.users || [];
      if (!users.length) {
        resBox.innerHTML = '<div class="g4fr-search-result">Nenhum usuário encontrado.</div>';
        return;
      }
      resBox.innerHTML = users.map(function (u) {
        return '<div class="g4fr-search-result" data-id="' + html(u.id) + '" data-name="' + html(u.name || u.login || '') + '"><strong>#' + html(u.id) + '</strong> ' + html(u.name || u.login || '') + '</div>';
      }).join('');
      resBox.querySelectorAll('.g4fr-search-result').forEach(function (el) {
        el.addEventListener('click', function () {
          $('g4fr-agent-id').value = el.getAttribute('data-id');
          $('g4fr-agent-name').value = el.getAttribute('data-name');
          resBox.innerHTML = '';
          resBox.style.display = 'none';
        });
      });
    }).catch(function (err) {
      resBox.innerHTML = '<div class="g4fr-search-result">' + html(err.message) + '</div>';
    });
  }

  function formatDate(iso) {
    if (!iso) return '';
    var p = String(iso).slice(0, 10).split('-');
    if (p.length === 3) return p[2] + '/' + p[1] + '/' + p[0];
    return iso;
  }

  document.addEventListener('DOMContentLoaded', function () {
    if ($('g4fr-build')) $('g4fr-build').addEventListener('click', buildDraft);
    if ($('g4fr-add-manual')) $('g4fr-add-manual').addEventListener('click', addManualEntry);
    if ($('g4fr-export')) $('g4fr-export').addEventListener('click', exportDocx);
    if ($('g4fr-download-json')) $('g4fr-download-json').addEventListener('click', downloadJson);
    if ($('g4fr-agent-search-btn')) $('g4fr-agent-search-btn').addEventListener('click', searchUsers);
    if ($('g4fr-agent-search-q')) $('g4fr-agent-search-q').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); searchUsers(); } });
    if ($('g4fr-group-search-btn')) $('g4fr-group-search-btn').addEventListener('click', searchGroups);
    if ($('g4fr-group-search-q')) $('g4fr-group-search-q').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); searchGroups(); } });
    renderSelectedGroups();
    if ($('g4fr-import-json')) $('g4fr-import-json').addEventListener('change', function () { if (this.files && this.files[0]) importJson(this.files[0]); });
    document.querySelectorAll('[data-context-preset]').forEach(function (btn) {
      btn.addEventListener('click', function () { applyContextPreset(btn.getAttribute('data-context-preset')); });
    });
  });
})();
