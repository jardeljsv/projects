<?php
// /plugins/glpibot/front/health.php
// Real upstream health check against the resolved API profile.

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

header('Content-Type: application/json; charset=UTF-8');
@ini_set('display_errors', '0');

function glpibot_health_noapi(string $reason, ?string $profileName = null, array $extra = []): void {
    $payload = array_merge([
        'mode' => 'noapi',
        'reason' => $reason,
    ], $extra);
    if ($profileName !== null && $profileName !== '') {
        $payload['profile_name'] = $profileName;
    }
    glpibot_json_response(200, $payload);
}

$glpiRoot = null;
$dbInfo = null;
$mysqli = glpibot_open_plugin_mysqli($glpiRoot, $dbInfo);
if (!$mysqli) {
    glpibot_health_noapi('db_unavailable');
}

$cfg = glpibot_load_plugin_config_from_mysqli($mysqli);
$debug = [];
$uid = glpibot_resolve_uid_from_php_session($debug);
$visibility = glpibot_resolve_widget_visibility($mysqli, $cfg, $uid);
if (empty($visibility['enabled'])) {
    @mysqli_close($mysqli);
    glpibot_health_noapi('disabled');
}
if (empty($visibility['allowed']) && empty($visibility['uncertain'])) {
    @mysqli_close($mysqli);
    glpibot_health_noapi('not_allowed');
}

$runtime = glpibot_resolve_runtime_profile($mysqli, $cfg, $uid);
@mysqli_close($mysqli);
if (empty($runtime['ok']) || !is_array($runtime['profile'] ?? null)) {
    glpibot_health_noapi((string)($runtime['reason'] ?? 'profile_unavailable'));
}

$profile = $runtime['profile'];
$profileName = (string)($profile['name'] ?? 'Chat');
$healthUrl = (string)($profile['health_url'] ?? '');
$apiKey = (string)($profile['api_key'] ?? '');
$timeoutMs = glpibot_int($profile['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
$healthTimeout = min($timeoutMs, 8000);

if ($healthUrl === '' || $apiKey === '') {
    glpibot_health_noapi('not_configured', $profileName);
}

$headers = [
    'Accept: application/json',
    'Authorization: Bearer ' . $apiKey,
];
$req = glpibot_http_json_request('GET', $healthUrl, $headers, null, $healthTimeout);
if (!$req['ok']) {
    glpibot_health_noapi('upstream_error', $profileName, [
        'http_code' => (int)$req['http_code'],
    ]);
}

$json = is_array($req['json']) ? $req['json'] : [];
if (array_key_exists('ok', $json) && !$json['ok']) {
    glpibot_health_noapi('health_not_ok', $profileName, [
        'up' => $json,
    ]);
}

glpibot_json_response(200, [
    'mode' => 'api',
    'profile_name' => $profileName,
    'reason' => 'healthy',
    'up' => $json,
]);
