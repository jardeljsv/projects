<?php
// /plugins/glpibot/front/allowed.php
// Widget visibility gate. Uses plugin config + optional group routes.

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

header('Content-Type: application/json; charset=UTF-8');
header('Vary: Cookie');
@ini_set('display_errors', '0');
http_response_code(200);

$glpiRoot = null;
$dbInfo = null;
$mysqli = glpibot_open_plugin_mysqli($glpiRoot, $dbInfo);
if (!$mysqli) {
    glpibot_json_response(200, [
        'enabled' => true,
        'restricted' => true,
        'allowed' => true,
        'uncertain' => true,
        'reason' => 'fail_open_db_unavailable'
    ]);
}

$cfg = glpibot_load_plugin_config_from_mysqli($mysqli);
$debug = [];
$uid = glpibot_resolve_uid_from_php_session($debug);
$result = glpibot_resolve_widget_visibility($mysqli, $cfg, $uid);
@mysqli_close($mysqli);

glpibot_json_response(200, $result);
