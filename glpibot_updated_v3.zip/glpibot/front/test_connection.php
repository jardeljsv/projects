<?php
// /plugins/glpibot/front/test_connection.php
// Used by the GLPIBot config page. Supports:
// - GET: test saved default profile
// - GET ?profile_id=<id>: test a saved extra profile or __default__
// - POST JSON/form: test ad-hoc values from the config screen without saving first

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

header('Content-Type: application/json; charset=UTF-8');
@ini_set('display_errors', '0');

function tc_respond(int $http, array $arr): void {
    http_response_code($http);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

function tc_read_input(): array {
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($method === 'POST') {
        $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
        if (strpos($ct, 'application/json') !== false) {
            $raw = file_get_contents('php://input');
            $json = json_decode((string)$raw, true);
            return is_array($json) ? $json : [];
        }
        return $_POST;
    }
    return $_GET;
}

function tc_profile_from_input(array $input): ?array {
    $base = glpibot_string($input['api_base_url'] ?? '', '');
    $key = glpibot_string($input['api_key'] ?? '', '');
    $healthPath = glpibot_normalize_endpoint_path($input['health_path'] ?? ($input['api_health_path'] ?? ''), '/health');
    $timeout = glpibot_int($input['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
    $name = glpibot_string($input['name'] ?? ($input['profile_name'] ?? 'Ad-hoc profile'), 'Ad-hoc profile');

    if ($base === '' && $key === '') {
        return null;
    }

    return [
        'id' => '__adhoc__',
        'name' => $name,
        'api_base_url' => $base,
        'api_key' => $key,
        'health_path' => $healthPath,
        'request_timeout_ms' => $timeout,
        'health_url' => glpibot_join_url($base, $healthPath, '/health'),
    ];
}

$input = tc_read_input();
$adhoc = tc_profile_from_input($input);
if (is_array($adhoc)) {
    $profile = $adhoc;
} else {
    $glpiRoot = null;
    $dbInfo = null;
    $mysqli = glpibot_open_plugin_mysqli($glpiRoot, $dbInfo);
    if (!$mysqli) {
        tc_respond(500, ['ok' => false, 'reason' => 'db_unavailable']);
    }
    $cfg = glpibot_load_plugin_config_from_mysqli($mysqli);
    @mysqli_close($mysqli);

    $profileId = glpibot_string($input['profile_id'] ?? '__default__', '__default__');
    $profiles = glpibot_profiles_with_default($cfg);
    $profile = $profiles[$profileId] ?? null;
    if (!is_array($profile)) {
        tc_respond(200, ['ok' => false, 'reason' => 'profile_not_found']);
    }
}

$healthUrl = (string)($profile['health_url'] ?? '');
$apiKey = (string)($profile['api_key'] ?? '');
$timeoutMs = glpibot_int($profile['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
$profileName = (string)($profile['name'] ?? 'Profile');

if ($healthUrl === '' || $apiKey === '') {
    tc_respond(200, ['ok' => false, 'reason' => 'not_configured', 'profile_name' => $profileName]);
}

$headers = [
    'Accept: application/json',
    'Authorization: Bearer ' . $apiKey,
];
$req = glpibot_http_json_request('GET', $healthUrl, $headers, null, min($timeoutMs, 8000));
if (!$req['ok']) {
    tc_respond(200, [
        'ok' => false,
        'reason' => 'upstream_error',
        'profile_name' => $profileName,
        'http_code' => (int)$req['http_code'],
        'detail' => $req['curl_error'] !== '' ? $req['curl_error'] : (string)$req['body_raw'],
    ]);
}

$json = is_array($req['json']) ? $req['json'] : [];
if (array_key_exists('ok', $json) && !$json['ok']) {
    tc_respond(200, [
        'ok' => false,
        'reason' => 'health_not_ok',
        'profile_name' => $profileName,
        'body' => $json,
    ]);
}

tc_respond(200, [
    'ok' => true,
    'reason' => 'healthy',
    'profile_name' => $profileName,
    'up' => $json,
]);
