<?php
// /plugins/glpibot/front/chatproxy.php
// Browser -> this proxy -> FastAPI model.
// Resolves API profile from group routes (or legacy default config).

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

header('Content-Type: application/json; charset=UTF-8');
@ini_set('display_errors', '0');

function respond_error(int $http, string $label, string $detail = '', $trace = ''): void {
    http_response_code($http);
    $out = ['error' => $label, 'detail' => $detail];
    if ($trace !== '' && $trace !== null) {
        if (!is_string($trace)) {
            $trace = json_encode($trace, JSON_UNESCAPED_UNICODE);
        } elseif (strlen($trace) > 4096) {
            $trace = substr($trace, 0, 4096) . '...[truncated]';
        }
        $out['trace'] = $trace;
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}

function respond_ok(string $text): void {
    http_response_code(200);
    echo json_encode(['text' => $text], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    respond_error(405, 'method_not_allowed', 'use POST');
}

$ct = strtolower($_SERVER['CONTENT_TYPE'] ?? '');
if (strpos($ct, 'application/json') === false) {
    respond_error(415, 'unsupported_media_type', 'need application/json');
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    respond_error(400, 'invalid_json', 'body must be valid JSON');
}

$sid            = (string)($data['sid'] ?? '');
$prompt         = trim((string)($data['prompt'] ?? ''));
$topP           = ($data['top_p'] ?? 0.85);
$temperature    = ($data['temperature'] ?? 0.35);
$maxNewTokens   = glpibot_int($data['max_new_tokens'] ?? ($data['max_len'] ?? 120), 120, 1, 2048);
$minLen         = glpibot_int($data['min_len'] ?? 4, 4, 0, 2048);

if ($prompt === '') {
    respond_error(400, 'empty_prompt', 'prompt is empty');
}
if (mb_strlen($prompt, 'UTF-8') > 4000) {
    $prompt = mb_substr($prompt, 0, 4000, 'UTF-8');
}

$glpiRoot = null;
$dbInfo = null;
$mysqli = glpibot_open_plugin_mysqli($glpiRoot, $dbInfo);
if (!$mysqli) {
    respond_error(500, 'internal_error', 'db_unavailable');
}

$cfg = glpibot_load_plugin_config_from_mysqli($mysqli);
$debug = [];
$uid = glpibot_resolve_uid_from_php_session($debug);
$runtime = glpibot_resolve_runtime_profile($mysqli, $cfg, $uid);
@mysqli_close($mysqli);

if (empty($runtime['ok']) || !is_array($runtime['profile'] ?? null)) {
    $reason = (string)($runtime['reason'] ?? 'profile_unavailable');
    $http = in_array($reason, ['not_in_allowed_groups', 'no_matching_route', 'uid_not_found_for_route_mode', 'uid_not_found_for_legacy_group_mode'], true) ? 403 : 503;
    respond_error($http, 'profile_unavailable', $reason);
}

$profile = $runtime['profile'];
$chatUrl = (string)($profile['chat_url'] ?? '');
$apiKey = (string)($profile['api_key'] ?? '');
$timeoutMs = glpibot_int($profile['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
if ($chatUrl === '' || $apiKey === '') {
    respond_error(503, 'profile_not_configured', 'missing_chat_url_or_api_key');
}

$upPayload = [
    'sid' => $sid,
    'prompt' => $prompt,
    'top_p' => $topP,
    'temperature' => $temperature,
    'max_new_tokens' => $maxNewTokens,
    'max_len' => $maxNewTokens,
    'min_len' => $minLen,
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Bearer ' . $apiKey,
];

$req = glpibot_http_json_request('POST', $chatUrl, $headers, $upPayload, $timeoutMs);
if (!$req['ok']) {
    respond_error(
        502,
        'upstream_error',
        'upstream_http_' . (int)$req['http_code'],
        $req['curl_error'] !== '' ? $req['curl_error'] : (string)$req['body_raw']
    );
}

$parsed = is_array($req['json']) ? $req['json'] : null;
if (!is_array($parsed)) {
    respond_error(502, 'invalid_upstream_json', (string)$req['body_raw']);
}
if (!array_key_exists('reply', $parsed)) {
    respond_error(502, 'no_reply_in_upstream', '', $parsed);
}

respond_ok((string)$parsed['reply']);
