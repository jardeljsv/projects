<?php

/**
 * Plugin DashProjects - Dashboard de projetos para GLPI
 *
 * @author  Diogo Berlanda
 * @license GPLv3+
 */

define('PLUGIN_DASHPROJECTS_VERSION', '1.0.0');
define('PLUGIN_DASHPROJECTS_MIN_GLPI_VERSION', '11.0.0');
define('PLUGIN_DASHPROJECTS_MAX_GLPI_VERSION', '11.0.99');

/**
 * Retorna informações da versão do plugin
 */
function plugin_version_dashprojects()
{
    return [
        'name'         => 'DashProjects GLPI',
        'version'      => PLUGIN_DASHPROJECTS_VERSION,
        'author'       => 'Diogo Berlanda',
        'license'      => 'GPLv3+',
        'homepage'     => 'https://github.com/diberlanda95/dashprojects',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_DASHPROJECTS_MIN_GLPI_VERSION,
                'max' => PLUGIN_DASHPROJECTS_MAX_GLPI_VERSION,
            ],
        ],
    ];
}

/**
 * Inicialização do plugin — registra hooks, menu, CSS e JS
 */
function plugin_init_dashprojects()
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['dashprojects'] = true;

    if (Session::getLoginUserID()) {
        // Menu
        $PLUGIN_HOOKS['redefine_menus']['dashprojects'] = 'plugin_dashprojects_redefine_menus';
        // JS mínimo
        $PLUGIN_HOOKS['add_javascript']['dashprojects'] = 'js/menu.js';
    }
}

/**
 * Verifica pré-requisitos do plugin
 */
function plugin_dashprojects_check_prerequisites()
{
    return true;
}

/**
 * Verifica configuração do plugin
 */
function plugin_dashprojects_check_config()
{
    return true;
}
