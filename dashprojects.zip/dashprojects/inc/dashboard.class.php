<?php

use Glpi\DBAL\QueryExpression;
use Glpi\DBAL\QueryFunction;

/**
 * Plugin DashProjects - Classe de queries do dashboard
 */
class PluginDashprojectsDashboard
{
    /**
     * Retorna dados dos cards KPI + gráficos
     */
    public static function getDashboardData(): array
    {
        global $DB;

        $entityCriteria = getEntitiesRestrictCriteria('glpi_projects');

        // --- Cards KPI ---
        $total = self::countProjects($DB, $entityCriteria, []);

        $andamento = self::countProjects($DB, $entityCriteria, [
            'ps.is_finished' => 0,
            ['glpi_projects.percent_done' => ['>', 0]]
        ]);

        $planejados = self::countProjects($DB, $entityCriteria, [
            'ps.is_finished' => 0,
            'glpi_projects.percent_done' => 0
        ]);

        $finalizados = self::countProjects($DB, $entityCriteria, ['ps.is_finished' => 1]);

        $atrasados = self::countProjects($DB, $entityCriteria, [
            'ps.is_finished' => 0,
            ['NOT' => ['glpi_projects.plan_end_date' => null]],
            new QueryExpression('`glpi_projects`.`plan_end_date` < NOW()'),
        ]);

        $taxa = ($total > 0) ? round(($finalizados / $total) * 100) : 0;

        $tempoMedioDias = 0;
        $result = $DB->request([
            'SELECT' => [
                QueryFunction::avg(
                    QueryFunction::timestampdiff('SECOND', 'glpi_projects.real_start_date', 'glpi_projects.real_end_date'),
                    'avg_sec'
                ),
            ],
            'FROM'  => 'glpi_projects',
            'INNER JOIN' => [
                'glpi_projectstates AS ps' => [
                    'ON' => ['ps' => 'id', 'glpi_projects' => 'projectstates_id']
                ]
            ],
            'WHERE' => array_merge([
                'ps.is_finished' => 1,
                'glpi_projects.is_deleted' => 0,
                'glpi_projects.is_template' => 0,
                ['NOT' => ['glpi_projects.real_start_date' => null]],
                ['NOT' => ['glpi_projects.real_end_date' => null]],
                new QueryExpression('`glpi_projects`.`real_end_date` >= DATE(NOW()) - INTERVAL 180 DAY'),
            ], $entityCriteria),
        ]);
        $row = $result->current();
        if (!empty($row['avg_sec'])) {
            $tempoMedioDias = round($row['avg_sec'] / 86400);
        }

        $milestones = 0;
        $result = $DB->request([
            'COUNT' => 'cpt',
            'FROM'  => 'glpi_projecttasks',
            'WHERE' => [
                'is_milestone' => 1,
                'percent_done' => 100,
                'is_deleted'   => 0
            ]
        ]);
        $row = $result->current();
        $milestones = (int)($row['cpt'] ?? 0);

        // --- Gráficos ---

        $trendData = [];
        $iterator = $DB->request([
            'SELECT' => [
                QueryFunction::dateFormat('glpi_projects.date_creation', '%d/%m', 'dia'),
                QueryFunction::count('glpi_projects.id', false, 'total'),
            ],
            'FROM'  => 'glpi_projects',
            'WHERE' => array_merge([
                'is_deleted' => 0,
                'is_template' => 0,
                new QueryExpression('`glpi_projects`.`date_creation` >= DATE(NOW()) - INTERVAL 30 DAY'),
            ], $entityCriteria),
            'GROUPBY' => [new QueryExpression('DATE(`glpi_projects`.`date_creation`)')],
            'ORDER' => [new QueryExpression('DATE(`glpi_projects`.`date_creation`) ASC')],
        ]);
        foreach ($iterator as $row) {
            $trendData[] = ['dia' => $row['dia'], 'total' => (int) $row['total']];
        }

        $typeData = [];
        $iterator = $DB->request([
            'SELECT' => [
                'pt.name AS nome',
                QueryFunction::count('p.id', false, 'total'),
            ],
            'FROM'   => 'glpi_projects AS p',
            'JOIN'   => [
                'glpi_projecttypes AS pt' => [
                    'ON' => ['pt' => 'id', 'p' => 'projecttypes_id'],
                ],
            ],
            'WHERE'  => array_merge([
                'p.is_deleted' => 0,
                'p.is_template' => 0,
            ], $entityCriteria),
            'GROUPBY' => ['pt.id', 'pt.name'],
            'ORDER'   => ['total DESC'],
            'LIMIT'   => 5,
        ]);
        foreach ($iterator as $row) {
            $typeData[] = ['nome' => $row['nome'], 'total' => (int) $row['total']];
        }

        $openedData = [];
        $iterator = $DB->request([
            'SELECT' => [
                QueryFunction::dateFormat('glpi_projects.date_creation', '%Y-%m', 'mes_ano'),
                QueryFunction::count('glpi_projects.id', false, 'total'),
            ],
            'FROM'  => 'glpi_projects',
            'WHERE' => array_merge([
                'is_deleted' => 0,
                'is_template' => 0,
                new QueryExpression("`glpi_projects`.`date_creation` >= DATE_FORMAT(NOW() - INTERVAL 5 MONTH, '%Y-%m-01')"),
            ], $entityCriteria),
            'GROUPBY' => [new QueryExpression("DATE_FORMAT(`glpi_projects`.`date_creation`, '%Y-%m')")],
            'ORDER'   => ['mes_ano ASC'],
        ]);
        foreach ($iterator as $row) {
            $openedData[] = ['mes_ano' => $row['mes_ano'], 'total' => (int) $row['total']];
        }

        $solvedData = [];
        $iterator = $DB->request([
            'SELECT' => [
                QueryFunction::dateFormat('glpi_projects.real_end_date', '%Y-%m', 'mes_ano'),
                QueryFunction::count('glpi_projects.id', false, 'total'),
            ],
            'FROM'  => 'glpi_projects',
            'INNER JOIN' => [
                'glpi_projectstates AS ps' => [
                    'ON' => ['ps' => 'id', 'glpi_projects' => 'projectstates_id']
                ]
            ],
            'WHERE' => array_merge([
                'ps.is_finished' => 1,
                'glpi_projects.is_deleted' => 0,
                'glpi_projects.is_template' => 0,
                new QueryExpression("`glpi_projects`.`real_end_date` >= DATE_FORMAT(NOW() - INTERVAL 5 MONTH, '%Y-%m-01')"),
            ], $entityCriteria),
            'GROUPBY' => [new QueryExpression("DATE_FORMAT(`glpi_projects`.`real_end_date`, '%Y-%m')")],
            'ORDER'   => ['mes_ano ASC'],
        ]);
        foreach ($iterator as $row) {
            $solvedData[] = ['mes_ano' => $row['mes_ano'], 'total' => (int) $row['total']];
        }

        return [
            'cards_top' => [
                'total'       => (int) $total,
                'andamento'   => (int) $andamento,
                'taxa'        => $taxa,
                'sla'         => (int) $atrasados,
                'tempo_medio' => $tempoMedioDias,
                'reabertos'   => (int) $milestones,
            ],
            'cards_bottom' => [
                'abertos'     => (int) $planejados,
                'atribuidos'  => (int) $andamento,
                'pendentes'   => (int) self::countProjects($DB, $entityCriteria, ['ps.is_finished' => 0, 'glpi_projects.percent_done' => 0]),
                'finalizados' => (int) $finalizados,
            ],
            'charts' => [
                'trend_line'     => $trendData,
                'cat_bar'        => $typeData,
                'monthly_opened' => $openedData,
                'monthly_solved' => $solvedData,
            ],
        ];
    }

    /**
     * Retorna ranking de gestores
     */
    public static function getRanking(): array
    {
        global $DB;
        $entityCriteria = getEntitiesRestrictCriteria('p');
        $iterator = $DB->request([
            'SELECT' => [
                new QueryExpression("TRIM(CONCAT(IFNULL(`u`.`firstname`, `u`.`name`), ' ', IFNULL(`u`.`realname`, ''))) AS `name`"),
                new QueryExpression("UPPER(CONCAT(LEFT(IFNULL(`u`.`firstname`, `u`.`name`), 1), LEFT(IFNULL(`u`.`realname`, ''), 1))) AS `avatar`"),
                QueryFunction::count('p.id', false, 'projects'),
                new QueryExpression('COUNT(`p`.`id`) * 50 AS `points`'),
            ],
            'FROM'  => 'glpi_projects AS p',
            'INNER JOIN' => [
                'glpi_users AS u' => [
                    'ON' => ['u'  => 'id', 'p' => 'users_id'],
                ],
                'glpi_projectstates AS ps' => [
                    'ON' => ['ps' => 'id', 'p' => 'projectstates_id']
                ]
            ],
            'WHERE' => array_merge([
                'ps.is_finished' => 1,
                'p.is_deleted'   => 0,
                'p.is_template'  => 0,
                ['NOT' => ['p.real_end_date' => null]],
                new QueryExpression('MONTH(`p`.`real_end_date`) = MONTH(CURRENT_DATE())'),
                new QueryExpression('YEAR(`p`.`real_end_date`) = YEAR(CURRENT_DATE())'),
            ], $entityCriteria),
            'GROUPBY' => ['u.id', 'u.firstname', 'u.name', 'u.realname'],
            'ORDER'   => ['points DESC'],
            'LIMIT'   => 20,
        ]);

        $colors = ['#3b82f6', '#a855f7', '#22c55e', '#f59e0b', '#06b6d4'];
        $ranking = [];
        foreach ($iterator as $key => $row) {
            $ranking[] = [
                'name'    => $row['name'],
                'avatar'  => !empty($row['avatar']) ? $row['avatar'] : 'G',
                'tickets' => (int) $row['projects'],
                'points'  => (int) $row['points'],
                'color'   => $colors[$key % count($colors)],
            ];
        }
        return $ranking;
    }

    /**
     * Retorna lista de projetos ativos
     */
    public static function getProjectsList(): array
    {
        global $DB;
        $entityCriteria = getEntitiesRestrictCriteria('p');
        $iterator = $DB->request([
            'SELECT' => [
                'p.id', 'p.name', 'p.projectstates_id AS status_id', 'p.date_creation AS date', 
                'p.priority', 'p.percent_done', 'p.projects_id', 'p.plan_end_date', 'p.real_end_date',
                'ps.name AS status_name', 'ps.is_finished',
                new QueryExpression("IFNULL(`pt`.`name`, 'Sem Tipo') AS `category`"),
                new QueryExpression("IFNULL(`u`.`name`, 'N/A') AS `user_name`"),
                new QueryExpression("IFNULL(`parent`.`name`, '') AS `parent_name`"),
                new QueryExpression("DATEDIFF(IFNULL(p.real_end_date, NOW()), p.plan_end_date) AS `variance_days`"),
            ],
            'FROM' => 'glpi_projects AS p',
            'LEFT JOIN' => [
                'glpi_projecttypes AS pt' => ['ON' => ['pt' => 'id', 'p' => 'projecttypes_id']],
                'glpi_users AS u' => ['ON' => ['u' => 'id', 'p' => 'users_id']],
                'glpi_projectstates AS ps' => ['ON' => ['ps' => 'id', 'p' => 'projectstates_id']],
                'glpi_projects AS parent' => ['ON' => ['parent' => 'id', 'p' => 'projects_id']]
            ],
            'WHERE' => array_merge([
                'ps.is_finished' => 0,
                'p.is_deleted'   => 0,
                'p.is_template'  => 0,
            ], $entityCriteria),
            'ORDER' => ['p.projects_id ASC', 'p.priority DESC', 'p.date_creation DESC'],
            'LIMIT' => 100,
        ]);
        $projects = [];
        foreach ($iterator as $row) { $projects[] = $row; }
        return $projects;
    }

    /**
     * Retorna lista de tarefas
     */
    public static function getTasksList(): array
    {
        global $DB;
        $entityCriteria = getEntitiesRestrictCriteria('p');
        $iterator = $DB->request([
            'SELECT' => [
                't.id', 't.name', 't.percent_done', 't.is_milestone',
                'p.name AS project_name', 'ps.name AS status', 'u.name AS technician'
            ],
            'FROM' => 'glpi_projecttasks AS t',
            'LEFT JOIN' => [
                'glpi_projects AS p' => ['ON' => ['p' => 'id', 't' => 'projects_id']],
                'glpi_projectstates AS ps' => ['ON' => ['ps' => 'id', 't' => 'projectstates_id']],
                'glpi_users AS u' => ['ON' => ['u' => 'id', 't' => 'users_id']]
            ],
            'WHERE' => array_merge([
                't.is_deleted' => 0, 'p.is_deleted' => 0, 'ps.is_finished' => 0
            ], $entityCriteria),
            'ORDER' => ['t.date_mod DESC'],
            'LIMIT' => 50,
        ]);
        $tasks = [];
        foreach ($iterator as $row) {
            $tasks[] = [
                'id' => $row['id'], 'name' => $row['name'], 'model' => $row['project_name'],
                'status' => $row['status'], 'location' => $row['technician'],
                'disk_total' => 100, 'disk_free' => 100 - $row['percent_done'],
                'is_milestone' => $row['is_milestone']
            ];
        }
        return $tasks;
    }

    private static function countProjects($DB, array $entityCriteria, array $extraWhere): int
    {
        $where = array_merge(['glpi_projects.is_deleted' => 0, 'glpi_projects.is_template' => 0], $extraWhere, $entityCriteria);
        $result = $DB->request([
            'COUNT' => 'cpt', 'FROM' => 'glpi_projects',
            'JOIN' => ['glpi_projectstates AS ps' => ['ON' => ['ps' => 'id', 'glpi_projects' => 'projectstates_id']]],
            'WHERE' => $where,
        ]);
        $row = $result->current();
        return (int) ($row['cpt'] ?? 0);
    }
}
