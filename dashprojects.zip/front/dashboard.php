<?php

/**
 * Plugin DashProjects - Página principal do Dashboard
 */

require_once __DIR__ . '/../../../inc/includes.php';

// Exige usuário logado E com direito de leitura no plugin
Session::checkRight('plugin_dashprojects', READ);

global $CFG_GLPI;

// Caminho base do plugin para o JS
$pluginRoot = $CFG_GLPI['root_doc'] . '/plugins/dashprojects';

// Dados do usuário logado (para o sidebar)
$currentUser = Session::getLoginUserID();
$userName    = getUserName($currentUser);
$userInitials = '';
if (isset($_SESSION['glpiname'])) {
    $parts = explode(' ', $userName);
    $userInitials = mb_strtoupper(mb_substr($parts[0] ?? '', 0, 1) . mb_substr($parts[1] ?? '', 0, 1));
}
if (empty($userInitials)) {
    $userInitials = 'U';
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DashProjects GLPI</title>
    <link href="<?php echo $pluginRoot; ?>/vendor/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $pluginRoot; ?>/vendor/css/fontawesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $pluginRoot; ?>/css/style.css">
    <script>
        // Passa o root do plugin para o JS
        const DASHPROJECTS_ROOT = '<?php echo $pluginRoot; ?>';
    </script>
</head>
<body>
    <div class="tv-indicator">
        <i class="fas fa-tv"></i> MODO TV ATIVO
    </div>

    <button class="floating-menu-btn" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </button>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-project-diagram"></i>
            </div>
            <div class="sidebar-title">DashProjects</div>
            <button class="sidebar-close" onclick="toggleMenu()">
                <i class="fas fa-chevron-left"></i>
            </button>
        </div>

        <nav class="menu-nav">
            <a href="#" class="menu-link active" onclick="showPage('dashboard', this)">
                <i class="fas fa-th-large"></i>
                <span>Visão Geral</span>
            </a>
            <a href="#" class="menu-link" onclick="showPage('sla', this)">
                <i class="fas fa-clock"></i>
                <span>Monitor Prazos</span>
            </a>
            <a href="#" class="menu-link" onclick="showPage('ranking', this)">
                <i class="fas fa-trophy"></i>
                <span>Ranking Gestores</span>
            </a>
            <a href="#" class="menu-link" onclick="showPage('tickets', this)">
                <i class="fas fa-tasks"></i>
                <span>Projetos</span>
            </a>
            <a href="#" class="menu-link" onclick="showPage('assets', this)">
                <i class="fas fa-list-check"></i>
                <span>Tarefas (Grid)</span>
            </a>
            <div style="flex: 1;"></div>
            <a href="<?php echo $CFG_GLPI['root_doc']; ?>/front/central.php" class="menu-link" title="Voltar ao GLPI">
                <i class="fas fa-arrow-left"></i>
                <span>Voltar ao GLPI</span>
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="user-avatar"><?php echo htmlspecialchars($userInitials); ?></div>
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($userName); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($_SESSION['glpiactiveprofile']['name'] ?? 'Usuário'); ?></div>
                </div>
                <button class="theme-toggle" onclick="toggleTheme()">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
        </div>
    </aside>

    <div class="notification-panel" id="notificationPanel">
        <div class="notification-header">
            <h3 class="notification-title">Notificações <span style="padding: 2px 6px; background: var(--warning); color: #000; border-radius: 4px; font-size: 0.6rem; font-weight: 700; vertical-align: middle;">DEMO</span></h3>
            <button class="notification-clear" onclick="clearNotifications()">Limpar Tudo</button>
        </div>
        <div class="notification-list" id="notificationList">
        </div>
    </div>

    <main class="main-content" id="mainContent">
        <div class="page-section active" id="dashboardSection">
            <header class="page-header">
                <div class="page-title-wrapper">
                    <h1>Visão Geral dos Projetos</h1>
                    <div class="page-subtitle">
                        <i class="fas fa-clock"></i>
                        <span>Última atualização: <span id="clock">Carregando...</span></span>
                    </div>
                </div>
            </header>

            <div class="grid-kpi">
                <div class="glass-card kpi-card glow-success">
                    <div>
                        <span class="kpi-icon success"><i class="fas fa-project-diagram"></i></span>
                        <div class="kpi-value" id="top-total"><span class="skeleton">00</span></div>
                    </div>
                    <div class="kpi-label">Total de Projetos</div>
                </div>
                <div class="glass-card kpi-card glow-primary">
                    <div>
                        <span class="kpi-icon primary"><i class="fas fa-spinner fa-pulse"></i></span>
                        <div class="kpi-value" id="top-andamento"><span class="skeleton">00</span></div>
                    </div>
                    <div class="kpi-label">Em Execução</div>
                </div>
                <div class="glass-card kpi-card glow-success">
                    <div>
                        <span class="kpi-icon success"><i class="fas fa-check-circle"></i></span>
                        <div class="kpi-value" id="top-taxa"><span class="skeleton">00%</span></div>
                    </div>
                    <div class="kpi-label">Taxa de Conclusão</div>
                </div>
                <div class="glass-card kpi-card glow-danger">
                    <div>
                        <span class="kpi-icon danger"><i class="fas fa-calendar-times"></i></span>
                        <div class="kpi-value" id="top-sla"><span class="skeleton">0</span></div>
                    </div>
                    <div class="kpi-label">Projetos Atrasados</div>
                </div>
                <div class="glass-card kpi-card glow-primary">
                    <div>
                        <span class="kpi-icon primary"><i class="fas fa-hourglass-half"></i></span>
                        <div class="kpi-value" id="top-tempo"><span class="skeleton">0d</span></div>
                    </div>
                    <div class="kpi-label">Duração Média</div>
                </div>
                <div class="glass-card kpi-card glow-warning">
                    <div>
                        <span class="kpi-icon warning"><i class="fas fa-flag-checkered"></i></span>
                        <div class="kpi-value" id="top-reabertos"><span class="skeleton">0</span></div>
                    </div>
                    <div class="kpi-label">Milestones Concluídos</div>
                </div>
            </div>

            <div class="grid-detail">
                <div class="glass-card detail-card glow-success">
                    <div class="detail-card-header">
                        <span class="kpi-icon success"><i class="fas fa-plus-circle"></i></span>
                    </div>
                    <div class="detail-value" id="bot-abertos">0</div>
                    <div class="detail-label">Novos Projetos</div>
                </div>
                <div class="glass-card detail-card glow-primary">
                    <div class="detail-card-header">
                        <span class="kpi-icon primary"><i class="fas fa-play-circle"></i></span>
                    </div>
                    <div class="detail-value" id="bot-atribuidos">0</div>
                    <div class="detail-label">Em Andamento</div>
                </div>
                <div class="glass-card detail-card glow-warning">
                    <div class="detail-card-header">
                        <span class="kpi-icon warning"><i class="fas fa-pause-circle"></i></span>
                    </div>
                    <div class="detail-value" id="bot-pendentes">0</div>
                    <div class="detail-label">Planejados</div>
                </div>
                <div class="glass-card detail-card glow-success">
                    <div class="detail-card-header">
                        <span class="kpi-icon success"><i class="fas fa-check-double"></i></span>
                    </div>
                    <div class="detail-value" id="bot-finalizados">0</div>
                    <div class="detail-label">Concluídos</div>
                </div>
            </div>

            <div class="grid-charts">
                <div class="glass-card chart-card">
                    <div class="chart-header">
                        <h3 class="chart-title">Criação de Projetos</h3>
                        <span style="font-size: 0.8rem; color: var(--text-muted);">Últimos 30 dias</span>
                    </div>
                    <div class="chart-container"><canvas id="lineChart"></canvas></div>
                </div>
                <div class="glass-card chart-card">
                    <div class="chart-header">
                        <h3 class="chart-title">Top Tipos de Projeto</h3>
                    </div>
                    <div class="chart-container"><canvas id="barChart"></canvas></div>
                </div>
                <div class="glass-card chart-card" style="grid-column: span 2;">
                    <div class="chart-header">
                        <h3 class="chart-title">Abertos vs Concluídos (Últimos 6 Meses)</h3>
                    </div>
                    <div class="chart-container"><canvas id="monthlyChart"></canvas></div>
                </div>
            </div>

            <div class="glass-card table-card">
                <div class="table-header">
                    <h3 class="table-title">Projetos Recentes</h3>
                    <a href="#" class="table-link" onclick="showPage('tickets', document.querySelectorAll('.menu-link')[3])">
                        Ver Todos os Projetos
                    </a>
                </div>
                <div class="table-responsive">
                    <table class="custom-table">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>ID & Nome</th>
                                <th>Tipo</th>
                                <th>Progresso</th>
                                <th style="text-align: right;">Desvio</th>
                            </tr>
                        </thead>
                        <tbody id="recent-tickets-body">
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: var(--text-muted);"></i>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- SLA Section -->
        <div class="page-section" id="slaSection">
            <header class="page-header">
                <div class="page-title-wrapper">
                    <h1>Monitor de Prazos</h1>
                    <div class="page-subtitle">
                        <i class="fas fa-stopwatch"></i>
                        <span>Acompanhamento de deadlines em tempo real</span>
                    </div>
                </div>
            </header>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 24px;">
                <div class="glass-card" style="padding: 32px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 12px;">
                        <i class="fas fa-exclamation-triangle" style="color: var(--danger);"></i>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 800; color: var(--danger); margin-bottom: 8px;" id="slaCritical">0</div>
                    <div style="font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Atrasados</div>
                </div>
                <div class="glass-card" style="padding: 32px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 12px;">
                        <i class="fas fa-clock" style="color: var(--warning);"></i>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 800; color: var(--warning); margin-bottom: 8px;" id="slaWarning">0</div>
                    <div style="font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Próximo ao Vencimento</div>
                </div>
                <div class="glass-card" style="padding: 32px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 12px;">
                        <i class="fas fa-check-circle" style="color: var(--success);"></i>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 800; color: var(--success); margin-bottom: 8px;" id="slaOk">0</div>
                    <div style="font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">No Prazo</div>
                </div>
            </div>
            <div class="glass-card">
                <h3 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 24px; padding: 0 24px;">Projetos com Entrega Próxima</h3>
                <div class="sla-widget" id="slaList" style="padding: 0 24px 24px;"></div>
            </div>
        </div>

        <!-- Ranking Section -->
        <div class="page-section" id="rankingSection">
            <header class="page-header">
                <div class="page-title-wrapper">
                    <h1>Ranking de Gestores</h1>
                    <div class="page-subtitle">
                        <i class="fas fa-trophy"></i>
                        <span>Entregas e Performance</span>
                    </div>
                </div>
            </header>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="glass-card h-100">
                        <div class="chart-header">
                            <h3 class="chart-title">Líderes de Projetos</h3>
                        </div>
                        <div id="leaderboard-container" class="leaderboard-container mt-3">
                            <div class="text-center p-5">
                                <i class="fas fa-spinner fa-spin fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="glass-card text-center mb-4" style="border-color: var(--gold) !important;">
                        <i class="fas fa-crown fa-3x mb-3" style="color: var(--warning);"></i>
                        <h5 style="color: var(--text-main);">Gestor do Mês</h5>
                        <h2 id="top-tech-name" class="fw-bold mt-2" style="color: var(--text-main);">--</h2>
                        <p style="color: var(--text-sec); font-size: 0.85rem;">Maior número de entregas</p>
                    </div>
                    <div class="glass-card">
                        <h5 class="mb-3" style="color: var(--text-main);">Como pontuar?</h5>
                        <ul class="list-unstyled" style="color: var(--text-sec); font-size: 0.85rem;">
                            <li class="mb-2"><i class="fas fa-check me-2" style="color: var(--success);"></i> Projeto Concluído: +50 pts</li>
                            <li class="mb-2"><i class="fas fa-clock me-2" style="color: var(--primary);"></i> Prazo Antecipado: +20 pts</li>
                            <li class="mb-2"><i class="fas fa-star me-2" style="color: var(--warning);"></i> Milestone Atingido: +10 pts</li>
                            <li><i class="fas fa-times me-2" style="color: var(--danger);"></i> Atraso na Entrega: -30 pts</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Project List Section -->
        <div class="page-section" id="ticketsSection">
            <header class="page-header">
                <h1>Listagem Geral de Projetos</h1>
            </header>
            <div class="glass-card table-card">
                <div class="table-responsive">
                    <table class="custom-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Tipo</th>
                                <th>Progresso</th>
                                <th>Desvio</th>
                                <th>Gestor</th>
                                <th>Criação</th>
                            </tr>
                        </thead>
                        <tbody id="tickets-full-body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Task Grid Section -->
        <div class="page-section" id="assetsSection">
            <header class="page-header">
                <div class="page-title-wrapper">
                    <h1>Tarefas de Projeto</h1>
                    <div class="page-subtitle">
                        <i class="fas fa-list-check"></i>
                        <span>Acompanhamento de atividades e progresso</span>
                    </div>
                </div>
            </header>
            <div id="assets-grid" class="assets-grid-container">
                <div class="text-center p-5">
                    <i class="fas fa-circle-notch fa-spin fa-2x"></i> Carregando tarefas...
                </div>
            </div>
        </div>
    </main>

    <!-- Modal Tarefa -->
    <div id="cyber-modal" class="cyber-overlay">
        <div class="cyber-hud">
            <button class="cyber-close" onclick="closeCyberModal()">
                <i class="fas fa-times"></i>
            </button>
            <div class="cyber-header">
                <div class="cyber-id-badge">ID: <span id="modal-id">000</span></div>
                <h2 id="modal-name" class="cyber-glitch-text">NOME_TAREFA</h2>
                <div class="cyber-sub" id="modal-sub">PROJETO</div>
            </div>
            <div class="cyber-grid-layout">
                <div class="cyber-col-left">
                    <div class="cyber-box">
                        <div class="cyber-label">STATUS</div>
                        <div class="cyber-status-text" id="modal-status">EM ANDAMENTO</div>
                    </div>
                    <div class="cyber-box">
                        <div class="cyber-label">RESPONSÁVEL</div>
                        <div class="cyber-os-display" id="modal-loc">
                            Técnico N/A
                        </div>
                    </div>
                </div>
                <div class="cyber-col-right">
                    <div class="cyber-stat-row">
                        <div class="stat-label"><i class="fas fa-chart-line"></i> PROGRESSO</div>
                        <div class="stat-value-text" id="modal-hdd">0%</div>
                        <div class="cyber-progress-bg">
                            <div class="cyber-progress-fill" id="bar-hdd" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cyber-footer">
                <div class="cyber-scanline"></div>
                <span>TAREFA DE PROJETO // MONITORAMENTO ATIVO</span>
            </div>
        </div>
    </div>

    <script src="<?php echo $pluginRoot; ?>/vendor/js/chart.umd.min.js"></script>
    <script src="<?php echo $pluginRoot; ?>/js/script.js"></script>
</body>
</html>
