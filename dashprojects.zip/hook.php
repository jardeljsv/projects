<?php

/**
 * Plugin DashProjects - Hook functions
 */

/**
 * Instalação do plugin
 */
function plugin_dashprojects_install()
{
    return true;
}

/**
 * Desinstalação do plugin
 */
function plugin_dashprojects_uninstall()
{
    return true;
}

/**
 * Adiciona o Dashboard no menu de navegação do GLPI
 */
function plugin_dashprojects_redefine_menus($menus)
{
    global $CFG_GLPI;

    if (Session::getLoginUserID()) {
        $menus['helpdesk']['content']['dashprojects'] = [
            'title' => __('DashProjects', 'dashprojects'),
            'page'  => $CFG_GLPI['root_doc'] . '/plugins/dashprojects/front/dashboard.php',
            'icon'  => 'ti ti-chart-dots',
        ];
    }

    return $menus;
}
