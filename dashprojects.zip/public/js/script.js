// ==================== GLOBAL VARIABLES ====================
const PLUGIN_ROOT = (typeof DASHPROJECTS_ROOT !== 'undefined') ? DASHPROJECTS_ROOT : '';

function escHtml(str) {
    const d = document.createElement('div');
    d.textContent = str ?? '';
    return d.innerHTML;
}

let lineChart, barChart, monthlyChart;
let tvMode = false;
let notificationCount = 3;
let tasksDataGlobal = [];

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initCharts();
    initNotifications();
    initSLAMonitor();
    updateData();
    loadFullTasks();

    updateClock();
    setInterval(updateClock, 1000);
    setInterval(updateData, 60000);
});

// ==================== THEME ====================
function initTheme() {
    const savedTheme = localStorage.getItem('glpi-theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
        updateThemeIcon();
    }
}

function toggleTheme() {
    document.body.classList.toggle('light-mode');
    const isLight = document.body.classList.contains('light-mode');
    localStorage.setItem('glpi-theme', isLight ? 'light' : 'dark');
    updateThemeIcon();

    if (lineChart) lineChart.destroy();
    if (barChart) barChart.destroy();
    if (monthlyChart) monthlyChart.destroy();
    initCharts();
    updateData();
}

function updateThemeIcon() {
    const icon = document.querySelector('.theme-toggle i');
    if (document.body.classList.contains('light-mode')) {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
}

// ==================== MENU ====================
function toggleMenu() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');

    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('expanded');

    if (sidebar.classList.contains('collapsed')) {
        document.body.classList.add('menu-closed');
    } else {
        document.body.classList.remove('menu-closed');
    }

    setTimeout(() => {
        if (lineChart) lineChart.resize();
        if (barChart) barChart.resize();
        if (monthlyChart) monthlyChart.resize();
    }, 350);
}

// ==================== PAGE NAVIGATION ====================
function showPage(pageId, linkElement) {
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.remove('active');
    });

    document.getElementById(pageId + 'Section').classList.add('active');

    document.querySelectorAll('.menu-link').forEach(link => {
        link.classList.remove('active');
    });
    linkElement.classList.add('active');

    if (pageId === 'ranking') renderLeaderboard();
    if (pageId === 'assets') loadFullTasks();

    setTimeout(() => {
        if (lineChart) lineChart.resize();
        if (barChart) barChart.resize();
        if (monthlyChart) monthlyChart.resize();
    }, 150);
}

// ==================== CLOCK ====================
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent =
        now.toLocaleDateString('pt-BR') + ' ' + now.toLocaleTimeString('pt-BR');
}

// ==================== TV MODE ====================
function toggleTVMode() {
    tvMode = !tvMode;
    document.body.classList.toggle('tv-mode');

    if (tvMode) {
        if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen();
        startTVRotation();
    } else {
        if (document.exitFullscreen) document.exitFullscreen();
        stopTVRotation();
    }
}

let tvRotationInterval;
function startTVRotation() {
    const pages = ['dashboard', 'sla', 'ranking', 'assets'];
    let currentIndex = 0;

    tvRotationInterval = setInterval(() => {
        currentIndex = (currentIndex + 1) % pages.length;
        const pageId = pages[currentIndex];
        const menuLinks = document.querySelectorAll('.menu-link');
        const targetLink = Array.from(menuLinks).find(l => l.getAttribute('onclick')?.includes(pageId));
        if (targetLink) showPage(pageId, targetLink);
    }, 15000);
}

function stopTVRotation() {
    clearInterval(tvRotationInterval);
}

// ==================== DATA UPDATE ====================
async function updateData() {
    try {
        const response = await fetch(PLUGIN_ROOT + '/ajax/dashboard.php?action=dashboard_data');
        const data = await response.json();

        setVal('top-total', data.cards_top.total);
        setVal('top-andamento', data.cards_top.andamento);
        setVal('top-taxa', data.cards_top.taxa + '%');
        setVal('top-sla', data.cards_top.sla);
        setVal('top-tempo', data.cards_top.tempo_medio + 'd');
        setVal('top-reabertos', data.cards_top.reabertos);
        setVal('bot-abertos', data.cards_bottom.abertos);
        setVal('bot-atribuidos', data.cards_bottom.atribuidos);
        setVal('bot-pendentes', data.cards_bottom.pendentes);
        setVal('bot-finalizados', data.cards_bottom.finalizados);

        if (lineChart) {
            lineChart.data.labels = data.charts.trend_line.map(x => x.dia);
            lineChart.data.datasets[0].data = data.charts.trend_line.map(x => x.total);
            lineChart.update('none');
        }

        if (barChart) {
            barChart.data.labels = data.charts.cat_bar.map(x => x.nome);
            barChart.data.datasets[0].data = data.charts.cat_bar.map(x => x.total);
            barChart.update('none');
        }

        if (monthlyChart && data.charts.monthly_opened && data.charts.monthly_solved) {
            const processed = processMonthlyData(data.charts.monthly_opened, data.charts.monthly_solved);
            monthlyChart.data.labels = processed.labels;
            monthlyChart.data.datasets[0].data = processed.opened;
            monthlyChart.data.datasets[1].data = processed.solved;
            monthlyChart.update('none');
        }

        loadProjectLists();
    } catch (error) {
        console.error('Error updating data:', error);
    }
}

function processMonthlyData(openedData, solvedData) {
    const labels = [];
    const dataOpened = [];
    const dataSolved = [];
    const today = new Date();
    for (let i = 5; i >= 0; i--) {
        const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        const key = `${year}-${month}`;
        labels.push(`${month}/${year.toString().substring(2)}`);
        const foundOpen = openedData.find(item => item.mes_ano === key);
        dataOpened.push(foundOpen ? parseInt(foundOpen.total) : 0);
        const foundSolved = solvedData.find(item => item.mes_ano === key);
        dataSolved.push(foundSolved ? parseInt(foundSolved.total) : 0);
    }
    return { labels, opened: dataOpened, solved: dataSolved };
}

function setVal(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
        element.classList.remove('skeleton');
    }
}

// ==================== CHARTS ====================
function initCharts() {
    const isLight = document.body.classList.contains('light-mode');
     Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    Chart.defaults.color = isLight ? '#94a3b8' : 'rgba(255, 255, 255, 0.3)';
    const gridColor = isLight ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)';
    const primaryColor = '#3b82f6';

    const lineCtx = document.getElementById('lineChart');
    if (lineCtx) {
        lineChart = new Chart(lineCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Projetos',
                    data: [],
                    borderColor: primaryColor,
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, grid: { color: gridColor } }
                }
            }
        });
    }

    const barCtx = document.getElementById('barChart');
    if (barCtx) {
        barChart = new Chart(barCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Quantidade',
                    data: [],
                    backgroundColor: primaryColor,
                    borderRadius: 8
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { beginAtZero: true, grid: { display: false } },
                    y: { grid: { display: false } }
                }
            }
        });
    }

    const monthlyCtx = document.getElementById('monthlyChart');
    if (monthlyCtx) {
        monthlyChart = new Chart(monthlyCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [
                    { label: 'Abertos', data: [], backgroundColor: 'rgba(59, 130, 246, 0.8)', borderRadius: 4 },
                    { label: 'Concluídos', data: [], backgroundColor: 'rgba(34, 197, 94, 0.8)', borderRadius: 4 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, grid: { color: gridColor } }
                }
            }
        });
    }
}

// ==================== LOAD PROJECT LISTS ====================
async function loadProjectLists() {
    try {
        const response = await fetch(PLUGIN_ROOT + '/ajax/dashboard.php?action=tickets_list');
        const projects = await response.json();

        const recentBody = document.getElementById('recent-tickets-body');
        const fullBody = document.getElementById('tickets-full-body');

        if (projects.length > 0) {
            const renderRow = (project, isFull = false) => {
                const percent = parseInt(project.percent_done) || 0;
                const variance = parseInt(project.variance_days) || 0;
                const isChild = project.projects_id > 0;
                
                let varianceHtml = '';
                if (variance > 0) {
                    varianceHtml = `<span class="badge-variance danger"><i class="fas fa-arrow-up"></i> ${variance} dias</span>`;
                } else if (variance < 0) {
                    varianceHtml = `<span class="badge-variance success"><i class="fas fa-arrow-down"></i> ${Math.abs(variance)} dias</span>`;
                } else {
                    varianceHtml = `<span class="badge-variance info">No prazo</span>`;
                }

                const nameHtml = isChild 
                    ? `<div class="project-name-cell child"><i class="fas fa-level-up-alt fa-rotate-90"></i> ${escHtml(project.name)}</div>`
                    : `<div class="project-name-cell parent">${escHtml(project.name)}</div>`;

                if (!isFull) {
                    return `
                        <tr class="${isChild ? 'row-child' : 'row-parent'}">
                            <td>
                                <div class="table-status-icon ${percent === 100 ? 'success' : (percent > 0 ? 'primary' : 'warning')}">
                                    <i class="fas ${percent === 100 ? 'fa-check-circle' : 'fa-spinner fa-pulse'}"></i>
                                </div>
                            </td>
                            <td>
                                <div class="table-ticket-info">
                                    <div class="table-ticket-title">${nameHtml}</div>
                                    <div class="table-ticket-id">#${project.id} ${isChild ? `<span class="parent-ref">Pai: ${escHtml(project.parent_name)}</span>` : ''}</div>
                                </div>
                            </td>
                            <td><span class="table-badge">${escHtml(project.category)}</span></td>
                            <td>
                                <div class="prog-wrapper">
                                    <div class="prog-bar"><div class="prog-fill" style="width: ${percent}%"></div></div>
                                    <span class="prog-text">${percent}%</span>
                                </div>
                            </td>
                            <td style="text-align: right;">${varianceHtml}</td>
                        </tr>
                    `;
                } else {
                    return `
                        <tr class="${isChild ? 'row-child' : 'row-parent'}">
                            <td><strong>#${project.id}</strong></td>
                            <td>${nameHtml}</td>
                            <td><span class="table-badge">${escHtml(project.category)}</span></td>
                            <td>
                                <div class="prog-wrapper">
                                    <div class="prog-bar"><div class="prog-fill" style="width: ${percent}%"></div></div>
                                    <span class="prog-text">${percent}%</span>
                                </div>
                            </td>
                            <td>${varianceHtml}</td>
                            <td>${escHtml(project.user_name || '-')}</td>
                            <td>${escHtml(project.date)}</td>
                        </tr>
                    `;
                }
            };

            recentBody.innerHTML = projects.slice(0, 10).map(p => renderRow(p, false)).join('');
            fullBody.innerHTML = projects.map(p => renderRow(p, true)).join('');
        } else {
            recentBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px;">Nenhum projeto encontrado</td></tr>';
            fullBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;">Nenhum projeto encontrado</td></tr>';
        }
    } catch (error) {
        console.error('Error loading projects:', error);
    }
}

// ==================== PROJECT TASKS (GRID) ====================
async function loadFullTasks() {
    const gridContainer = document.getElementById('assets-grid');
    if (!gridContainer) return;
    try {
        const response = await fetch(PLUGIN_ROOT + '/ajax/dashboard.php?action=assets_list');
        tasksDataGlobal = await response.json();
        if (!tasksDataGlobal || tasksDataGlobal.length === 0) {
            gridContainer.innerHTML = '<div class="text-center p-5 text-muted">Nenhuma tarefa encontrada.</div>';
            return;
        }
        gridContainer.innerHTML = tasksDataGlobal.map((task, index) => {
            const percent = 100 - (parseFloat(task.disk_free) || 0);
            const statusColor = task.is_milestone == 1 ? '#ffee00' : '#00f3ff';
            return `
                <div class="asset-card-cyber" onclick="openCyberModal(${index})">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <div class="cyber-card-title">${escHtml(task.name)}</div>
                            <div class="cyber-card-meta"><i class="fas ${task.is_milestone == 1 ? 'fa-flag' : 'fa-check-square'}"></i> ${escHtml(task.model)}</div>
                        </div>
                        <div style="width: 10px; height: 10px; background: ${statusColor}; border-radius: 50%; box-shadow: 0 0 8px ${statusColor};"></div>
                    </div>
                    <div style="margin-top: 10px;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.7rem; color: rgba(255,255,255,0.7); font-family: 'Share Tech Mono';">
                            <span>PROGRESSO</span><span>${percent.toFixed(0)}%</span>
                        </div>
                        <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); margin-top: 2px;">
                            <div style="width: ${percent}%; height: 100%; background: ${percent === 100 ? 'var(--success)' : 'var(--neon-blue)'}; box-shadow: 0 0 5px ${percent === 100 ? 'var(--success)' : 'var(--neon-blue)'};"></div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) { console.error('Error loading tasks:', error); }
}

function openCyberModal(index) {
    const task = tasksDataGlobal[index];
    if (!task) return;
    document.getElementById('modal-id').innerText = (task.id || '0').toString().padStart(3, '0');
    document.getElementById('modal-name').innerText = task.name || 'UNKNOWN';
    document.getElementById('modal-sub').innerText = (task.model || 'PROJETO N/A').toUpperCase();
    document.getElementById('modal-status').innerText = (task.status || 'EM ANDAMENTO').toUpperCase();
    document.getElementById('modal-loc').innerText = (task.location || 'NÃO ATRIBUÍDA').toUpperCase();
    const percent = 100 - (parseFloat(task.disk_free) || 0);
    document.getElementById('modal-hdd').innerText = percent.toFixed(0) + '% CONCLUÍDO';
    const modal = document.getElementById('cyber-modal');
    modal.classList.add('active');
    setTimeout(() => {
        const hddBar = document.getElementById('bar-hdd');
        hddBar.style.width = percent + '%';
        hddBar.style.background = percent === 100 ? 'var(--success)' : 'linear-gradient(90deg, var(--neon-blue), var(--neon-pink))';
    }, 100);
}

function closeCyberModal() {
    document.getElementById('cyber-modal').classList.remove('active');
    document.getElementById('bar-hdd').style.width = '0%';
}

document.addEventListener('click', (e) => {
    if (e.target.id === 'cyber-modal') closeCyberModal();
});

// ==================== SLA MONITOR ====================
function initSLAMonitor() {
    updateSLAData();
    setInterval(updateSLACountdowns, 1000);
}

function updateSLAData() {
    const slaItems = [
        { id: 1, title: 'Entrega Fase 1 - ERP', ticket: 'Proj #10', deadline: new Date(Date.now() + 30 * 60000), status: 'critical' },
        { id: 2, title: 'Migração de Dados', ticket: 'Proj #12', deadline: new Date(Date.now() + 120 * 60000), status: 'warning' },
        { id: 3, title: 'Treinamento Usuários', ticket: 'Proj #08', deadline: new Date(Date.now() + 480 * 60000), status: 'ok' }
    ];
    renderSLAList(slaItems);
    updateSLASummary(slaItems);
}

function renderSLAList(items) {
    const container = document.getElementById('slaList');
    if (!container) return;
    container.innerHTML = items.map(item => `
        <div class="sla-item ${item.status}">
            <div class="sla-icon-item ${item.status}"><i class="fas ${item.status === 'critical' ? 'fa-exclamation-triangle' : item.status === 'warning' ? 'fa-clock' : 'fa-check-circle'}"></i></div>
            <div class="sla-info">
                <div class="sla-title">${item.title}</div>
                <div class="sla-subtitle">${item.ticket}</div>
            </div>
            <div class="sla-countdown">
                <div class="sla-time ${item.status}" data-deadline="${item.deadline.getTime()}">--:--</div>
                <div class="sla-label">Restante</div>
            </div>
        </div>
    `).join('');
}

function updateSLACountdowns() {
    document.querySelectorAll('.sla-time[data-deadline]').forEach(el => {
        const deadline = parseInt(el.getAttribute('data-deadline'));
        const now = Date.now();
        const diff = deadline - now;
        if (diff <= 0) { el.textContent = 'ATRASADO'; return; }
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        el.textContent = `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    });
}

function updateSLASummary(items) {
    setVal('slaCritical', items.filter(i => i.status === 'critical').length);
    setVal('slaWarning', items.filter(i => i.status === 'warning').length);
    setVal('slaOk', items.filter(i => i.status === 'ok').length);
}

// ==================== NOTIFICATIONS ====================
function initNotifications() {
    const initialNotifications = [
        { id: 1, type: 'danger', text: 'Prazo crítico: Entrega Fase 1 vence em 30 min', time: 'Agora', unread: true },
        { id: 2, type: 'success', text: 'Projeto #08 concluído', time: '5 min atrás', unread: true }
    ];
    renderNotifications(initialNotifications);
}

function renderNotifications(notifications) {
    const list = document.getElementById('notificationList');
    if (notifications.length === 0) {
        list.innerHTML = '<p style="text-align: center; padding: 40px; color: var(--text-muted);">Nenhuma notificação</p>';
        return;
    }
    list.innerHTML = notifications.map(n => `
        <div class="notification-item ${n.unread ? 'unread' : ''}">
            <div class="notification-icon ${n.type}"><i class="fas ${n.type === 'danger' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i></div>
            <div class="notification-content">
                <div class="notification-text">${n.text}</div>
                <div class="notification-time">${n.time}</div>
            </div>
        </div>
    `).join('');
}

function toggleNotifications() { document.getElementById('notificationPanel').classList.toggle('show'); }
function clearNotifications() { renderNotifications([]); document.getElementById('notificationBadge').style.display = 'none'; }

// ==================== RANKING ====================
async function renderLeaderboard() {
    const container = document.getElementById('leaderboard-container');
    if (!container) return;
    try {
        const response = await fetch(PLUGIN_ROOT + '/ajax/dashboard.php?action=get_ranking');
        const technicians = await response.json();
        if (!technicians || technicians.length === 0) {
            container.innerHTML = '<div class="text-center p-5 text-muted">Nenhum projeto finalizado.</div>';
            return;
        }
        const maxPoints = Math.max(...technicians.map(t => t.points)) || 1;
        container.innerHTML = technicians.map((tech, index) => {
            const rank = index + 1;
            const percent = (tech.points / maxPoints) * 100;
            return `
                <div class="leaderboard-item rank-${rank > 3 ? 'other' : rank}" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--card-bg); border-bottom: 1px solid var(--border-color); margin-bottom: 8px; border-radius: 12px;">
                    <div style="width: 30px; text-align:center; font-weight:700;">${rank === 1 ? '👑' : `#${rank}`}</div>
                    <div style="width: 46px; height: 46px; border-radius: 50%; background: ${tech.color}20; color: ${tech.color}; display: flex; align-items: center; justify-content: center; font-weight: 700; border: 2px solid ${tech.color}; flex-shrink: 0;">${tech.avatar}</div>
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                            <span style="font-weight: 600;">${escHtml(tech.name)}</span>
                            <span style="color: ${tech.color}; font-weight: 700;">${tech.points} pts</span>
                        </div>
                        <div style="width: 100%; height: 6px; background: var(--glass-bg); border-radius: 10px; overflow: hidden;">
                            <div style="width: ${percent}%; height: 100%; background: ${tech.color};" class="progress-bar-anim"></div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) { console.error('Erro ao carregar ranking:', error); }
}

document.addEventListener('click', (e) => {
    const panel = document.getElementById('notificationPanel');
    if (panel && !panel.contains(e.target) && !e.target.closest('.icon-btn')) panel.classList.remove('show');
});
