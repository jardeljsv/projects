<?php
$path = dirname(__DIR__) . '/assets/js/widget.js';
if (!is_file($path)) {
    http_response_code(404);
    exit;
}
$mtime = (int)@filemtime($path);
header('Content-Type: application/javascript; charset=UTF-8');
header('Cache-Control: public, max-age=300');
if ($mtime > 0) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
}
readfile($path);
