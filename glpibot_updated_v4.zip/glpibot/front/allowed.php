<?php
// /plugins/glpibot/front/allowed.php
// Widget visibility gate. Uses GLPI's own bootstrap/session/config.

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

header('Content-Type: application/json; charset=UTF-8');
header('Vary: Cookie');
@ini_set('display_errors', '0');

$glpiRoot = null;
if (!glpibot_bootstrap_glpi_runtime($glpiRoot)) {
    glpibot_json_response(200, [
        'enabled' => true,
        'restricted' => true,
        'allowed' => false,
        'uncertain' => false,
        'reason' => 'glpi_bootstrap_unavailable'
    ]);
}

$cfg = glpibot_load_plugin_config_glpi();
$uid = glpibot_resolve_uid_glpi_runtime();
$result = glpibot_resolve_widget_visibility_glpi($cfg, $uid);

glpibot_json_response(200, $result);
