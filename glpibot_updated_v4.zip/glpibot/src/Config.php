<?php

namespace GlpiPlugin\Glpibot;

use CommonGLPI;
use Session;
use Glpi\Application\View\TemplateRenderer;

class Config extends \Config
{
    public static function getTypeName($nb = 0)
    {
        return __('GLPIBot', 'glpibot');
    }

    public static function getConfig(): array
    {
        return \Config::getConfigurationValues('plugin:glpibot');
    }

    private static function fetchGroupsList(): array
    {
        $groups = [];

        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            return $groups;
        }

        try {
            if (method_exists($DB, 'request')) {
                $it = $DB->request([
                    'SELECT' => ['id', 'name'],
                    'FROM'   => 'glpi_groups',
                    'ORDER'  => ['name'],
                ]);
                foreach ($it as $row) {
                    if (!is_array($row)) continue;
                    $id = isset($row['id']) ? (int)$row['id'] : 0;
                    $name = isset($row['name']) ? (string)$row['name'] : '';
                    if ($id > 0) {
                        $groups[] = ['id' => $id, 'name' => $name];
                    }
                }
                return $groups;
            }
        } catch (\Throwable $e) {
            // fall back below
        }

        try {
            if (method_exists($DB, 'query')) {
                $res = @$DB->query("SELECT `id`, `name` FROM `glpi_groups` ORDER BY `name` ASC");
                if ($res) {
                    if (method_exists($DB, 'fetchAssoc')) {
                        while ($row = $DB->fetchAssoc($res)) {
                            $id = isset($row['id']) ? (int)$row['id'] : 0;
                            $name = isset($row['name']) ? (string)$row['name'] : '';
                            if ($id > 0) {
                                $groups[] = ['id' => $id, 'name' => $name];
                            }
                        }
                    } elseif (method_exists($DB, 'fetch_assoc')) {
                        while ($row = $DB->fetch_assoc($res)) {
                            $id = isset($row['id']) ? (int)$row['id'] : 0;
                            $name = isset($row['name']) ? (string)$row['name'] : '';
                            if ($id > 0) {
                                $groups[] = ['id' => $id, 'name' => $name];
                            }
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return $groups;
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case \Config::class:
                return self::createTabEntry(self::getTypeName());
        }
        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case \Config::class:
                return self::showForConfig($item, $withtemplate);
        }
        return true;
    }

    public static function showForConfig(\Config $config, $withtemplate = 0)
    {
        if (!self::canView()) {
            return false;
        }

        $current_config = self::getConfig();
        $canedit        = Session::haveRight(self::$rightname, UPDATE);
        $groups         = self::fetchGroupsList();

        TemplateRenderer::getInstance()->display('@glpibot/config.html.twig', [
            'current_config' => $current_config,
            'can_edit'       => $canedit,
            'groups'         => $groups,
            'plugin_key'     => 'glpibot'
        ]);

        return true;
    }
}
