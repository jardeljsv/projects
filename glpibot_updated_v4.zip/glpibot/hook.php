<?php

function plugin_glpibot_install() {
   \Config::setConfigurationValues('plugin:glpibot', [
      'enable_widget'        => 1,
      'api_base_url'         => '',
      'api_key'              => '',
      'api_chat_path'        => '/chat',
      'api_health_path'      => '/health',
      'request_timeout_ms'   => 60000,
      'allowed_groups'       => '',
      'default_profile_name' => 'Default API',
      'api_profiles_json'    => '',
      'group_routes_json'    => ''
   ]);

   return true;
}

function plugin_glpibot_uninstall() {
   $cfg = new \Config();
   $cfg->deleteByCriteria(['context' => 'plugin:glpibot']);
   return true;
}
