<?php
// Common GLPIBot helpers shared by setup.php, config UI, and bootstrapless endpoints.

if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

if (!function_exists('glpibot_string')) {
    function glpibot_string($v, string $default = ''): string {
        if ($v === null) {
            return $default;
        }
        if (is_string($v)) {
            return trim($v);
        }
        if (is_scalar($v)) {
            return trim((string)$v);
        }
        return $default;
    }
}

if (!function_exists('glpibot_bool')) {
    function glpibot_bool($v, bool $default = false): bool {
        if (is_bool($v)) {
            return $v;
        }
        if (is_int($v) || is_float($v)) {
            return ((int)$v) !== 0;
        }
        if (is_string($v)) {
            $s = strtolower(trim($v));
            if ($s === '') {
                return $default;
            }
            if (in_array($s, ['1', 'true', 'yes', 'y', 'on'], true)) {
                return true;
            }
            if (in_array($s, ['0', 'false', 'no', 'n', 'off'], true)) {
                return false;
            }
        }
        return $default;
    }
}

if (!function_exists('glpibot_int')) {
    function glpibot_int($v, int $default = 0, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int {
        if (!is_numeric($v)) {
            return $default;
        }
        $n = (int)$v;
        if ($n < $min) $n = $min;
        if ($n > $max) $n = $max;
        return $n;
    }
}

if (!function_exists('glpibot_parse_id_list')) {
    function glpibot_parse_id_list($raw): array {
        $raw = is_string($raw) ? trim($raw) : '';
        if ($raw === '') {
            return [];
        }

        $j = json_decode($raw, true);
        if (is_array($j)) {
            $out = [];
            foreach ($j as $v) {
                $id = (int)$v;
                if ($id > 0) $out[$id] = $id;
            }
            return array_values($out);
        }

        if (preg_match('/^\d+$/', $raw)) {
            $id = (int)$raw;
            return $id > 0 ? [$id] : [];
        }

        $parts = preg_split('/[,\s]+/', $raw);
        if (!is_array($parts)) {
            return [];
        }

        $out = [];
        foreach ($parts as $p) {
            $id = (int)$p;
            if ($id > 0) $out[$id] = $id;
        }
        return array_values($out);
    }
}

if (!function_exists('glpibot_get_current_uid_glpi')) {
    function glpibot_get_current_uid_glpi(): int {
        try {
            if (class_exists('Session') && method_exists('Session', 'getLoginUserID')) {
                $uid = (int)\Session::getLoginUserID();
                if ($uid > 0) {
                    return $uid;
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        if (isset($_SESSION['glpiID'])) {
            $uid = (int)$_SESSION['glpiID'];
            if ($uid > 0) {
                return $uid;
            }
        }

        return 0;
    }
}

if (!function_exists('glpibot_get_groups_from_session_glpi')) {
    function glpibot_get_groups_from_session_glpi(): array {
        $ids = [];
        if (!isset($_SESSION) || !is_array($_SESSION) || !isset($_SESSION['glpigroups']) || !is_array($_SESSION['glpigroups'])) {
            return [];
        }

        foreach ($_SESSION['glpigroups'] as $k => $v) {
            if (is_numeric($k)) {
                $gid = (int)$k;
                if ($gid > 0) {
                    $ids[$gid] = true;
                }
            }
            if (is_numeric($v)) {
                $gid = (int)$v;
                if ($gid > 0) {
                    $ids[$gid] = true;
                }
            }
        }

        return array_keys($ids);
    }
}

if (!function_exists('glpibot_get_groups_from_db_glpi')) {
    function glpibot_get_groups_from_db_glpi(int $uid): array {
        $ids = [];

        global $DB;
        if (!isset($DB) || !is_object($DB) || $uid <= 0) {
            return [];
        }

        try {
            if (method_exists($DB, 'request')) {
                $it = $DB->request([
                    'SELECT' => ['groups_id'],
                    'FROM'   => 'glpi_groups_users',
                    'WHERE'  => ['users_id' => $uid],
                ]);
                foreach ($it as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                    if ($gid > 0) {
                        $ids[$gid] = true;
                    }
                }
                return array_keys($ids);
            }
        } catch (\Throwable $e) {
            // ignore and try fallback
        }

        try {
            if (method_exists($DB, 'query')) {
                $res = @$DB->query('SELECT `groups_id` FROM `glpi_groups_users` WHERE `users_id` = ' . (int)$uid);
                if ($res) {
                    if (method_exists($DB, 'fetchAssoc')) {
                        while ($row = $DB->fetchAssoc($res)) {
                            $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                            if ($gid > 0) {
                                $ids[$gid] = true;
                            }
                        }
                    } elseif (method_exists($DB, 'fetch_assoc')) {
                        while ($row = $DB->fetch_assoc($res)) {
                            $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                            if ($gid > 0) {
                                $ids[$gid] = true;
                            }
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return array_keys($ids);
    }
}

if (!function_exists('glpibot_resolve_current_user_groups_glpi')) {
    function glpibot_resolve_current_user_groups_glpi(int $uid = 0): array {
        $ids = glpibot_get_groups_from_session_glpi();
        if (empty($ids)) {
            if ($uid <= 0) {
                $uid = glpibot_get_current_uid_glpi();
            }
            if ($uid > 0) {
                $ids = glpibot_get_groups_from_db_glpi($uid);
            }
        }

        $out = [];
        foreach ($ids as $gid) {
            $gid = (int)$gid;
            if ($gid > 0) {
                $out[$gid] = true;
            }
        }
        return array_keys($out);
    }
}

if (!function_exists('glpibot_expand_group_ancestors_glpi')) {
    function glpibot_expand_group_ancestors_glpi(array $groupIds): array {
        $dist = [];
        $frontier = [];
        foreach ($groupIds as $gid) {
            $gid = (int)$gid;
            if ($gid > 0 && !isset($dist[$gid])) {
                $dist[$gid] = 0;
                $frontier[$gid] = 0;
            }
        }

        if (empty($frontier)) {
            return $dist;
        }

        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            return $dist;
        }

        $depth = 0;
        while (!empty($frontier) && $depth < 20) {
            $depth++;
            $ids = array_map('intval', array_keys($frontier));
            $next = [];

            try {
                if (method_exists($DB, 'request')) {
                    $it = $DB->request([
                        'SELECT' => ['id', 'groups_id'],
                        'FROM'   => 'glpi_groups',
                        'WHERE'  => ['id' => $ids],
                    ]);
                    foreach ($it as $row) {
                        if (!is_array($row)) {
                            continue;
                        }
                        $id = isset($row['id']) ? (int)$row['id'] : 0;
                        $parent = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                        if ($id <= 0 || $parent <= 0) {
                            continue;
                        }
                        $candidateDistance = ((int)($dist[$id] ?? 0)) + 1;
                        if (!isset($dist[$parent]) || $candidateDistance < (int)$dist[$parent]) {
                            $dist[$parent] = $candidateDistance;
                            $next[$parent] = $candidateDistance;
                        }
                    }
                    $frontier = $next;
                    continue;
                }
            } catch (\Throwable $e) {
                // ignore and try fallback below
            }

            try {
                if (!method_exists($DB, 'query')) {
                    break;
                }
                $in = implode(',', $ids);
                if ($in === '') {
                    break;
                }
                $res = @$DB->query('SELECT `id`, `groups_id` FROM `glpi_groups` WHERE `id` IN (' . $in . ')');
                if (!$res) {
                    break;
                }
                if (method_exists($DB, 'fetchAssoc')) {
                    while ($row = $DB->fetchAssoc($res)) {
                        $id = isset($row['id']) ? (int)$row['id'] : 0;
                        $parent = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                        if ($id <= 0 || $parent <= 0) {
                            continue;
                        }
                        $candidateDistance = ((int)($dist[$id] ?? 0)) + 1;
                        if (!isset($dist[$parent]) || $candidateDistance < (int)$dist[$parent]) {
                            $dist[$parent] = $candidateDistance;
                            $next[$parent] = $candidateDistance;
                        }
                    }
                } elseif (method_exists($DB, 'fetch_assoc')) {
                    while ($row = $DB->fetch_assoc($res)) {
                        $id = isset($row['id']) ? (int)$row['id'] : 0;
                        $parent = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                        if ($id <= 0 || $parent <= 0) {
                            continue;
                        }
                        $candidateDistance = ((int)($dist[$id] ?? 0)) + 1;
                        if (!isset($dist[$parent]) || $candidateDistance < (int)$dist[$parent]) {
                            $dist[$parent] = $candidateDistance;
                            $next[$parent] = $candidateDistance;
                        }
                    }
                }
                $frontier = $next;
            } catch (\Throwable $e) {
                break;
            }
        }

        return $dist;
    }
}

if (!function_exists('glpibot_compare_route_candidates')) {
    function glpibot_compare_route_candidates(array $candidate, array $best): int {
        $aPriority = (int)($candidate['route']['priority'] ?? 100);
        $bPriority = (int)($best['route']['priority'] ?? 100);
        if ($aPriority !== $bPriority) {
            return $aPriority <=> $bPriority;
        }

        $aDistance = (int)($candidate['distance'] ?? 999999);
        $bDistance = (int)($best['distance'] ?? 999999);
        if ($aDistance !== $bDistance) {
            return $aDistance <=> $bDistance;
        }

        $aGroup = (int)($candidate['route']['group_id'] ?? 0);
        $bGroup = (int)($best['route']['group_id'] ?? 0);
        if ($aGroup !== $bGroup) {
            return $aGroup <=> $bGroup;
        }

        return strcmp((string)($candidate['route']['id'] ?? ''), (string)($best['route']['id'] ?? ''));
    }
}

if (!function_exists('glpibot_match_route_from_groups')) {
    function glpibot_match_route_from_groups(array $cfg, array $userGroups, array $expandedDistances): array {
        $routes = glpibot_parse_group_routes_json($cfg['group_routes_json'] ?? '');
        $enabledRoutes = [];
        foreach ($routes as $route) {
            if (!empty($route['enabled'])) {
                $enabledRoutes[] = $route;
            }
        }

        $best = null;
        foreach ($enabledRoutes as $route) {
            $gid = (int)($route['group_id'] ?? 0);
            if ($gid <= 0 || !isset($expandedDistances[$gid])) {
                continue;
            }

            $distance = (int)$expandedDistances[$gid];
            if (empty($route['include_children']) && $distance > 0) {
                continue;
            }

            $candidate = [
                'route' => $route,
                'distance' => $distance,
                'direct_groups' => array_values(array_map('intval', $userGroups)),
                'expanded_groups' => array_keys($expandedDistances),
                'expanded_distances' => $expandedDistances,
            ];

            if ($best === null || glpibot_compare_route_candidates($candidate, $best) < 0) {
                $best = $candidate;
            }
        }

        return [
            'route_mode' => !empty($enabledRoutes),
            'matched' => $best !== null,
            'match' => $best,
            'user_groups' => array_values(array_map('intval', $userGroups)),
            'expanded_groups' => array_keys($expandedDistances),
            'expanded_distances' => $expandedDistances,
        ];
    }
}

if (!function_exists('glpibot_normalize_endpoint_path')) {
    function glpibot_normalize_endpoint_path($path, string $default): string {
        $path = glpibot_string($path, '');
        if ($path === '') {
            return $default;
        }
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }
        return $path;
    }
}

if (!function_exists('glpibot_join_url')) {
    function glpibot_join_url(string $base, string $path, string $defaultPath = ''): string {
        $base = rtrim(trim($base), '/');
        if ($base === '') {
            return '';
        }
        $path = glpibot_normalize_endpoint_path($path, $defaultPath !== '' ? $defaultPath : '/');
        return $base . $path;
    }
}

if (!function_exists('glpibot_default_profile_from_config')) {
    function glpibot_default_profile_from_config(array $cfg): array {
        $base = glpibot_string($cfg['api_base_url'] ?? '', '');
        $key = glpibot_string($cfg['api_key'] ?? '', '');
        $timeout = glpibot_int($cfg['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
        $chatPath = glpibot_normalize_endpoint_path($cfg['api_chat_path'] ?? '', '/chat');
        $healthPath = glpibot_normalize_endpoint_path($cfg['api_health_path'] ?? '', '/health');

        return [
            'id' => '__default__',
            'name' => glpibot_string($cfg['default_profile_name'] ?? '', 'Default API'),
            'api_base_url' => $base,
            'api_key' => $key,
            'request_timeout_ms' => $timeout,
            'chat_path' => $chatPath,
            'health_path' => $healthPath,
            'enabled' => true,
            'is_default' => true,
            'chat_url' => glpibot_join_url($base, $chatPath, '/chat'),
            'health_url' => glpibot_join_url($base, $healthPath, '/health'),
        ];
    }
}

if (!function_exists('glpibot_parse_profiles_json')) {
    function glpibot_parse_profiles_json($raw): array {
        $raw = is_string($raw) ? trim($raw) : '';
        if ($raw === '') {
            return [];
        }

        $j = json_decode($raw, true);
        if (!is_array($j)) {
            return [];
        }

        $out = [];
        foreach ($j as $row) {
            if (!is_array($row)) {
                continue;
            }

            $id = glpibot_string($row['id'] ?? '', '');
            if ($id === '') {
                continue;
            }

            $base = glpibot_string($row['api_base_url'] ?? '', '');
            $chatPath = glpibot_normalize_endpoint_path($row['chat_path'] ?? '', '/chat');
            $healthPath = glpibot_normalize_endpoint_path($row['health_path'] ?? '', '/health');

            $out[$id] = [
                'id' => $id,
                'name' => glpibot_string($row['name'] ?? '', $id),
                'api_base_url' => $base,
                'api_key' => glpibot_string($row['api_key'] ?? '', ''),
                'request_timeout_ms' => glpibot_int($row['request_timeout_ms'] ?? 60000, 60000, 1000, 600000),
                'chat_path' => $chatPath,
                'health_path' => $healthPath,
                'enabled' => glpibot_bool($row['enabled'] ?? true, true),
                'is_default' => false,
                'chat_url' => glpibot_join_url($base, $chatPath, '/chat'),
                'health_url' => glpibot_join_url($base, $healthPath, '/health'),
            ];
        }

        return $out;
    }
}

if (!function_exists('glpibot_parse_group_routes_json')) {
    function glpibot_parse_group_routes_json($raw): array {
        $raw = is_string($raw) ? trim($raw) : '';
        if ($raw === '') {
            return [];
        }

        $j = json_decode($raw, true);
        if (!is_array($j)) {
            return [];
        }

        $out = [];
        foreach ($j as $row) {
            if (!is_array($row)) {
                continue;
            }

            $groupId = glpibot_int($row['group_id'] ?? ($row['groups_id'] ?? 0), 0, 0, PHP_INT_MAX);
            if ($groupId <= 0) {
                continue;
            }

            $profileId = glpibot_string($row['profile_id'] ?? '__default__', '__default__');
            if ($profileId === '') {
                $profileId = '__default__';
            }

            $routeId = glpibot_string($row['id'] ?? '', '');
            if ($routeId === '') {
                $routeId = 'route_' . $groupId . '_' . count($out);
            }

            $out[] = [
                'id' => $routeId,
                'group_id' => $groupId,
                'profile_id' => $profileId,
                'priority' => glpibot_int($row['priority'] ?? 100, 100, 0, 999999),
                'include_children' => glpibot_bool($row['include_children'] ?? true, true),
                'enabled' => glpibot_bool($row['enabled'] ?? true, true),
            ];
        }

        return $out;
    }
}

if (!function_exists('glpibot_has_enabled_group_routes')) {
    function glpibot_has_enabled_group_routes(array $cfg): bool {
        $routes = glpibot_parse_group_routes_json($cfg['group_routes_json'] ?? '');
        foreach ($routes as $route) {
            if (!empty($route['enabled'])) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('glpibot_profiles_with_default')) {
    function glpibot_profiles_with_default(array $cfg): array {
        $profiles = glpibot_parse_profiles_json($cfg['api_profiles_json'] ?? '');
        $profiles['__default__'] = glpibot_default_profile_from_config($cfg);
        return $profiles;
    }
}
