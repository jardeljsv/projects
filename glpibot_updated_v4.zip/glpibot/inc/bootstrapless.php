<?php
// Runtime helpers for GLPIBot public plugin endpoints.
// This file intentionally does NOT open a separate mysqli connection.
// It bootstraps GLPI through inc/includes.php and then uses GLPI's own $DB,
// session, and Config APIs.

if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/common.php';

if (!function_exists('glpibot_json_response')) {
    function glpibot_json_response(int $status, array $payload): void {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('glpibot_files_log_path')) {
    function glpibot_files_log_path(?string $glpiRoot): string {
        if ($glpiRoot) {
            $candidate = rtrim($glpiRoot, '/\\') . '/files/_log/glpibot-plugin.log';
            $dir = dirname($candidate);
            if (is_dir($dir) && is_writable($dir)) {
                return $candidate;
            }
        }
        return '/tmp/glpibot-plugin.log';
    }
}

if (!function_exists('glpibot_log')) {
    function glpibot_log(?string $glpiRoot, string $message): void {
        $file = glpibot_files_log_path($glpiRoot);
        $ts = date('Y-m-d H:i:s');
        @file_put_contents($file, '[' . $ts . '] ' . $message . "\n", FILE_APPEND);
    }
}

if (!function_exists('glpibot_find_glpi_root')) {
    function glpibot_find_glpi_root(): ?string {
        $candidates = [];

        $envRoot = getenv('GLPI_ROOT');
        if (is_string($envRoot) && trim($envRoot) !== '') {
            $candidates[] = trim($envRoot);
        }

        // Normal plugin layout:
        //   <glpi>/plugins/glpibot/inc/bootstrapless.php
        // Public-root layout:
        //   <glpi>/public/plugins/glpibot/inc/bootstrapless.php
        $candidates[] = dirname(__DIR__, 4);
        $candidates[] = dirname(__DIR__, 3);
        $candidates[] = dirname(__DIR__, 2);
        $candidates[] = dirname(__DIR__, 1);

        $docRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
        if (is_string($docRoot) && trim($docRoot) !== '') {
            $docRoot = rtrim(trim($docRoot), '/\\');
            $candidates[] = $docRoot;
            $candidates[] = dirname($docRoot);
            $candidates[] = $docRoot . '/glpi';
        }

        $seen = [];
        foreach ($candidates as $cand) {
            if (!is_string($cand) || trim($cand) === '') {
                continue;
            }
            $real = realpath($cand);
            if ($real === false) {
                $real = rtrim($cand, '/\\');
            }
            if (isset($seen[$real])) {
                continue;
            }
            $seen[$real] = true;

            if (is_dir($real) && is_file($real . '/inc/includes.php')) {
                return $real;
            }
        }
        return null;
    }
}

if (!function_exists('glpibot_bootstrap_glpi_runtime')) {
    function glpibot_bootstrap_glpi_runtime(?string &$glpiRootOut = null): bool {
        $glpiRoot = glpibot_find_glpi_root();
        $glpiRootOut = $glpiRoot;
        if ($glpiRoot === null) {
            glpibot_log(null, 'GLPI_ROOT_NOT_FOUND');
            return false;
        }

        $includes = rtrim($glpiRoot, '/\\') . '/inc/includes.php';
        if (!is_file($includes)) {
            glpibot_log($glpiRoot, 'GLPI_INCLUDES_NOT_FOUND ' . $includes);
            return false;
        }

        try {
            require_once $includes;
        } catch (Throwable $e) {
            glpibot_log($glpiRoot, 'GLPI_BOOTSTRAP_ERROR ' . $e->getMessage());
            return false;
        }

        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            glpibot_log($glpiRoot, 'GLPI_DB_OBJECT_UNAVAILABLE_AFTER_BOOTSTRAP');
            return false;
        }

        return true;
    }
}

if (!function_exists('glpibot_load_plugin_config_glpi')) {
    function glpibot_load_plugin_config_glpi(): array {
        try {
            if (class_exists('Config') && method_exists('Config', 'getConfigurationValues')) {
                $cfg = \Config::getConfigurationValues('plugin:glpibot');
                return is_array($cfg) ? $cfg : [];
            }
        } catch (Throwable $e) {
            // fall through to DB fallback below
        }

        $cfg = [];
        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            return $cfg;
        }

        try {
            if (method_exists($DB, 'request')) {
                $it = $DB->request([
                    'SELECT' => ['name', 'value'],
                    'FROM'   => 'glpi_configs',
                    'WHERE'  => ['context' => 'plugin:glpibot'],
                ]);
                foreach ($it as $row) {
                    if (is_array($row) && isset($row['name'])) {
                        $cfg[(string)$row['name']] = (string)($row['value'] ?? '');
                    }
                }
                return $cfg;
            }
        } catch (Throwable $e) {
            // fall through to query fallback
        }

        try {
            if (method_exists($DB, 'query')) {
                $res = @$DB->query("SELECT `name`, `value` FROM `glpi_configs` WHERE `context` = 'plugin:glpibot'");
                if ($res) {
                    if (method_exists($DB, 'fetchAssoc')) {
                        while ($row = $DB->fetchAssoc($res)) {
                            if (isset($row['name'])) {
                                $cfg[(string)$row['name']] = (string)($row['value'] ?? '');
                            }
                        }
                    } elseif (method_exists($DB, 'fetch_assoc')) {
                        while ($row = $DB->fetch_assoc($res)) {
                            if (isset($row['name'])) {
                                $cfg[(string)$row['name']] = (string)($row['value'] ?? '');
                            }
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            // ignore
        }

        return $cfg;
    }
}

if (!function_exists('glpibot_resolve_uid_glpi_runtime')) {
    function glpibot_resolve_uid_glpi_runtime(): int {
        return glpibot_get_current_uid_glpi();
    }
}

if (!function_exists('glpibot_match_route_for_uid_glpi')) {
    function glpibot_match_route_for_uid_glpi(array $cfg, int $uid): array {
        $userGroups = $uid > 0 ? glpibot_resolve_current_user_groups_glpi($uid) : [];
        $expanded = glpibot_expand_group_ancestors_glpi($userGroups);
        return glpibot_match_route_from_groups($cfg, $userGroups, $expanded);
    }
}

if (!function_exists('glpibot_profile_from_route_match')) {
    function glpibot_profile_from_route_match(array $cfg, ?array $match): ?array {
        if ($match === null || !isset($match['route']) || !is_array($match['route'])) {
            return null;
        }
        $profileId = glpibot_string($match['route']['profile_id'] ?? '__default__', '__default__');
        if ($profileId === '') {
            $profileId = '__default__';
        }
        $profiles = glpibot_profiles_with_default($cfg);
        $profile = $profiles[$profileId] ?? null;
        if (!is_array($profile)) {
            return null;
        }
        if (!empty($profile['is_default'])) {
            return $profile;
        }
        if (empty($profile['enabled'])) {
            return null;
        }
        return $profile;
    }
}

if (!function_exists('glpibot_resolve_legacy_visibility_glpi')) {
    function glpibot_resolve_legacy_visibility_glpi(array $cfg, int $uid): array {
        $allowedGroups = glpibot_parse_id_list($cfg['allowed_groups'] ?? '');
        if (empty($allowedGroups)) {
            return [
                'allowed' => true,
                'restricted' => false,
                'uncertain' => false,
                'reason' => 'all_users',
                'user_groups' => [],
                'expanded_groups' => [],
            ];
        }

        if ($uid <= 0) {
            return [
                'allowed' => false,
                'restricted' => true,
                'uncertain' => false,
                'reason' => 'uid_not_found',
                'user_groups' => [],
                'expanded_groups' => [],
            ];
        }

        $userGroups = glpibot_resolve_current_user_groups_glpi($uid);
        $expanded = glpibot_expand_group_ancestors_glpi($userGroups);
        $allowedMap = [];
        foreach ($allowedGroups as $gid) {
            $allowedMap[(int)$gid] = true;
        }

        $hit = false;
        foreach (array_keys($expanded) as $gid) {
            if (isset($allowedMap[(int)$gid])) {
                $hit = true;
                break;
            }
        }

        return [
            'allowed' => $hit,
            'restricted' => true,
            'uncertain' => false,
            'reason' => $hit ? 'in_allowed_group' : 'not_in_allowed_groups',
            'user_groups' => $userGroups,
            'expanded_groups' => array_keys($expanded),
        ];
    }
}

if (!function_exists('glpibot_resolve_widget_visibility_glpi')) {
    function glpibot_resolve_widget_visibility_glpi(array $cfg, int $uid): array {
        $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
        if (!$enabled) {
            return [
                'enabled' => false,
                'restricted' => false,
                'allowed' => false,
                'uncertain' => false,
                'reason' => 'disabled',
                'route_mode' => false,
                'matched_route' => null,
                'profile_name' => null,
            ];
        }

        if (glpibot_has_enabled_group_routes($cfg)) {
            if ($uid <= 0) {
                return [
                    'enabled' => true,
                    'restricted' => true,
                    'allowed' => false,
                    'uncertain' => false,
                    'reason' => 'uid_not_found_for_route_mode',
                    'route_mode' => true,
                    'matched_route' => null,
                    'profile_name' => null,
                ];
            }

            $routeProbe = glpibot_match_route_for_uid_glpi($cfg, $uid);
            if (!empty($routeProbe['matched'])) {
                $profile = glpibot_profile_from_route_match($cfg, $routeProbe['match']);
                if (!is_array($profile)) {
                    return [
                        'enabled' => true,
                        'restricted' => true,
                        'allowed' => false,
                        'uncertain' => false,
                        'reason' => 'route_profile_missing_or_disabled',
                        'route_mode' => true,
                        'matched_route' => $routeProbe['match']['route'] ?? null,
                        'profile_name' => null,
                    ];
                }
                return [
                    'enabled' => true,
                    'restricted' => true,
                    'allowed' => true,
                    'uncertain' => false,
                    'reason' => 'matched_group_route',
                    'route_mode' => true,
                    'matched_route' => $routeProbe['match']['route'] ?? null,
                    'profile_name' => (string)($profile['name'] ?? ''),
                ];
            }

            return [
                'enabled' => true,
                'restricted' => true,
                'allowed' => false,
                'uncertain' => false,
                'reason' => 'no_matching_route',
                'route_mode' => true,
                'matched_route' => null,
                'profile_name' => null,
            ];
        }

        $legacy = glpibot_resolve_legacy_visibility_glpi($cfg, $uid);
        return [
            'enabled' => true,
            'restricted' => (bool)$legacy['restricted'],
            'allowed' => (bool)$legacy['allowed'],
            'uncertain' => (bool)$legacy['uncertain'],
            'reason' => (string)$legacy['reason'],
            'route_mode' => false,
            'matched_route' => null,
            'profile_name' => null,
        ];
    }
}

if (!function_exists('glpibot_resolve_runtime_profile_glpi')) {
    function glpibot_resolve_runtime_profile_glpi(array $cfg, int $uid): array {
        $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
        if (!$enabled) {
            return [
                'ok' => false,
                'reason' => 'disabled',
                'route_mode' => false,
                'profile' => null,
                'uid_required' => false,
            ];
        }

        if (glpibot_has_enabled_group_routes($cfg)) {
            if ($uid <= 0) {
                return [
                    'ok' => false,
                    'reason' => 'uid_not_found_for_route_mode',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }

            $routeProbe = glpibot_match_route_for_uid_glpi($cfg, $uid);
            if (empty($routeProbe['matched'])) {
                return [
                    'ok' => false,
                    'reason' => 'no_matching_route',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }

            $profile = glpibot_profile_from_route_match($cfg, $routeProbe['match']);
            if (!is_array($profile)) {
                return [
                    'ok' => false,
                    'reason' => 'route_profile_missing_or_disabled',
                    'route_mode' => true,
                    'profile' => null,
                    'uid_required' => true,
                ];
            }

            return [
                'ok' => true,
                'reason' => 'matched_group_route',
                'route_mode' => true,
                'profile' => $profile,
                'matched_route' => $routeProbe['match']['route'] ?? null,
                'uid_required' => true,
            ];
        }

        $legacy = glpibot_resolve_legacy_visibility_glpi($cfg, $uid);
        if (empty($legacy['allowed'])) {
            return [
                'ok' => false,
                'reason' => (string)$legacy['reason'],
                'route_mode' => false,
                'profile' => null,
                'uid_required' => !empty($legacy['restricted']),
            ];
        }

        return [
            'ok' => true,
            'reason' => 'legacy_default_profile',
            'route_mode' => false,
            'profile' => glpibot_default_profile_from_config($cfg),
            'uid_required' => false,
        ];
    }
}

if (!function_exists('glpibot_http_json_request')) {
    function glpibot_http_json_request(string $method, string $url, array $headers = [], $body = null, int $timeoutMs = 60000): array {
        $ch = curl_init();
        if ($ch === false) {
            return [
                'ok' => false,
                'http_code' => 0,
                'curl_error' => 'curl_init_failed',
                'body_raw' => '',
                'json' => null,
            ];
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $method = strtoupper(trim($method));
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
            }
        } elseif ($method !== 'GET') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
            }
        } else {
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        }

        $timeoutMs = max(1000, min($timeoutMs, 600000));
        if (defined('CURLOPT_TIMEOUT_MS')) {
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, $timeoutMs);
        } else {
            curl_setopt($ch, CURLOPT_TIMEOUT, (int)ceil($timeoutMs / 1000));
        }

        $bodyRaw = curl_exec($ch);
        $curlErr = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $json = null;
        if (is_string($bodyRaw) && $bodyRaw !== '') {
            $parsed = json_decode($bodyRaw, true);
            if (is_array($parsed)) {
                $json = $parsed;
            }
        }

        return [
            'ok' => ($bodyRaw !== false && $curlErr === '' && $httpCode >= 200 && $httpCode < 300),
            'http_code' => $httpCode,
            'curl_error' => $curlErr,
            'body_raw' => is_string($bodyRaw) ? $bodyRaw : '',
            'json' => $json,
        ];
    }
}
