# Relatórios G4F

Plugin GLPI API-first para gerar rascunhos de relatórios com múltiplos contextos, revisão manual e exportação DOCX.

## Principais pontos

- A extração de dados de relatório é feita pela API REST do GLPI.
- Não cria tabelas de negócio próprias.
- Não usa PHPWord, ZipArchive, bibliotecas JS externas ou CDN.
- Composer é opcional: o plugin inclui autoload interno em `inc/autoload.php`.
- `vendor/autoload.php` é intencionalmente vazio, seguindo o padrão usado no GLPIBot.
- O menu em Ferramentas abre somente o gerador de relatório.
- A configuração administrativa fica em Configurar > Geral > Relatórios G4F.
- Chamadas de teste e extração usam endpoints em `front/`, não `ajax/`.
- CSS/JS das páginas são inseridos pelo PHP da própria página, evitando 404 de assets estáticos em instalações com public-root/proxy.

## Instalação

```bash
cd /var/www/html/glpi/plugins
rm -rf g4freports
unzip g4freports_v0.5.0_extraction_templates_status.zip
chown -R www-data:www-data g4freports
```

Composer continua opcional:

```bash
cd /var/www/html/glpi/plugins/g4freports
composer install --no-dev --optimize-autoloader
chown -R www-data:www-data /var/www/html/glpi/plugins/g4freports
```

Depois:

1. Configurar > Plugins > Relatórios G4F > Instalar/Habilitar.
2. Configurar > Geral > Relatórios G4F.
3. Preencher o perfil padrão da API GLPI.
4. Usar o botão `Testar conexão padrão`.
5. Ferramentas > Relatórios G4F para gerar o relatório.

## Autenticação GLPI API

O perfil padrão aceita:

- App token + User token.
- Session token fixo.
- Tokens por variável de ambiente.

A URL aceita tanto `https://servidor/apirest.php` quanto `https://servidor`; o plugin normaliza para `/apirest.php`.

## Contextos do relatório

O usuário pode marcar múltiplos contextos ao mesmo tempo:

- Chamados atribuídos ao agente.
- Chamados solicitados pelo agente.
- Chamados atribuídos aos grupos do agente.
- Tarefas de chamado feitas pelo agente.
- Acompanhamentos feitos pelo agente.
- Soluções registradas pelo agente.
- Projetos gerenciados pelo agente.
- Projetos gerenciados pelos grupos do agente.
- Projetos em que o agente participa.
- Tarefas de projeto do agente.
- Tarefas de projeto dos grupos do agente.
- Entradas narrativas manuais.


## Alterações v0.5.0

- Os quatro modelos DOCX agora geram estruturas distintas: operacional, gerencial formal, técnico/projeto e anexo evidencial.
- A identidade visual do DOCX usa elementos editáveis do Word: cabeçalho, rodapé, tabelas, sombreamentos e faixas decorativas. O exportador não insere imagens de fundo no corpo do documento.
- Chamados e projetos priorizam a última atividade/comentário/tarefa registrada pelo agente no período antes de cair para descrição ou solução.
- Status numéricos de chamados são convertidos para nomes; status de projeto/tarefa de projeto tentam resolver ProjectState/ProjectTaskState via API.
- Grupos adicionais podem ser pesquisados por nome ou ID na tela de geração do relatório.
