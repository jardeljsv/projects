<?php
// Unified API endpoint. Accepts GET with ?action=...&payload={json} by default
// and also supports JSON/form POST. This mirrors the GLPIBot hardening pattern
// for environments where browser POSTs to plugin endpoints may be blocked.

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Api\SearchOptionResolver;
use GlpiPlugin\G4freports\Builder\ReportDraftBuilder;

@ini_set('display_errors', '0');


$cfg = Config::merged();
if (!Security::canUse($cfg) && !Security::canConfigure()) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
}

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
$input = g4fr_parse_request_payload();
if ($action === '') {
    $action = trim((string)($input['action'] ?? ''));
}
if ($action === '') {
    g4fr_json_response(400, ['ok' => false, 'error' => 'action_nao_informada']);
}

function g4fr_api_profile_from_input(array $input, array $cfg): ?array {
    if (isset($input['adhoc_profile']) && is_array($input['adhoc_profile']) && \GlpiPlugin\G4freports\Security::canConfigure()) {
        return \GlpiPlugin\G4freports\Config::normalizeProfile($input['adhoc_profile'], '__adhoc__');
    }
    $profileId = trim((string)($input['profile_id'] ?? '__default__'));
    return \GlpiPlugin\G4freports\Config::getAllowedProfileForCurrentUser($profileId, $cfg);
}

try {
    switch ($action) {
        case 'test_connection': {
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            $client->initSession();
            try {
                $session = $client->request('GET', '/getFullSession');
            } catch (Throwable $e) {
                $session = ['warning' => $e->getMessage()];
            }
            $client->killSession();
            g4fr_json_response(200, ['ok' => true, 'base_url' => $client->getBaseUrl(), 'session' => $session]);
        }

        case 'test_profiles': {
            if (!Security::canConfigure()) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            // Tests saved profiles only; avoids sending tokens through query strings.
            $profiles = Config::profiles($cfg);
            $out = [];
            foreach ($profiles as $id => $profile) {
                try {
                    $client = new GlpiApiClient($profile);
                    $client->initSession();
                    $client->killSession();
                    $out[] = ['id' => $id, 'name' => $profile['name'] ?? $id, 'ok' => true, 'base_url' => $client->getBaseUrl()];
                } catch (Throwable $e) {
                    $out[] = ['id' => $id, 'name' => $profile['name'] ?? $id, 'ok' => false, 'error' => $e->getMessage()];
                }
            }
            g4fr_json_response(200, ['ok' => true, 'results' => $out]);
        }

        case 'search_users': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $q = trim((string)($input['q'] ?? ''));
            if ($q === '') {
                g4fr_json_response(200, ['ok' => true, 'users' => []]);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            $resolver = new SearchOptionResolver($client, json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true) ?: []);
            $fields = $resolver->fields('User', ['id' => [2], 'name' => [1], 'realname' => [9], 'firstname' => [34], 'login' => [1]]);
            $nameField = $fields['name'] ?: 1;
            $display = array_values(array_filter(array_unique([$fields['id'] ?: 2, $fields['name'] ?: 1, $fields['realname'], $fields['firstname']])));
            $res = $client->search('User', [['field' => $nameField, 'searchtype' => 'contains', 'value' => $q]], $display, '0-20');
            $users = [];
            foreach (($res['data'] ?? []) as $row) {
                if (!is_array($row)) continue;
                $id = (int)($row[(string)($fields['id'] ?: 2)] ?? $row['2'] ?? 0);
                $name = (string)($row[(string)($fields['name'] ?: 1)] ?? $row['1'] ?? '');
                $real = (string)($row[(string)$fields['realname']] ?? '');
                $first = (string)($row[(string)$fields['firstname']] ?? '');
                $full = trim($first . ' ' . $real);
                $users[] = ['id' => $id, 'name' => $full !== '' ? $full : $name, 'login' => $name, 'raw' => $row];
            }
            $client->killSession();
            g4fr_json_response(200, ['ok' => true, 'users' => $users]);
        }


        case 'search_groups': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $q = trim((string)($input['q'] ?? ''));
            if ($q === '') {
                g4fr_json_response(200, ['ok' => true, 'groups' => []]);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            $groups = [];

            // Numeric search is common during operations; allow direct lookup by ID
            // without requiring the user to know or type the exact API search syntax.
            if (preg_match('/^\d+$/', $q)) {
                try {
                    $item = $client->getItem('Group', (int)$q, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                    if (is_array($item) && (int)($item['id'] ?? 0) > 0) {
                        $groups[] = [
                            'id' => (int)$item['id'],
                            'name' => (string)(($item['completename'] ?? '') ?: ($item['name'] ?? ('Grupo #' . (int)$item['id']))),
                            'raw' => $item
                        ];
                    }
                } catch (Throwable $e) {
                    // Fall through to normal search.
                }
            }

            try {
                $resolver = new SearchOptionResolver($client, json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true) ?: []);
                $fields = $resolver->fields('Group', ['id' => [2], 'name' => [1], 'completename' => [80, 1]]);
                $nameField = $fields['completename'] ?: ($fields['name'] ?: 1);
                $display = array_values(array_filter(array_unique([$fields['id'] ?: 2, $fields['name'] ?: 1, $fields['completename']])));
                $res = $client->search('Group', [['field' => $nameField, 'searchtype' => 'contains', 'value' => $q]], $display, '0-30');
                $seen = [];
                foreach ($groups as $g) {
                    $seen[(int)$g['id']] = true;
                }
                foreach (($res['data'] ?? []) as $row) {
                    if (!is_array($row)) continue;
                    $id = (int)($row[(string)($fields['id'] ?: 2)] ?? $row['2'] ?? 0);
                    if ($id <= 0 || isset($seen[$id])) continue;
                    $name = (string)($row[(string)($fields['completename'] ?: 0)] ?? '');
                    if ($name === '') {
                        $name = (string)($row[(string)($fields['name'] ?: 1)] ?? $row['1'] ?? ('Grupo #' . $id));
                    }
                    $groups[] = ['id' => $id, 'name' => $name, 'raw' => $row];
                    $seen[$id] = true;
                }
            } catch (Throwable $e) {
                if (empty($groups)) {
                    throw $e;
                }
            }
            $client->killSession();
            g4fr_json_response(200, ['ok' => true, 'groups' => array_values($groups)]);
        }

        case 'search_options': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $itemtype = trim((string)($input['itemtype'] ?? 'Ticket'));
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $client = new GlpiApiClient($profile);
            $options = $client->listSearchOptions($itemtype);
            $client->killSession();
            g4fr_json_response(200, ['ok' => true, 'itemtype' => $itemtype, 'options' => $options]);
        }

        case 'build_draft': {
            if (!Security::canUse($cfg)) {
                g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
            }
            $profile = g4fr_api_profile_from_input($input, $cfg);
            if (!$profile) {
                g4fr_json_response(400, ['ok' => false, 'error' => 'Perfil de API não encontrado.']);
            }
            $builder = new ReportDraftBuilder($cfg, $profile);
            $draft = $builder->build($input);
            g4fr_json_response(200, ['ok' => true, 'draft' => $draft]);
        }

        default:
            g4fr_json_response(404, ['ok' => false, 'error' => 'acao_desconhecida: ' . $action]);
    }
} catch (Throwable $e) {
    $trace = g4fr_str_limit($e->getTraceAsString(), 3000);
    g4fr_json_response(500, ['ok' => false, 'error' => $e->getMessage(), 'trace' => $trace]);
}
