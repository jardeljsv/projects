<?php
// plugins/g4freports/setup.php

$autoload = __DIR__ . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

require_once __DIR__ . '/inc/menu.class.php';
require_once __DIR__ . '/inc/config.class.php';

define('PLUGIN_G4FREPORTS_VERSION', '0.1.0');

define('PLUGIN_G4FREPORTS_MIN_GLPI', '10.0.0');

function plugin_init_g4freports(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['g4freports'] = true;

    if (class_exists('Plugin')) {
        Plugin::registerClass('PluginG4freportsConfig', [
            'addtabon' => 'Config'
        ]);
        Plugin::registerClass('PluginG4freportsMenu');
    }

    // Add a left-menu entry under Tools/Ferramentas.
    $PLUGIN_HOOKS['menu_toadd']['g4freports'] = [
        'tools' => 'PluginG4freportsMenu'
    ];

    $PLUGIN_HOOKS['add_css']['g4freports'] = [
        'assets/css/g4freports.css'
    ];
}

function plugin_version_g4freports(): array
{
    return [
        'name'           => 'Relatórios G4F',
        'version'        => PLUGIN_G4FREPORTS_VERSION,
        'author'         => 'Artur de Andrade Batista',
        'license'        => 'MIT',
        'homepage'       => '',
        'requirements'   => [
            'glpi' => [
                'min' => PLUGIN_G4FREPORTS_MIN_GLPI,
                'max' => '11.99.99'
            ]
        ]
    ];
}

function plugin_g4freports_check_prerequisites(): bool
{
    if (defined('GLPI_VERSION') && version_compare(GLPI_VERSION, PLUGIN_G4FREPORTS_MIN_GLPI, '<')) {
        if (method_exists('Plugin', 'messageIncompatible')) {
            Plugin::messageIncompatible('core', PLUGIN_G4FREPORTS_MIN_GLPI);
        }
        return false;
    }

    if (!function_exists('curl_init')) {
        echo 'The cURL PHP extension is required by Relatórios G4F.';
        return false;
    }

    return true;
}

function plugin_g4freports_check_config($verbose = false): bool
{
    return true;
}
