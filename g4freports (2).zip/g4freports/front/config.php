<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;

if (class_exists('Session')) {
    Session::checkLoginUser();
}

if (!Security::canConfigure()) {
    if (class_exists('Html')) {
        Html::displayRightError();
    }
    http_response_code(403);
    exit;
}

$cfg = Config::merged();
$rootdoc = $CFG_GLPI['root_doc'] ?? '';
$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (class_exists('Session') && method_exists('Session', 'checkCSRF')) {
            Session::checkCSRF($_POST);
        }
        $apiProfiles = trim((string)($_POST['api_profiles_json'] ?? '[]'));
        $fieldOverrides = trim((string)($_POST['field_overrides_json'] ?? '{}'));
        json_decode($apiProfiles, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('JSON de perfis de API inválido: ' . json_last_error_msg());
        }
        json_decode($fieldOverrides, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('JSON de mapeamento de campos inválido: ' . json_last_error_msg());
        }
        Config::save([
            'enabled'                => isset($_POST['enabled']) ? 1 : 0,
            'allowed_groups'         => trim((string)($_POST['allowed_groups'] ?? '')),
            'allowed_profiles'       => trim((string)($_POST['allowed_profiles'] ?? '')),
            'api_profiles_json'      => $apiProfiles,
            'default_profile_id'     => trim((string)($_POST['default_profile_id'] ?? 'default')),
            'max_items'              => max(10, min(1000, (int)($_POST['max_items'] ?? 200))),
            'request_timeout_ms'     => max(1000, min(600000, (int)($_POST['request_timeout_ms'] ?? 60000))),
            'mask_sensitive_data'    => isset($_POST['mask_sensitive_data']) ? 1 : 0,
            'field_overrides_json'   => $fieldOverrides,
            'default_footer'         => trim((string)($_POST['default_footer'] ?? '')),
            'contract_label'         => trim((string)($_POST['contract_label'] ?? '')),
            'default_report_title'   => trim((string)($_POST['default_report_title'] ?? '')),
            'default_scope_text'     => trim((string)($_POST['default_scope_text'] ?? '')),
            'default_objective_text' => trim((string)($_POST['default_objective_text'] ?? '')),
        ]);
        $cfg = Config::merged();
        $notice = 'Configurações salvas.';
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

if (class_exists('Html')) {
    Html::header(__('Configurações - Relatórios G4F', 'g4freports'), $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu');
}
?>
<div class="g4fr-wrap">
  <div class="g4fr-header">
    <div>
      <h1>Configurações - Relatórios G4F</h1>
      <p>Configuração API-first sem tabelas próprias de negócio. Os dados de relatório são extraídos via API do GLPI.</p>
    </div>
    <a class="btn btn-outline-primary" href="<?php echo htmlspecialchars($rootdoc . '/plugins/g4freports/front/report.php'); ?>">Gerar relatório</a>
  </div>

  <?php if ($notice): ?><div class="alert alert-success"><?php echo htmlspecialchars($notice); ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

  <form method="post" class="g4fr-card g4fr-config-form">
    <?php if (class_exists('Html') && method_exists('Html', 'hidden')) { echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]); } ?>

    <h2>Geral</h2>
    <label class="g4fr-check"><input type="checkbox" name="enabled" value="1" <?php echo ((int)($cfg['enabled'] ?? 1) === 1) ? 'checked' : ''; ?>> Módulo habilitado</label>
    <label class="g4fr-check"><input type="checkbox" name="mask_sensitive_data" value="1" <?php echo ((int)($cfg['mask_sensitive_data'] ?? 1) === 1) ? 'checked' : ''; ?>> Mascarar CPF, e-mail e telefone nos textos exportados</label>

    <div class="g4fr-grid">
      <div class="g4fr-field">
        <label>Contrato / ambiente</label>
        <input class="form-control" name="contract_label" value="<?php echo htmlspecialchars((string)($cfg['contract_label'] ?? '')); ?>">
      </div>
      <div class="g4fr-field">
        <label>Perfil padrão de API</label>
        <input class="form-control" name="default_profile_id" value="<?php echo htmlspecialchars((string)($cfg['default_profile_id'] ?? 'default')); ?>">
      </div>
      <div class="g4fr-field">
        <label>Máximo de entradas</label>
        <input type="number" class="form-control" name="max_items" min="10" max="1000" value="<?php echo htmlspecialchars((string)($cfg['max_items'] ?? 200)); ?>">
      </div>
      <div class="g4fr-field">
        <label>Timeout padrão (ms)</label>
        <input type="number" class="form-control" name="request_timeout_ms" min="1000" max="600000" value="<?php echo htmlspecialchars((string)($cfg['request_timeout_ms'] ?? 60000)); ?>">
      </div>
      <div class="g4fr-field">
        <label>Perfis GLPI autorizados</label>
        <input class="form-control" name="allowed_profiles" value="<?php echo htmlspecialchars((string)($cfg['allowed_profiles'] ?? '')); ?>" placeholder="Ex.: 4, 6">
        <small>Vazio = não restringe por perfil. Administradores sempre acessam.</small>
      </div>
      <div class="g4fr-field">
        <label>Grupos GLPI autorizados</label>
        <input class="form-control" name="allowed_groups" value="<?php echo htmlspecialchars((string)($cfg['allowed_groups'] ?? '')); ?>" placeholder="Ex.: 59, 81">
        <small>Vazio = não restringe por grupo.</small>
      </div>
    </div>

    <h2>Perfis de API GLPI</h2>
    <p>Use um serviço de leitura quando possível. Para evitar CORS e exposição de tokens, as chamadas são feitas pelo PHP do plugin, não pelo navegador.</p>
    <textarea class="form-control g4fr-mono" name="api_profiles_json" rows="14"><?php echo htmlspecialchars((string)($cfg['api_profiles_json'] ?? '[]')); ?></textarea>
    <div class="g4fr-actions">
      <button type="button" id="g4fr-test-config" class="btn btn-outline-secondary">Testar JSON de conexões</button>
      <span id="g4fr-test-config-result"></span>
    </div>

    <h2>Mapeamento de campos de pesquisa</h2>
    <p>O plugin tenta resolver Search Options automaticamente. Use este JSON apenas se a instância GLPI usar campos diferentes.</p>
    <textarea class="form-control g4fr-mono" name="field_overrides_json" rows="10"><?php echo htmlspecialchars((string)($cfg['field_overrides_json'] ?? '{}')); ?></textarea>

    <h2>Textos padrão do relatório</h2>
    <div class="g4fr-field">
      <label>Título padrão</label>
      <input class="form-control" name="default_report_title" value="<?php echo htmlspecialchars((string)($cfg['default_report_title'] ?? '')); ?>">
    </div>
    <div class="g4fr-field">
      <label>Abrangência padrão</label>
      <textarea class="form-control" name="default_scope_text" rows="3"><?php echo htmlspecialchars((string)($cfg['default_scope_text'] ?? '')); ?></textarea>
    </div>
    <div class="g4fr-field">
      <label>Objetivo padrão</label>
      <textarea class="form-control" name="default_objective_text" rows="3"><?php echo htmlspecialchars((string)($cfg['default_objective_text'] ?? '')); ?></textarea>
    </div>
    <div class="g4fr-field">
      <label>Rodapé DOCX</label>
      <input class="form-control" name="default_footer" value="<?php echo htmlspecialchars((string)($cfg['default_footer'] ?? '')); ?>">
    </div>

    <div class="g4fr-actions">
      <button class="btn btn-primary" type="submit">Salvar configurações</button>
    </div>
  </form>
</div>
<script>
window.G4FREPORTS = { root: <?php echo json_encode($rootdoc . '/plugins/g4freports'); ?> };
</script>
<script src="<?php echo htmlspecialchars($rootdoc . '/plugins/g4freports/assets/js/config.js'); ?>"></script>
<?php
if (class_exists('Html')) {
    Html::footer();
}
