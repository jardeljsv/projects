<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;

if (class_exists('Session')) {
    Session::checkLoginUser();
}

$cfg = Config::merged();
if (!Security::canUse($cfg)) {
    if (class_exists('Html')) {
        Html::displayRightError();
    }
    http_response_code(403);
    exit;
}

$profiles = Config::profiles($cfg);
$rootdoc = $CFG_GLPI['root_doc'] ?? '';

if (class_exists('Html')) {
    Html::header(__('Relatórios G4F', 'g4freports'), $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu');
}
?>
<div class="g4fr-wrap">
  <div class="g4fr-header">
    <div>
      <h1>Relatórios G4F</h1>
      <p>Gerador API-first de rascunhos de relatório com contextos múltiplos, edição manual e exportação DOCX.</p>
    </div>
    <div class="g4fr-header-actions">
      <a class="btn btn-outline-secondary" href="<?php echo htmlspecialchars($rootdoc . '/plugins/g4freports/front/diagnostics.php'); ?>">Diagnóstico</a>
      <?php if (Security::canConfigure()): ?>
      <a class="btn btn-outline-primary" href="<?php echo htmlspecialchars($rootdoc . '/plugins/g4freports/front/config.php'); ?>">Configurações</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="g4fr-card">
    <h2>1. Parâmetros do relatório</h2>
    <form id="g4fr-form" class="g4fr-grid">
      <div class="g4fr-field">
        <label>Conexão GLPI</label>
        <select name="profile_id" id="g4fr-profile" class="form-select">
          <?php foreach ($profiles as $id => $profile): ?>
            <option value="<?php echo htmlspecialchars($id); ?>" <?php echo $id === ($cfg['default_profile_id'] ?? '') ? 'selected' : ''; ?>><?php echo htmlspecialchars((string)($profile['name'] ?? $id)); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="g4fr-field">
        <label>ID do agente principal</label>
        <input type="number" name="agent_id" id="g4fr-agent-id" class="form-control" placeholder="Ex.: 20744" min="1">
      </div>

      <div class="g4fr-field">
        <label>Nome do agente (opcional)</label>
        <input type="text" name="agent_name" id="g4fr-agent-name" class="form-control" placeholder="Será preenchido pela API quando possível">
      </div>

      <div class="g4fr-field g4fr-field-inline">
        <label>Pesquisar agente</label>
        <div class="input-group">
          <input type="text" id="g4fr-agent-search-q" class="form-control" placeholder="Nome/login">
          <button type="button" id="g4fr-agent-search-btn" class="btn btn-outline-secondary">Buscar</button>
        </div>
        <div id="g4fr-agent-results" class="g4fr-search-results"></div>
      </div>

      <div class="g4fr-field">
        <label>Início</label>
        <input type="date" name="period_start" id="g4fr-start" class="form-control" value="<?php echo date('Y-m-01'); ?>">
      </div>

      <div class="g4fr-field">
        <label>Fim</label>
        <input type="date" name="period_end" id="g4fr-end" class="form-control" value="<?php echo date('Y-m-t'); ?>">
      </div>

      <div class="g4fr-field">
        <label>Modelo</label>
        <select name="template" id="g4fr-template" class="form-select">
          <option value="operational">Operacional diário/mensal</option>
          <option value="formal_managerial">Gerencial formal</option>
          <option value="project_technical">Técnico/projeto</option>
          <option value="annex_full">Anexo evidencial completo</option>
        </select>
      </div>

      <div class="g4fr-field">
        <label>IDs de grupos adicionais</label>
        <input type="text" name="group_ids" id="g4fr-group-ids" class="form-control" placeholder="Ex.: 59, 24">
        <small>Opcional. O módulo tentará resolver os grupos do agente via API.</small>
      </div>

      <div class="g4fr-field g4fr-full">
        <label>Título do relatório</label>
        <input type="text" name="report_title" id="g4fr-title" class="form-control" value="<?php echo htmlspecialchars((string)($cfg['default_report_title'] ?? 'Relatório Gerencial de Atividades')); ?>">
      </div>

      <div class="g4fr-field g4fr-full">
        <label>Abrangência</label>
        <textarea name="scope_text" id="g4fr-scope" class="form-control" rows="3"><?php echo htmlspecialchars((string)($cfg['default_scope_text'] ?? '')); ?></textarea>
      </div>

      <div class="g4fr-field g4fr-full">
        <label>Objetivo</label>
        <textarea name="objective_text" id="g4fr-objective" class="form-control" rows="3"><?php echo htmlspecialchars((string)($cfg['default_objective_text'] ?? '')); ?></textarea>
      </div>
    </form>
  </div>

  <div class="g4fr-card">
    <h2>2. Contextos de extração</h2>
    <p>Marque quantos contextos forem necessários. O agente principal serve como âncora, mas o rascunho pode combinar dados de usuário, grupos, tickets, projetos e entradas manuais.</p>
    <div class="g4fr-contexts" id="g4fr-contexts">
      <label><input type="checkbox" value="tickets_assigned_user" checked> Chamados atribuídos ao agente</label>
      <label><input type="checkbox" value="tickets_requested_by_user"> Chamados solicitados pelo agente</label>
      <label><input type="checkbox" value="tickets_assigned_groups" checked> Chamados atribuídos aos grupos do agente</label>
      <label><input type="checkbox" value="ticket_tasks_by_user" checked> Tarefas de chamados feitas pelo agente</label>
      <label><input type="checkbox" value="ticket_followups_by_user" checked> Acompanhamentos feitos pelo agente</label>
      <label><input type="checkbox" value="ticket_solutions_by_user" checked> Soluções registradas pelo agente</label>
      <label><input type="checkbox" value="projects_managed_by_user" checked> Projetos gerenciados pelo agente</label>
      <label><input type="checkbox" value="projects_managed_by_groups" checked> Projetos gerenciados por grupos do agente</label>
      <label><input type="checkbox" value="projects_member_user" checked> Projetos em que o agente participa</label>
      <label><input type="checkbox" value="project_tasks_user" checked> Tarefas de projeto do agente</label>
      <label><input type="checkbox" value="project_tasks_groups"> Tarefas de projeto dos grupos do agente</label>
      <label><input type="checkbox" value="manual_entries" checked> Permitir entradas narrativas manuais</label>
    </div>
    <div class="g4fr-actions">
      <button type="button" id="g4fr-build" class="btn btn-primary">Gerar rascunho pela API</button>
      <button type="button" id="g4fr-add-manual" class="btn btn-outline-secondary" disabled>Adicionar entrada manual</button>
      <button type="button" id="g4fr-download-json" class="btn btn-outline-secondary" disabled>Baixar rascunho JSON</button>
      <label class="btn btn-outline-secondary mb-0">
        Importar JSON <input type="file" id="g4fr-import-json" accept="application/json" hidden>
      </label>
      <button type="button" id="g4fr-export" class="btn btn-success" disabled>Exportar DOCX</button>
    </div>
  </div>

  <div id="g4fr-status" class="g4fr-status"></div>
  <div id="g4fr-preview"></div>
</div>
<script>
window.G4FREPORTS = {
  root: <?php echo json_encode($rootdoc . '/plugins/g4freports'); ?>
};
</script>
<script src="<?php echo htmlspecialchars($rootdoc . '/plugins/g4freports/assets/js/report.js'); ?>"></script>
<?php
if (class_exists('Html')) {
    Html::footer();
}
