<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Api\SearchOptionResolver;
use GlpiPlugin\G4freports\Util\Http;

if (class_exists('Session')) Session::checkLoginUser();
$cfg = Config::merged();
if (!Security::canUse($cfg)) Security::denyJson();

$data = Http::readJsonOrPost();
$q = trim((string)($data['q'] ?? ''));
if ($q === '') Http::jsonResponse(['ok' => true, 'users' => []]);
$profile = Config::getProfile(trim((string)($data['profile_id'] ?? ($cfg['default_profile_id'] ?? 'default'))), $cfg);
if (!$profile) Http::jsonResponse(['ok' => false, 'error' => 'Perfil de API não encontrado.'], 400);

try {
    $client = new GlpiApiClient($profile);
    $resolver = new SearchOptionResolver($client, json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true) ?: []);
    $fields = $resolver->fields('User', ['id' => [2], 'name' => [1], 'realname' => [9], 'firstname' => [34], 'login' => [1]]);
    $nameField = $fields['name'] ?: 1;
    $display = array_values(array_filter(array_unique([$fields['id'] ?: 2, $fields['name'] ?: 1, $fields['realname'], $fields['firstname']])));
    $res = $client->search('User', [['field' => $nameField, 'searchtype' => 'contains', 'value' => $q]], $display, '0-20');
    $users = [];
    foreach (($res['data'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $id = (int)($row[(string)($fields['id'] ?: 2)] ?? $row['2'] ?? 0);
        $name = (string)($row[(string)($fields['name'] ?: 1)] ?? $row['1'] ?? '');
        $real = (string)($row[(string)$fields['realname']] ?? '');
        $first = (string)($row[(string)$fields['firstname']] ?? '');
        $full = trim($first . ' ' . $real);
        $users[] = ['id' => $id, 'name' => $full !== '' ? $full : $name, 'login' => $name, 'raw' => $row];
    }
    $client->killSession();
    Http::jsonResponse(['ok' => true, 'users' => $users]);
} catch (Throwable $e) {
    Http::jsonResponse(['ok' => false, 'error' => $e->getMessage()], 500);
}
