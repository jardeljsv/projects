<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Util\Http;

if (class_exists('Session')) Session::checkLoginUser();
$cfg = Config::merged();
if (!Security::canUse($cfg)) Security::denyJson();

$data = Http::readJsonOrPost();
$itemtype = trim((string)($data['itemtype'] ?? 'Ticket'));
$profile = Config::getProfile(trim((string)($data['profile_id'] ?? ($cfg['default_profile_id'] ?? 'default'))), $cfg);
if (!$profile) Http::jsonResponse(['ok' => false, 'error' => 'Perfil de API não encontrado.'], 400);

try {
    $client = new GlpiApiClient($profile);
    $options = $client->listSearchOptions($itemtype);
    $client->killSession();
    Http::jsonResponse(['ok' => true, 'itemtype' => $itemtype, 'options' => $options]);
} catch (Throwable $e) {
    Http::jsonResponse(['ok' => false, 'error' => $e->getMessage()], 500);
}
