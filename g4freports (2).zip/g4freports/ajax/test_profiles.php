<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Util\Http;

if (class_exists('Session')) Session::checkLoginUser();
if (!Security::canConfigure()) Security::denyJson();

$data = Http::readJsonOrPost();
$profiles = json_decode((string)($data['api_profiles_json'] ?? '[]'), true);
if (!is_array($profiles)) {
    Http::jsonResponse(['ok' => false, 'error' => 'JSON inválido: ' . json_last_error_msg()], 400);
}
$out = [];
foreach ($profiles as $profile) {
    if (!is_array($profile)) continue;
    try {
        $client = new GlpiApiClient($profile);
        $client->initSession();
        $client->killSession();
        $out[] = ['id' => $profile['id'] ?? '', 'name' => $profile['name'] ?? '', 'ok' => true, 'base_url' => $client->getBaseUrl()];
    } catch (Throwable $e) {
        $out[] = ['id' => $profile['id'] ?? '', 'name' => $profile['name'] ?? '', 'ok' => false, 'error' => $e->getMessage()];
    }
}
Http::jsonResponse(['ok' => true, 'results' => $out]);
