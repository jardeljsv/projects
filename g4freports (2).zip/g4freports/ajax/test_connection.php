<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Util\Http;

if (class_exists('Session')) Session::checkLoginUser();
$cfg = Config::merged();
if (!Security::canUse($cfg)) Security::denyJson();

$data = Http::readJsonOrPost();
$profileId = trim((string)($data['profile_id'] ?? ($cfg['default_profile_id'] ?? 'default')));
$profile = Config::getProfile($profileId, $cfg);
if (!$profile) {
    Http::jsonResponse(['ok' => false, 'error' => 'Perfil de API não encontrado.'], 400);
}

try {
    $client = new GlpiApiClient($profile);
    $client->initSession();
    $session = null;
    try { $session = $client->request('GET', '/getFullSession'); } catch (Throwable $e) { $session = ['warning' => $e->getMessage()]; }
    $client->killSession();
    Http::jsonResponse(['ok' => true, 'base_url' => $client->getBaseUrl(), 'session' => $session]);
} catch (Throwable $e) {
    Http::jsonResponse(['ok' => false, 'error' => $e->getMessage()], 500);
}
