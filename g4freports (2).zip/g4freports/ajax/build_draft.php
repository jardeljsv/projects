<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Builder\ReportDraftBuilder;
use GlpiPlugin\G4freports\Util\Http;

if (class_exists('Session')) Session::checkLoginUser();
$cfg = Config::merged();
if (!Security::canUse($cfg)) Security::denyJson();

$data = Http::readJsonOrPost();
$profileId = trim((string)($data['profile_id'] ?? ($cfg['default_profile_id'] ?? 'default')));
$profile = Config::getProfile($profileId, $cfg);
if (!$profile) Http::jsonResponse(['ok' => false, 'error' => 'Perfil de API não encontrado.'], 400);

try {
    $builder = new ReportDraftBuilder($cfg, $profile);
    $draft = $builder->build($data);
    Http::jsonResponse(['ok' => true, 'draft' => $draft]);
} catch (Throwable $e) {
    Http::jsonResponse(['ok' => false, 'error' => $e->getMessage(), 'trace' => substr($e->getTraceAsString(), 0, 4000)], 500);
}
