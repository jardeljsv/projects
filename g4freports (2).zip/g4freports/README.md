# Relatórios G4F para GLPI

Plugin MVP para testar geração de relatórios GLPI via API, com rascunho editável em tela e exportação DOCX.

## Objetivo

O plugin foi desenhado como um gerador API-first, sem tabelas próprias de negócio. Ele usa a API REST do GLPI para montar um rascunho de relatório a partir de múltiplos contextos selecionáveis ao mesmo tempo:

- chamados atribuídos ao agente;
- chamados solicitados pelo agente;
- chamados atribuídos aos grupos do agente;
- tarefas de chamados feitas pelo agente;
- acompanhamentos feitos pelo agente;
- soluções registradas pelo agente;
- projetos gerenciados pelo agente;
- projetos gerenciados por grupos do agente;
- projetos em que o agente participa;
- tarefas de projeto do agente;
- tarefas de projeto dos grupos do agente;
- entradas narrativas manuais.

O agente principal é a âncora do relatório, não o único filtro possível.

## Instalação

1. Copie a pasta `g4freports` para `plugins/g4freports` no servidor GLPI.
2. Garanta que o PHP tenha `curl` habilitado.
3. Ative o plugin em **Configurar > Plugins**.
4. Acesse **Ferramentas > Relatórios G4F > Configurações**.
5. Configure pelo menos um perfil de API.

## Configuração da API

Exemplo de perfil:

```json
[
  {
    "id": "sesdf",
    "name": "SES-DF Produção",
    "base_url": "https://centraldeservicos.saude.df.gov.br/apirest.php",
    "app_token": "APP_TOKEN_AQUI",
    "user_token": "USER_TOKEN_AQUI",
    "session_token": "",
    "verify_tls": true,
    "timeout_ms": 60000,
    "default_entity_id": 0,
    "recursive_entities": true
  }
]
```

`base_url` pode apontar para `/apirest.php` ou para a raiz do GLPI; o plugin normaliza automaticamente.

Também é possível referenciar segredos por variável de ambiente:

```json
{
  "app_token_env": "G4FREPORTS_APP_TOKEN",
  "user_token_env": "G4FREPORTS_USER_TOKEN"
}
```

## Segurança

- As chamadas à API são feitas server-side pelo PHP do plugin.
- Tokens não são enviados ao navegador.
- O plugin suporta restrição por IDs de perfis e grupos GLPI locais.
- O exportador mascara CPF, e-mail e telefone por padrão.
- Para produção, prefira usuário de API com menor privilégio possível.

## Diagnóstico

Use **Ferramentas > Relatórios G4F > Diagnóstico** para:

- testar conexão e sessão de API;
- listar `Search Options` de `Ticket`, `Project`, `ProjectTask`, `User` e outros itemtypes;
- ajustar o JSON de mapeamento de campos caso a instância GLPI use IDs diferentes.

## Observações do MVP

- O plugin não cria tabelas próprias.
- Rascunhos podem ser baixados/importados como JSON para retomar edição.
- O DOCX é gerado sem dependência de PHPWord ou ZipArchive, usando OpenXML mínimo.
- Algumas buscas dependem dos `Search Options` expostos pela API da instância GLPI. Se um contexto retornar vazio, use a página de diagnóstico para mapear campos e preencher `field_overrides_json`.

## Estrutura

```text
g4freports/
  setup.php
  hook.php
  front/
    report.php
    config.php
    diagnostics.php
    export.php
  ajax/
    build_draft.php
    search_users.php
    search_options.php
    test_connection.php
  src/
    Api/
    Builder/
    Export/
    Util/
  assets/
    css/
    js/
  resources/img/
```
