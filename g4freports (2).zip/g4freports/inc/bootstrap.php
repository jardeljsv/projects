<?php

$autoload = dirname(__DIR__) . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

$glpiRoot = dirname(__DIR__, 3);
$includes = $glpiRoot . '/inc/includes.php';
if (is_file($includes)) {
    require_once $includes;
}
