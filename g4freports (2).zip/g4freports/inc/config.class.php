<?php

if (!class_exists('GlpiPlugin\\G4freports\\Config')) {
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
    }
}

class PluginG4freportsConfig extends \GlpiPlugin\G4freports\Config
{
}
