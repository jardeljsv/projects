<?php

if (!class_exists('GlpiPlugin\\G4freports\\Menu')) {
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
    }
}

class PluginG4freportsMenu extends \GlpiPlugin\G4freports\Menu
{
}
