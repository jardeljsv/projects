<?php

namespace GlpiPlugin\G4freports\Export;

use GlpiPlugin\G4freports\Util\DateHelper;
use GlpiPlugin\G4freports\Util\TextNormalizer;

class DocxExporter
{
    private string $logoPath;
    private string $navy = '002B49';
    private string $blue = '2F6FED';
    private string $teal = '188DA1';
    private string $light = 'EAF1F8';
    private string $border = 'B8C7D9';
    private string $yellow = 'FFF4CC';

    public function __construct(string $logoPath = '')
    {
        $this->logoPath = $logoPath;
    }

    public function toBinary(array $draft): string
    {
        $document = $this->documentXml($draft);
        $footer = $this->footerXml((string)($draft['footer'] ?? ''));
        $core = $this->coreXml($draft);
        $app = $this->appXml();
        $rels = $this->rootRelsXml();
        $docRels = $this->documentRelsXml($this->hasLogo());
        $contentTypes = $this->contentTypesXml($this->hasLogo());
        $styles = $this->stylesXml();
        $settings = $this->settingsXml();

        $files = [
            '[Content_Types].xml' => $contentTypes,
            '_rels/.rels' => $rels,
            'docProps/core.xml' => $core,
            'docProps/app.xml' => $app,
            'word/document.xml' => $document,
            'word/_rels/document.xml.rels' => $docRels,
            'word/styles.xml' => $styles,
            'word/settings.xml' => $settings,
            'word/footer1.xml' => $footer
        ];

        if ($this->hasLogo()) {
            $files['word/media/g4f-logo.png'] = file_get_contents($this->logoPath) ?: '';
        }

        return $this->zipStore($files);
    }

    public function filename(array $draft): string
    {
        $title = (string)($draft['report_title'] ?? 'relatorio-g4f');
        $subject = (string)($draft['subject']['name'] ?? 'profissional');
        $period = (string)($draft['period_start'] ?? '') . '_' . (string)($draft['period_end'] ?? '');
        $base = $title . '-' . $subject . '-' . $period;
        $base = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base) ?: $base;
        $base = preg_replace('/[^A-Za-z0-9_\-]+/', '-', $base) ?? $base;
        $base = trim($base, '-_');
        if ($base === '') {
            $base = 'relatorio-g4f';
        }
        return substr($base, 0, 140) . '.docx';
    }

    private function documentXml(array $draft): string
    {
        $body = [];
        $body[] = $this->logoParagraph();
        $body[] = $this->spacer(8);
        $body[] = $this->paragraph((string)($draft['report_title'] ?? 'Relatório Gerencial de Atividades'), 'Title', 'center', true, 48, $this->navy);
        $subtitle = trim((string)($draft['contract_label'] ?? '') . ' • ' . (string)($draft['connection']['name'] ?? 'GLPI'));
        if ($subtitle !== '•') {
            $body[] = $this->paragraph($subtitle, '', 'center', false, 22, '666666');
        }
        $period = DateHelper::displayDate((string)($draft['period_start'] ?? '')) . ' a ' . DateHelper::displayDate((string)($draft['period_end'] ?? ''));
        $subject = (string)($draft['subject']['name'] ?? 'Profissional não informado');
        $body[] = $this->paragraph('Profissional responsável: ' . $subject, '', 'center', false, 22, '666666');
        $body[] = $this->paragraph('Período: ' . $period, '', 'center', false, 22, '666666');
        $body[] = $this->spacer(8);
        $body[] = $this->metricCards($draft['metrics'] ?? []);
        $body[] = $this->callout('Leitura recomendada', 'Este documento foi gerado como rascunho normalizado a partir de dados da API do GLPI e entradas manuais. Revise as narrativas, validações e eventuais lacunas antes de enviar a versão final.', 'DCEBFF', $this->blue);
        $body[] = $this->paragraph('Data de emissão: ' . date('d/m/Y'), '', 'center', false, 20, '666666');
        $body[] = $this->pageBreak();

        $body[] = $this->heading('Sumário executivo', 1);
        $body[] = $this->blockParagraphs((string)($draft['executive_summary'] ?? ''), 22);

        $body[] = $this->heading('1. Abrangência', 1);
        $body[] = $this->blockParagraphs((string)($draft['scope_text'] ?? ''), 22);

        $body[] = $this->heading('2. Objetivo', 1);
        $body[] = $this->blockParagraphs((string)($draft['objective_text'] ?? ''), 22);

        $body[] = $this->heading('3. Indicadores consolidados', 1);
        $body[] = $this->indicatorTable($draft['metrics'] ?? []);

        if (!empty($draft['validations']) && is_array($draft['validations'])) {
            $txt = [];
            foreach ($draft['validations'] as $validation) {
                if (!is_array($validation)) continue;
                $txt[] = strtoupper((string)($validation['level'] ?? 'info')) . ': ' . (string)($validation['message'] ?? '');
            }
            if (!empty($txt)) {
                $body[] = $this->callout('Validações do rascunho', implode("\n", $txt), $this->yellow, 'D39E00');
            }
        }

        $body[] = $this->heading('4. Detalhamento diário', 1);
        $daily = $this->dailyGroups($draft);
        if (empty($daily)) {
            $body[] = $this->paragraph('Nenhuma entrada foi incluída no relatório para o período selecionado.', '', 'left', false, 22, '333333');
        } else {
            foreach ($daily as $group) {
                $body[] = $this->heading(DateHelper::displayDate((string)$group['date']), 2);
                foreach ($group['entries'] as $entry) {
                    $body[] = $this->entryBlock($entry);
                }
            }
        }

        $body[] = $this->heading('5. Pendências e próximos passos', 1);
        $next = $this->collectNextSteps($draft);
        $body[] = $this->blockParagraphs($next ?: 'Não foram registradas pendências específicas no rascunho. Complementar manualmente, caso aplicável.', 22);

        $body[] = $this->heading('6. Conclusão', 1);
        $body[] = $this->blockParagraphs((string)($draft['conclusion_text'] ?? 'As atividades foram consolidadas em formato padronizado para facilitar conferência, ajuste narrativo e envio gerencial. O documento deve ser revisado pelo responsável antes da formalização.'), 22);

        $body[] = $this->signatureBlock($subject);

        $sectPr = '<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">' .
            '<w:body>' . implode('', $body) . $sectPr . '</w:body></w:document>';
    }

    private function dailyGroups(array $draft): array
    {
        $groups = [];
        $entries = is_array($draft['entries'] ?? null) ? $draft['entries'] : [];
        foreach ($entries as $entry) {
            if (!is_array($entry) || empty($entry['include_in_report'])) continue;
            $date = DateHelper::normalizeDate((string)($entry['date'] ?? ''), date('Y-m-d'));
            if (!isset($groups[$date])) $groups[$date] = ['date' => $date, 'entries' => []];
            $groups[$date]['entries'][] = $entry;
        }
        ksort($groups);
        return array_values($groups);
    }

    private function collectNextSteps(array $draft): string
    {
        $lines = [];
        foreach (($draft['entries'] ?? []) as $entry) {
            if (!is_array($entry) || empty($entry['include_in_report'])) continue;
            $next = trim((string)($entry['next_steps'] ?? ''));
            if ($next !== '') {
                $lines[] = '• ' . ((string)($entry['title'] ?? 'Atividade')) . ': ' . $next;
            }
        }
        return implode("\n", array_slice($lines, 0, 50));
    }

    private function entryBlock(array $entry): string
    {
        $title = (string)($entry['title'] ?? 'Atividade');
        $ref = trim((string)($entry['source_reference'] ?? ''));
        $status = trim((string)($entry['status'] ?? ''));
        $category = trim((string)($entry['category'] ?? ''));
        $meta = [];
        if ($ref !== '') $meta[] = $ref;
        if ($status !== '') $meta[] = 'Status: ' . $status;
        if ($category !== '') $meta[] = 'Categoria: ' . $category;

        $xml = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/><w:tblBorders>' . $this->borders($this->border) . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid>';
        $xml .= '<w:tr><w:tc><w:tcPr><w:shd w:fill="' . $this->light . '"/><w:tcW w:w="9500" w:type="dxa"/></w:tcPr>';
        $xml .= $this->paragraph($title, '', 'left', true, 22, $this->navy);
        if (!empty($meta)) {
            $xml .= $this->paragraph(implode(' | ', $meta), '', 'left', false, 18, '666666');
        }
        $xml .= '</w:tc></w:tr>';
        $xml .= '<w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/></w:tcPr>';
        $xml .= $this->labelAndBlock('Atividades realizadas', (string)($entry['activity_performed'] ?? ''));
        $xml .= $this->labelAndBlock('Resultado', (string)($entry['result'] ?? ''));
        if (trim((string)($entry['next_steps'] ?? '')) !== '') {
            $xml .= $this->labelAndBlock('Plano de tratamento / próximos passos', (string)$entry['next_steps']);
        }
        if (trim((string)($entry['observations'] ?? '')) !== '') {
            $xml .= $this->labelAndBlock('Observações', (string)$entry['observations']);
        }
        $xml .= '</w:tc></w:tr></w:tbl>';
        $xml .= $this->spacer(4);
        return $xml;
    }

    private function labelAndBlock(string $label, string $text): string
    {
        $text = trim($text);
        if ($text === '') return '';
        return $this->paragraph($label, '', 'left', true, 20, $this->navy) . $this->blockParagraphs($text, 20);
    }

    private function metricCards(array $metrics): string
    {
        if (empty($metrics)) return '';
        $cells = '';
        $count = 0;
        foreach (array_slice($metrics, 0, 4) as $metric) {
            if (!is_array($metric)) continue;
            $count++;
            $fill = $count === 3 ? $this->teal : $this->navy;
            $cells .= '<w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>';
            $cells .= $this->paragraph((string)($metric['value'] ?? ''), '', 'center', true, 32, 'FFFFFF');
            $cells .= $this->paragraph((string)($metric['label'] ?? ''), '', 'center', false, 16, 'FFFFFF');
            $cells .= '</w:tc>';
        }
        while ($count < 4) {
            $count++;
            $cells .= '<w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/><w:shd w:fill="' . $this->navy . '"/></w:tcPr>' . $this->paragraph('-', '', 'center', true, 32, 'FFFFFF') . '</w:tc>';
        }
        return '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders('FFFFFF') . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/><w:gridCol w:w="2375"/></w:tblGrid><w:tr>' . $cells . '</w:tr></w:tbl>' . $this->spacer(8);
    }

    private function indicatorTable(array $metrics): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders($this->border) . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="4750"/><w:gridCol w:w="4750"/></w:tblGrid>';
        $xml .= '<w:tr>' . $this->cell('Indicador', $this->navy, 'FFFFFF', true) . $this->cell('Valor', $this->navy, 'FFFFFF', true) . '</w:tr>';
        foreach ($metrics as $metric) {
            if (!is_array($metric)) continue;
            $xml .= '<w:tr>' . $this->cell((string)($metric['label'] ?? ''), 'FFFFFF', '222222', false) . $this->cell((string)($metric['value'] ?? ''), 'FFFFFF', '222222', true) . '</w:tr>';
        }
        $xml .= '</w:tbl>' . $this->spacer(6);
        return $xml;
    }

    private function signatureBlock(string $subject): string
    {
        $xml = $this->spacer(24);
        $xml .= $this->paragraph('________________________________________', '', 'center', false, 20, '333333');
        $xml .= $this->paragraph($subject, '', 'center', true, 20, '333333');
        $xml .= $this->paragraph('Profissional responsável', '', 'center', false, 18, '666666');
        return $xml;
    }

    private function callout(string $title, string $text, string $fill, string $accent): string
    {
        $xml = '<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblBorders>' . $this->borders($accent) . '</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>';
        $xml .= $this->paragraph($title, '', 'left', true, 20, $this->navy);
        $xml .= $this->blockParagraphs($text, 18);
        $xml .= '</w:tc></w:tr></w:tbl>' . $this->spacer(8);
        return $xml;
    }

    private function heading(string $text, int $level): string
    {
        $style = $level === 1 ? 'Heading1' : 'Heading2';
        $size = $level === 1 ? 34 : 26;
        $color = $level === 1 ? $this->navy : $this->blue;
        return $this->paragraph($text, $style, 'left', false, $size, $color);
    }

    private function blockParagraphs(string $text, int $size = 22): string
    {
        $text = TextNormalizer::clean($text, false);
        if ($text === '') {
            return '';
        }
        $out = [];
        foreach (preg_split('/\n+/', $text) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (preg_match('/^[•\-*]\s*(.+)$/u', $line, $m)) {
                $out[] = $this->paragraph('• ' . $m[1], '', 'left', false, $size, '333333');
            } else {
                $out[] = $this->paragraph($line, '', 'left', false, $size, '333333');
            }
        }
        return implode('', $out);
    }

    private function paragraph(string $text, string $style = '', string $align = 'left', bool $bold = false, int $size = 22, string $color = '333333'): string
    {
        $pPr = '';
        if ($style !== '') {
            $pPr .= '<w:pStyle w:val="' . $this->x($style) . '"/>';
        }
        if ($align !== '') {
            $pPr .= '<w:jc w:val="' . $this->x($align) . '"/>';
        }
        $pPr .= '<w:spacing w:after="120" w:line="276" w:lineRule="auto"/>';
        $rPr = '<w:rPr>' . ($bold ? '<w:b/>' : '') . '<w:sz w:val="' . (int)$size . '"/><w:szCs w:val="' . (int)$size . '"/><w:color w:val="' . $this->x($color) . '"/></w:rPr>';
        return '<w:p><w:pPr>' . $pPr . '</w:pPr><w:r>' . $rPr . '<w:t xml:space="preserve">' . $this->x($text) . '</w:t></w:r></w:p>';
    }

    private function cell(string $text, string $fill, string $color, bool $bold): string
    {
        return '<w:tc><w:tcPr><w:tcW w:w="4750" w:type="dxa"/><w:shd w:fill="' . $fill . '"/></w:tcPr>' . $this->paragraph($text, '', 'center', $bold, 18, $color) . '</w:tc>';
    }

    private function spacer(int $after): string
    {
        return '<w:p><w:pPr><w:spacing w:after="' . (int)($after * 20) . '"/></w:pPr></w:p>';
    }

    private function pageBreak(): string
    {
        return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
    }

    private function borders(string $color): string
    {
        return '<w:top w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:left w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:right w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="' . $color . '"/>';
    }

    private function logoParagraph(): string
    {
        if (!$this->hasLogo()) {
            return $this->paragraph('G4F', '', 'left', true, 26, $this->navy);
        }
        $cx = 1600000;
        $cy = 750000;
        return '<w:p><w:pPr><w:jc w:val="left"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' . $cx . '" cy="' . $cy . '"/><wp:docPr id="1" name="G4F Logo"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="g4f-logo.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdLogo"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
    }

    private function hasLogo(): bool
    {
        return $this->logoPath !== '' && is_file($this->logoPath) && is_readable($this->logoPath);
    }

    private function footerXml(string $footer): string
    {
        $footer = trim($footer) ?: 'G4F';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="14"/><w:color w:val="666666"/></w:rPr><w:t xml:space="preserve">' . $this->x($footer) . '</w:t></w:r></w:p></w:ftr>';
    }

    private function documentRelsXml(bool $logo): string
    {
        $rels = '<Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>';
        if ($logo) {
            $rels .= '<Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/g4f-logo.png"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $rels . '</Relationships>';
    }

    private function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';
    }

    private function contentTypesXml(bool $logo): string
    {
        $png = $logo ? '<Default Extension="png" ContentType="image/png"/>' : '';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' . $png . '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';
    }

    private function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:jc w:val="center"/><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="48"/><w:color w:val="' . $this->navy . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr><w:rPr><w:sz w:val="34"/><w:color w:val="' . $this->navy . '"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="180" w:after="80"/></w:pPr><w:rPr><w:b/><w:sz w:val="26"/><w:color w:val="' . $this->blue . '"/></w:rPr></w:style></w:styles>';
    }

    private function settingsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:zoom w:percent="100"/><w:defaultTabStop w:val="708"/></w:settings>';
    }

    private function coreXml(array $draft): string
    {
        $title = (string)($draft['report_title'] ?? 'Relatório G4F');
        $created = date('c');
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' . $this->x($title) . '</dc:title><dc:creator>Relatórios G4F</dc:creator><cp:lastModifiedBy>Relatórios G4F</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:modified></cp:coreProperties>';
    }

    private function appXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Relatórios G4F</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company>G4F</Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.1.0</AppVersion></Properties>';
    }

    private function zipStore(array $files): string
    {
        $local = '';
        $central = '';
        $offset = 0;
        $count = 0;
        foreach ($files as $name => $content) {
            $name = str_replace('\\', '/', (string)$name);
            $content = (string)$content;
            $crc = crc32($content);
            if ($crc < 0) {
                $crc = $crc + 4294967296;
            }
            $size = strlen($content);
            $time = 0;
            $date = 0;
            $nameLen = strlen($name);
            $localHeader = pack('VvvvvvVVVvv', 0x04034b50, 20, 0, 0, $time, $date, $crc, $size, $size, $nameLen, 0) . $name;
            $local .= $localHeader . $content;
            $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 0x031E, 20, 0, 0, $time, $date, $crc, $size, $size, $nameLen, 0, 0, 0, 0, 0, $offset) . $name;
            $offset += strlen($localHeader) + $size;
            $count++;
        }
        $end = pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($central), strlen($local), 0);
        return $local . $central . $end;
    }

    private function x(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}
