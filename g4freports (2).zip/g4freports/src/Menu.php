<?php

namespace GlpiPlugin\G4freports;

class Menu extends \CommonGLPI
{
    public static function getTypeName($nb = 0)
    {
        return __('Relatórios G4F', 'g4freports');
    }

    public static function getMenuName()
    {
        return self::getTypeName();
    }

    public static function getMenuContent(): array
    {
        global $CFG_GLPI;

        $base = ($CFG_GLPI['root_doc'] ?? '') . '/plugins/g4freports/front';

        $menu = [];
        $menu['title'] = self::getMenuName();
        $menu['page']  = $base . '/report.php';
        $menu['icon']  = 'ti ti-file-export';

        $menu['options']['generate'] = [
            'title' => __('Gerar relatório', 'g4freports'),
            'page'  => $base . '/report.php',
            'icon'  => 'ti ti-file-export'
        ];

        $menu['options']['config'] = [
            'title' => __('Configurações', 'g4freports'),
            'page'  => $base . '/config.php',
            'icon'  => 'ti ti-settings'
        ];

        $menu['options']['diagnostics'] = [
            'title' => __('Diagnóstico', 'g4freports'),
            'page'  => $base . '/diagnostics.php',
            'icon'  => 'ti ti-stethoscope'
        ];

        return $menu;
    }
}
