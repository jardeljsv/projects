<?php

namespace GlpiPlugin\G4freports;

use CommonGLPI;

class Config extends \Config
{
    public static function getTypeName($nb = 0)
    {
        return __('Relatórios G4F', 'g4freports');
    }

    public static function getConfig(): array
    {
        $cfg = \Config::getConfigurationValues('plugin:g4freports');
        return is_array($cfg) ? $cfg : [];
    }

    public static function getDefaultConfig(): array
    {
        return [
            'enabled'                => 1,
            'allowed_groups'         => '',
            'allowed_profiles'       => '',
            'api_profiles_json'      => '[]',
            'default_profile_id'     => 'default',
            'max_items'              => 200,
            'request_timeout_ms'     => 60000,
            'mask_sensitive_data'    => 1,
            'field_overrides_json'   => '{}',
            'default_footer'         => 'Brasília - DF, 70712-900 | SCN Q 2 BL A - Asa Norte, Corporate Financial Center | contato@g4f.com.br | www.g4f.com.br',
            'contract_label'         => 'SES-DF',
            'default_report_title'   => 'Relatório Gerencial de Atividades',
            'default_scope_text'     => 'Este relatório apresenta as atividades executadas no período selecionado, consolidando registros obtidos via GLPI e complementações narrativas inseridas pelo profissional responsável.',
            'default_objective_text' => 'Formalizar, padronizar e evidenciar as ações técnicas executadas, mantendo rastreabilidade por chamados, projetos, tarefas, acompanhamentos e registros manuais.'
        ];
    }

    public static function merged(): array
    {
        return array_replace(self::getDefaultConfig(), self::getConfig());
    }

    public static function save(array $values): void
    {
        \Config::setConfigurationValues('plugin:g4freports', $values);
    }

    public static function profiles(array $cfg = null): array
    {
        $cfg = $cfg ?? self::merged();
        $raw = (string)($cfg['api_profiles_json'] ?? '[]');
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }
        $out = [];
        foreach ($decoded as $profile) {
            if (!is_array($profile)) {
                continue;
            }
            $id = trim((string)($profile['id'] ?? ''));
            if ($id === '') {
                $id = 'profile_' . (count($out) + 1);
            }
            $profile['id'] = $id;
            $out[$id] = $profile;
        }
        return $out;
    }

    public static function getProfile(string $id, array $cfg = null): ?array
    {
        $profiles = self::profiles($cfg);
        if (isset($profiles[$id])) {
            return $profiles[$id];
        }
        if (!empty($profiles)) {
            return reset($profiles);
        }
        return null;
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case \Config::class:
                return self::createTabEntry(self::getTypeName());
        }
        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        global $CFG_GLPI;
        echo '<div class="center"><p><a class="btn btn-primary" href="' . htmlspecialchars(($CFG_GLPI['root_doc'] ?? '') . '/plugins/g4freports/front/config.php', ENT_QUOTES, 'UTF-8') . '">Abrir configurações do plugin Relatórios G4F</a></p></div>';
        return true;
    }
}
