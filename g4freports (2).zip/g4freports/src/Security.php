<?php

namespace GlpiPlugin\G4freports;

class Security
{
    public static function currentUserId(): int
    {
        try {
            if (class_exists('Session') && method_exists('Session', 'getLoginUserID')) {
                $uid = (int)\Session::getLoginUserID();
                if ($uid > 0) {
                    return $uid;
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return (int)($_SESSION['glpiID'] ?? 0);
    }

    public static function currentProfileId(): int
    {
        return (int)($_SESSION['glpiactiveprofile']['id'] ?? 0);
    }

    public static function currentGroupIds(): array
    {
        $ids = [];
        if (isset($_SESSION['glpigroups']) && is_array($_SESSION['glpigroups'])) {
            foreach ($_SESSION['glpigroups'] as $k => $v) {
                if (is_numeric($k) && (int)$k > 0) {
                    $ids[(int)$k] = true;
                }
                if (is_numeric($v) && (int)$v > 0) {
                    $ids[(int)$v] = true;
                }
            }
        }
        return array_keys($ids);
    }

    public static function parseIds($raw): array
    {
        if (is_array($raw)) {
            $out = [];
            foreach ($raw as $v) {
                $id = (int)$v;
                if ($id > 0) $out[$id] = true;
            }
            return array_keys($out);
        }
        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return self::parseIds($decoded);
        }
        $out = [];
        foreach (preg_split('/[^0-9]+/', $raw) as $part) {
            $id = (int)$part;
            if ($id > 0) {
                $out[$id] = true;
            }
        }
        return array_keys($out);
    }

    public static function canConfigure(): bool
    {
        try {
            if (class_exists('Session') && method_exists('Session', 'haveRight')) {
                return \Session::haveRight('config', UPDATE);
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return false;
    }

    public static function canUse(array $cfg = null): bool
    {
        $cfg = $cfg ?? Config::merged();
        if ((int)($cfg['enabled'] ?? 1) !== 1) {
            return false;
        }

        if (self::canConfigure()) {
            return true;
        }

        $allowedProfiles = self::parseIds($cfg['allowed_profiles'] ?? '');
        if (!empty($allowedProfiles)) {
            $pid = self::currentProfileId();
            if ($pid > 0 && in_array($pid, $allowedProfiles, true)) {
                return true;
            }
        }

        $allowedGroups = self::parseIds($cfg['allowed_groups'] ?? '');
        if (!empty($allowedGroups)) {
            $userGroups = self::currentGroupIds();
            foreach ($userGroups as $gid) {
                if (in_array((int)$gid, $allowedGroups, true)) {
                    return true;
                }
            }
            return false;
        }

        // No restrictions means any authenticated GLPI user can open the module.
        return self::currentUserId() > 0;
    }

    public static function denyJson(int $code = 403, string $message = 'Acesso negado'): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
