<?php

namespace GlpiPlugin\G4freports\Builder;

use GlpiPlugin\G4freports\Api\GlpiApiClient;
use GlpiPlugin\G4freports\Api\SearchOptionResolver;
use GlpiPlugin\G4freports\Util\DateHelper;
use GlpiPlugin\G4freports\Util\TextNormalizer;

class ReportDraftBuilder
{
    private array $cfg;
    private array $profile;
    private GlpiApiClient $client;
    private SearchOptionResolver $resolver;
    private array $warnings = [];
    private bool $maskSensitive = true;
    private int $maxItems = 200;

    public function __construct(array $cfg, array $profile)
    {
        $this->cfg = $cfg;
        $this->profile = $profile;
        $this->client = new GlpiApiClient($profile);
        $overrides = json_decode((string)($cfg['field_overrides_json'] ?? '{}'), true);
        $this->resolver = new SearchOptionResolver($this->client, is_array($overrides) ? $overrides : []);
        $this->maskSensitive = ((int)($cfg['mask_sensitive_data'] ?? 1)) === 1;
        $this->maxItems = max(10, min(1000, (int)($cfg['max_items'] ?? 200)));
    }

    public function build(array $request): array
    {
        $start = DateHelper::normalizeDate((string)($request['period_start'] ?? ''), date('Y-m-01'));
        $end   = DateHelper::normalizeDate((string)($request['period_end'] ?? ''), date('Y-m-t'));
        if (strtotime($end) < strtotime($start)) {
            [$start, $end] = [$end, $start];
        }

        $agentId = (int)($request['agent_id'] ?? 0);
        $contexts = $request['contexts'] ?? [];
        if (!is_array($contexts)) {
            $contexts = preg_split('/[,\s]+/', (string)$contexts) ?: [];
        }
        $contexts = array_values(array_unique(array_filter(array_map('strval', $contexts))));
        if (empty($contexts)) {
            $contexts = ['tickets_assigned_user', 'ticket_tasks_by_user', 'ticket_followups_by_user', 'ticket_solutions_by_user', 'projects_member_user', 'project_tasks_user', 'manual_entries'];
        }

        $manualGroupIds = $this->parseIdList($request['group_ids'] ?? '');
        $template = trim((string)($request['template'] ?? 'operational')) ?: 'operational';

        $agent = ['id' => $agentId, 'name' => trim((string)($request['agent_name'] ?? ''))];
        if ($agentId > 0) {
            try {
                $item = $this->client->getItem('User', $agentId, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                $agent['raw'] = $item;
                $agent['name'] = TextNormalizer::firstNonEmpty($item['name'] ?? '', $item['realname'] ?? '', $item['firstname'] ?? '', $agent['name']);
                if (isset($item['firstname']) || isset($item['realname'])) {
                    $full = trim((string)($item['firstname'] ?? '') . ' ' . (string)($item['realname'] ?? ''));
                    if ($full !== '') {
                        $agent['name'] = $full;
                    }
                }
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível obter dados completos do agente via API: ' . $e->getMessage();
            }
        }
        if ($agent['name'] === '') {
            $agent['name'] = $agentId > 0 ? ('Usuário ID ' . $agentId) : 'Profissional não informado';
        }

        $apiGroupIds = $agentId > 0 ? $this->resolveUserGroups($agentId) : [];
        $groupIds = array_values(array_unique(array_merge($apiGroupIds, $manualGroupIds)));
        $groups = $this->resolveGroups($groupIds);

        $entries = [];
        $seen = [];

        if ($agentId <= 0 && $this->requiresAgent($contexts)) {
            $this->warnings[] = 'Nenhum agente foi informado. Os contextos vinculados a usuário podem retornar poucos dados.';
        }

        if ($this->hasAny($contexts, ['tickets_assigned_user','tickets_requested_by_user','tickets_assigned_groups','ticket_tasks_by_user','ticket_followups_by_user','ticket_solutions_by_user'])) {
            $tickets = $this->collectTickets($agentId, $groupIds, $contexts, $start, $end);
            foreach ($tickets as $ticketId => $ticket) {
                $ticketEntries = $this->ticketToEntries((int)$ticketId, $ticket, $agentId, $contexts, $start, $end);
                foreach ($ticketEntries as $entry) {
                    $this->addEntry($entries, $seen, $entry);
                }
                if (count($entries) >= $this->maxItems) {
                    $this->warnings[] = 'Limite máximo de entradas atingido durante a leitura de chamados. Ajuste o período, os contextos ou o limite nas configurações.';
                    break;
                }
            }
        }

        if ($this->hasAny($contexts, ['projects_managed_by_user','projects_managed_by_groups','projects_member_user','project_tasks_user','project_tasks_groups'])) {
            $projects = $this->collectProjects($agentId, $groupIds, $contexts, $start, $end);
            foreach ($projects as $projectId => $project) {
                $projectEntries = $this->projectToEntries((int)$projectId, $project, $agentId, $groupIds, $contexts, $start, $end);
                foreach ($projectEntries as $entry) {
                    $this->addEntry($entries, $seen, $entry);
                }
                if (count($entries) >= $this->maxItems) {
                    $this->warnings[] = 'Limite máximo de entradas atingido durante a leitura de projetos. Ajuste o período, os contextos ou o limite nas configurações.';
                    break;
                }
            }
        }

        usort($entries, static function ($a, $b) {
            $d = strcmp((string)($a['date'] ?? ''), (string)($b['date'] ?? ''));
            if ($d !== 0) return $d;
            return strcmp((string)($a['title'] ?? ''), (string)($b['title'] ?? ''));
        });

        $metrics = $this->calculateMetrics($entries);
        $daily = $this->groupByDay($entries);
        $validations = $this->validateDraft($entries, $contexts, $start, $end);

        return [
            'schema_version' => 1,
            'created_at' => date('c'),
            'connection' => [
                'id' => (string)($this->profile['id'] ?? 'default'),
                'name' => (string)($this->profile['name'] ?? 'GLPI')
            ],
            'contract_label' => (string)($this->cfg['contract_label'] ?? ''),
            'report_title' => trim((string)($request['report_title'] ?? '')) ?: (string)($this->cfg['default_report_title'] ?? 'Relatório Gerencial de Atividades'),
            'template' => $template,
            'period_start' => $start,
            'period_end' => $end,
            'subject' => [
                'type' => 'user',
                'id' => $agentId,
                'name' => $agent['name']
            ],
            'groups' => array_values($groups),
            'contexts' => $contexts,
            'scope_text' => (string)($request['scope_text'] ?? ($this->cfg['default_scope_text'] ?? '')),
            'objective_text' => (string)($request['objective_text'] ?? ($this->cfg['default_objective_text'] ?? '')),
            'executive_summary' => $this->defaultExecutiveSummary($entries, $agent['name'], $start, $end),
            'metrics' => $metrics,
            'entries' => $entries,
            'daily_groups' => $daily,
            'validations' => $validations,
            'warnings' => array_values(array_unique($this->warnings)),
            'footer' => (string)($this->cfg['default_footer'] ?? '')
        ];
    }

    private function collectTickets(int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $fields = $this->resolver->fields('Ticket', [
            'id' => [2], 'name' => [1], 'status' => [12], 'date' => [15], 'date_mod' => [19],
            'closedate' => [16], 'solvedate' => [18], 'users_id_assign' => [5],
            'groups_id_assign' => [8], 'users_id_recipient' => [4], 'itilcategories_id' => [7], 'priority' => [3]
        ]);
        $display = array_values(array_filter($fields));
        $tickets = [];

        if ($agentId > 0 && in_array('tickets_assigned_user', $contexts, true) && $fields['users_id_assign'] > 0) {
            $this->mergeSearchRows($tickets, 'Ticket', [
                $this->crit($fields['users_id_assign'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'tickets_assigned_user');
        }

        if ($agentId > 0 && in_array('tickets_requested_by_user', $contexts, true) && $fields['users_id_recipient'] > 0) {
            $this->mergeSearchRows($tickets, 'Ticket', [
                $this->crit($fields['users_id_recipient'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'tickets_requested_by_user');
        }

        if (in_array('tickets_assigned_groups', $contexts, true) && $fields['groups_id_assign'] > 0) {
            foreach ($groupIds as $gid) {
                $this->mergeSearchRows($tickets, 'Ticket', [
                    $this->crit($fields['groups_id_assign'], 'equals', (int)$gid),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
                ], $display, 'tickets_assigned_groups');
            }
        }

        // Direct subitem searches can discover work performed by the agent even when the ticket is not assigned to them.
        if ($agentId > 0 && in_array('ticket_tasks_by_user', $contexts, true)) {
            foreach ($this->searchSubitemParents('TicketTask', 'tickets_id', $agentId, $start, $end) as $ticketId) {
                $tickets[$ticketId]['_sources']['ticket_tasks_by_user'] = true;
            }
        }
        if ($agentId > 0 && in_array('ticket_followups_by_user', $contexts, true)) {
            foreach ($this->searchSubitemParents('ITILFollowup', 'items_id', $agentId, $start, $end, 'Ticket') as $ticketId) {
                $tickets[$ticketId]['_sources']['ticket_followups_by_user'] = true;
            }
        }
        if ($agentId > 0 && in_array('ticket_solutions_by_user', $contexts, true)) {
            foreach ($this->searchSubitemParents('ITILSolution', 'items_id', $agentId, $start, $end, 'Ticket') as $ticketId) {
                $tickets[$ticketId]['_sources']['ticket_solutions_by_user'] = true;
            }
        }

        // Enrich each ticket item.
        foreach (array_keys($tickets) as $id) {
            try {
                $tickets[$id]['item'] = $this->client->getItem('Ticket', (int)$id, ['expand_dropdowns' => true, 'get_hateoas' => false]);
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível detalhar o chamado ' . $id . ': ' . $e->getMessage();
            }
        }

        return $tickets;
    }

    private function collectProjects(int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $fields = $this->resolver->fields('Project', [
            'id' => [2], 'name' => [1], 'status' => [12], 'date_mod' => [19], 'date' => [15],
            'manager_user' => [4], 'manager_group' => [8], 'percent_done' => [86], 'code' => [3]
        ]);
        $display = array_values(array_filter($fields));
        $projects = [];

        if ($agentId > 0 && in_array('projects_managed_by_user', $contexts, true) && $fields['manager_user'] > 0) {
            $this->mergeSearchRows($projects, 'Project', [
                $this->crit($fields['manager_user'], 'equals', $agentId),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'projects_managed_by_user');
        }

        if (in_array('projects_managed_by_groups', $contexts, true) && $fields['manager_group'] > 0) {
            foreach ($groupIds as $gid) {
                $this->mergeSearchRows($projects, 'Project', [
                    $this->crit($fields['manager_group'], 'equals', (int)$gid),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00', 'AND'),
                    $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
                ], $display, 'projects_managed_by_groups');
            }
        }

        if ($agentId > 0 && in_array('project_tasks_user', $contexts, true)) {
            foreach ($this->searchSubitemParents('ProjectTask', 'projects_id', $agentId, $start, $end) as $projectId) {
                $projects[$projectId]['_sources']['project_tasks_user'] = true;
            }
        }

        if (in_array('project_tasks_groups', $contexts, true)) {
            // Some GLPI setups do not expose group assignment for ProjectTask as a searchable field.
            // Project details below still try to read task team/subitems.
            if (empty($groupIds)) {
                $this->warnings[] = 'Contexto de tarefas de projeto por grupo selecionado, mas nenhum grupo foi resolvido para o agente.';
            }
        }

        // Project team membership is safest via subitem on candidate managed projects. If no candidate exists,
        // search all projects updated in the period up to the configured limit and filter team locally.
        if ($agentId > 0 && in_array('projects_member_user', $contexts, true)) {
            $this->mergeSearchRows($projects, 'Project', [
                $this->crit($fields['date_mod'] ?: $fields['date'], 'morethan', $start . ' 00:00:00'),
                $this->crit($fields['date_mod'] ?: $fields['date'], 'lessthan', $end . ' 23:59:59', 'AND')
            ], $display, 'projects_member_probe');
        }

        foreach (array_keys($projects) as $id) {
            try {
                $projects[$id]['item'] = $this->client->getItem('Project', (int)$id, ['expand_dropdowns' => true, 'get_hateoas' => false]);
            } catch (\Throwable $e) {
                $this->warnings[] = 'Não foi possível detalhar o projeto ' . $id . ': ' . $e->getMessage();
            }
        }

        return $projects;
    }

    private function ticketToEntries(int $ticketId, array $ticket, int $agentId, array $contexts, string $start, string $end): array
    {
        $item = $ticket['item'] ?? [];
        $row = $ticket['row'] ?? [];
        $title = TextNormalizer::firstNonEmpty($item['name'] ?? '', $this->rowVal($row, 1), 'Chamado ' . $ticketId);
        $status = TextNormalizer::firstNonEmpty($item['status'] ?? '', $item['tickets_id'] ?? '', $this->rowVal($row, 12));
        $date = TextNormalizer::firstNonEmpty($item['date_mod'] ?? '', $item['date'] ?? '', $this->rowVal($row, 19), $this->rowVal($row, 15), $start);
        $entries = [];

        $content = TextNormalizer::clean($item['content'] ?? '', $this->maskSensitive);
        $solutionSummary = '';
        foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILSolution') as $sol) {
            $solutionSummary .= "\n" . TextNormalizer::clean($sol['content'] ?? ($sol['solution'] ?? ''), $this->maskSensitive);
        }
        $baseText = trim($solutionSummary) ?: $content;

        if (!empty($ticket['_sources']['tickets_assigned_user']) || !empty($ticket['_sources']['tickets_requested_by_user']) || !empty($ticket['_sources']['tickets_assigned_groups'])) {
            $entries[] = $this->entry([
                'date' => $date,
                'source_type' => 'ticket',
                'source_itemtype' => 'Ticket',
                'source_id' => $ticketId,
                'source_reference' => 'Chamado ' . $ticketId,
                'title' => 'Chamado ' . $ticketId . ' - ' . $title,
                'status' => $status,
                'category' => TextNormalizer::firstNonEmpty($item['itilcategories_id'] ?? '', $this->rowVal($row, 7)),
                'activity_performed' => TextNormalizer::summarize($baseText ?: 'Registro localizado no GLPI dentro do contexto selecionado. Complementar a narrativa técnica, se necessário.', 1600),
                'result' => $this->resultFromStatus($status),
                'next_steps' => '',
                'observations' => 'Origem: chamado vinculado ao contexto selecionado.'
            ]);
        }

        if (in_array('ticket_tasks_by_user', $contexts, true)) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'TicketTask') as $task) {
                $taskDate = TextNormalizer::firstNonEmpty($task['date'] ?? '', $task['begin'] ?? '', $task['date_creation'] ?? '', $task['date_mod'] ?? '', $date);
                if (!DateHelper::within($taskDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($task, $agentId)) continue;
                $txt = TextNormalizer::clean($task['content'] ?? ($task['name'] ?? ''), $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $taskDate,
                    'source_type' => 'ticket_task',
                    'source_itemtype' => 'TicketTask',
                    'source_id' => (int)($task['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Tarefa ' . (int)($task['id'] ?? 0),
                    'title' => 'Tarefa do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Tarefa registrada no chamado.',
                    'result' => $this->resultFromStatus($status),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de tarefa do GLPI.'
                ]);
            }
        }

        if (in_array('ticket_followups_by_user', $contexts, true)) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILFollowup') as $follow) {
                $fDate = TextNormalizer::firstNonEmpty($follow['date'] ?? '', $follow['date_creation'] ?? '', $follow['date_mod'] ?? '', $date);
                if (!DateHelper::within($fDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($follow, $agentId)) continue;
                $txt = TextNormalizer::clean($follow['content'] ?? '', $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $fDate,
                    'source_type' => 'ticket_followup',
                    'source_itemtype' => 'ITILFollowup',
                    'source_id' => (int)($follow['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Acompanhamento ' . (int)($follow['id'] ?? 0),
                    'title' => 'Acompanhamento do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Acompanhamento registrado no chamado.',
                    'result' => $this->resultFromStatus($status),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de acompanhamento do GLPI.'
                ]);
            }
        }

        if (in_array('ticket_solutions_by_user', $contexts, true)) {
            foreach ($this->safeSubitems('Ticket', $ticketId, 'ITILSolution') as $sol) {
                $sDate = TextNormalizer::firstNonEmpty($sol['date_approval'] ?? '', $sol['date_creation'] ?? '', $sol['date_mod'] ?? '', $item['solvedate'] ?? '', $date);
                if (!DateHelper::within($sDate, $start, $end)) continue;
                if ($agentId > 0 && !$this->subitemBelongsToUser($sol, $agentId)) {
                    // Some GLPI versions do not expose users_id on solution subitems; keep if solved in period.
                    if (isset($sol['users_id']) || isset($sol['users_id_tech'])) {
                        continue;
                    }
                }
                $txt = TextNormalizer::clean($sol['content'] ?? ($sol['solution'] ?? ''), $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $sDate,
                    'source_type' => 'ticket_solution',
                    'source_itemtype' => 'ITILSolution',
                    'source_id' => (int)($sol['id'] ?? 0),
                    'source_reference' => 'Chamado ' . $ticketId . ' / Solução ' . (int)($sol['id'] ?? 0),
                    'title' => 'Solução do chamado ' . $ticketId . ' - ' . $title,
                    'status' => $status,
                    'activity_performed' => $txt ?: 'Solução registrada no chamado.',
                    'result' => 'Solução registrada no GLPI.',
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de solução do GLPI.'
                ]);
            }
        }

        return $entries;
    }

    private function projectToEntries(int $projectId, array $project, int $agentId, array $groupIds, array $contexts, string $start, string $end): array
    {
        $item = $project['item'] ?? [];
        $row = $project['row'] ?? [];
        $title = TextNormalizer::firstNonEmpty($item['name'] ?? '', $this->rowVal($row, 1), 'Projeto ' . $projectId);
        $status = TextNormalizer::firstNonEmpty($item['projectstates_id'] ?? '', $item['status'] ?? '', $this->rowVal($row, 12));
        $date = TextNormalizer::firstNonEmpty($item['date_mod'] ?? '', $item['date_creation'] ?? '', $this->rowVal($row, 19), $start);
        $entries = [];

        $isMember = !in_array('projects_member_user', $contexts, true) || $this->projectHasUser($projectId, $agentId);
        if ($agentId > 0 && in_array('projects_member_user', $contexts, true) && !$isMember && empty($project['_sources']['projects_member_probe'])) {
            return [];
        }

        if (!empty($project['_sources']['projects_managed_by_user']) || !empty($project['_sources']['projects_managed_by_groups']) || ($isMember && in_array('projects_member_user', $contexts, true))) {
            $content = TextNormalizer::clean($item['content'] ?? ($item['comment'] ?? ''), $this->maskSensitive);
            $entries[] = $this->entry([
                'date' => $date,
                'source_type' => 'project',
                'source_itemtype' => 'Project',
                'source_id' => $projectId,
                'source_reference' => 'Projeto ' . $projectId,
                'title' => 'Projeto ' . $projectId . ' - ' . $title,
                'status' => $status,
                'category' => TextNormalizer::firstNonEmpty($item['projecttypes_id'] ?? '', $item['type'] ?? ''),
                'activity_performed' => TextNormalizer::summarize($content ?: 'Projeto localizado no GLPI dentro do contexto selecionado. Complementar a narrativa técnica, se necessário.', 1600),
                'result' => $this->projectResult($item),
                'next_steps' => '',
                'observations' => 'Origem: projeto vinculado ao contexto selecionado.'
            ]);
        }

        if ($this->hasAny($contexts, ['project_tasks_user','project_tasks_groups'])) {
            foreach ($this->safeSubitems('Project', $projectId, 'ProjectTask') as $task) {
                $taskDate = TextNormalizer::firstNonEmpty($task['real_start_date'] ?? '', $task['plan_start_date'] ?? '', $task['date_creation'] ?? '', $task['date_mod'] ?? '', $date);
                if (!DateHelper::within($taskDate, $start, $end)) continue;
                $belongs = false;
                if (in_array('project_tasks_user', $contexts, true) && ($agentId <= 0 || $this->subitemBelongsToUser($task, $agentId))) {
                    $belongs = true;
                }
                if (!$belongs && in_array('project_tasks_groups', $contexts, true) && $this->subitemBelongsToAnyGroup($task, $groupIds)) {
                    $belongs = true;
                }
                if (!$belongs && !isset($task['users_id']) && !isset($task['groups_id']) && !isset($task['users_id_tech']) && !isset($task['groups_id_tech'])) {
                    // Some APIs omit task team; include tasks from already selected project as fallback.
                    $belongs = true;
                }
                if (!$belongs) continue;

                $txt = TextNormalizer::clean(($task['content'] ?? '') ?: ($task['name'] ?? ''), $this->maskSensitive);
                $entries[] = $this->entry([
                    'date' => $taskDate,
                    'source_type' => 'project_task',
                    'source_itemtype' => 'ProjectTask',
                    'source_id' => (int)($task['id'] ?? 0),
                    'source_reference' => 'Projeto ' . $projectId . ' / Tarefa ' . (int)($task['id'] ?? 0),
                    'title' => 'Tarefa de projeto - ' . TextNormalizer::firstNonEmpty($task['name'] ?? '', $title),
                    'status' => TextNormalizer::firstNonEmpty($task['projecttaskstates_id'] ?? '', $status),
                    'activity_performed' => $txt ?: 'Tarefa de projeto registrada no GLPI.',
                    'result' => $this->projectTaskResult($task),
                    'next_steps' => '',
                    'observations' => 'Atividade extraída de tarefa de projeto.'
                ]);
            }
        }

        return $entries;
    }

    private function mergeSearchRows(array &$bucket, string $itemtype, array $criteria, array $display, string $source): void
    {
        $display = array_values(array_unique(array_filter($display)));
        try {
            $range = '0-' . max(0, $this->maxItems - 1);
            $res = $this->client->search($itemtype, $criteria, $display, $range, ['sort' => $display[0] ?? 2, 'order' => 'DESC']);
            $rows = is_array($res['data'] ?? null) ? $res['data'] : [];
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $id = $this->rowId($row);
                if ($id <= 0) continue;
                if (!isset($bucket[$id])) {
                    $bucket[$id] = ['row' => $row, '_sources' => []];
                }
                $bucket[$id]['_sources'][$source] = true;
            }
        } catch (\Throwable $e) {
            $this->warnings[] = 'Falha ao pesquisar ' . $itemtype . ' para o contexto ' . $source . ': ' . $e->getMessage();
        }
    }

    private function searchSubitemParents(string $itemtype, string $parentFieldLogical, int $agentId, string $start, string $end, string $requiredItemtype = ''): array
    {
        $fields = $this->resolver->fields($itemtype, [
            'id' => [2], 'date' => [15, 3], 'date_mod' => [19], 'users_id' => [5, 4], 'content' => [1], $parentFieldLogical => [7, 6, 13]
        ]);
        $parentField = (int)($fields[$parentFieldLogical] ?? 0);
        $dateField = $fields['date_mod'] ?: $fields['date'];
        $userField = $fields['users_id'];
        if ($parentField <= 0 || $dateField <= 0 || $userField <= 0) {
            return [];
        }

        $parents = [];
        try {
            $criteria = [
                $this->crit($userField, 'equals', $agentId),
                $this->crit($dateField, 'morethan', $start . ' 00:00:00', 'AND'),
                $this->crit($dateField, 'lessthan', $end . ' 23:59:59', 'AND')
            ];
            if ($requiredItemtype !== '') {
                $itField = $this->resolver->field($itemtype, 'itemtype', [4]);
                if ($itField > 0) {
                    $criteria[] = $this->crit($itField, 'equals', $requiredItemtype, 'AND');
                }
            }
            $res = $this->client->search($itemtype, $criteria, array_values(array_filter([$fields['id'], $parentField])), '0-' . ($this->maxItems - 1));
            foreach (($res['data'] ?? []) as $row) {
                if (!is_array($row)) continue;
                $pid = (int)$this->rowVal($row, $parentField);
                if ($pid > 0) {
                    $parents[$pid] = $pid;
                }
            }
        } catch (\Throwable $e) {
            // This is an optimization; do not spam users unless it is the only selected context.
        }
        return array_values($parents);
    }

    private function resolveUserGroups(int $userId): array
    {
        $ids = [];
        foreach (['Group_User', 'Group'] as $sub) {
            try {
                $rows = $this->client->getSubItems('User', $userId, $sub, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                if (!is_array($rows)) continue;
                foreach ($rows as $row) {
                    if (!is_array($row)) continue;
                    foreach (['groups_id', 'id'] as $k) {
                        if (isset($row[$k]) && is_numeric($row[$k])) {
                            $ids[(int)$row[$k]] = true;
                        }
                    }
                }
                if (!empty($ids)) break;
            } catch (\Throwable $e) {
                // Try next route.
            }
        }
        return array_keys($ids);
    }

    private function resolveGroups(array $groupIds): array
    {
        $out = [];
        foreach ($groupIds as $gid) {
            $gid = (int)$gid;
            if ($gid <= 0) continue;
            $name = 'Grupo ID ' . $gid;
            try {
                $item = $this->client->getItem('Group', $gid, ['expand_dropdowns' => true, 'get_hateoas' => false]);
                $name = TextNormalizer::firstNonEmpty($item['name'] ?? '', $name);
            } catch (\Throwable $e) {
                // keep fallback
            }
            $out[$gid] = ['id' => $gid, 'name' => $name];
        }
        return $out;
    }

    private function safeSubitems(string $itemtype, int $id, string $subitemtype): array
    {
        try {
            $rows = $this->client->getSubItems($itemtype, $id, $subitemtype, ['expand_dropdowns' => true, 'get_hateoas' => false, 'range' => '0-' . ($this->maxItems - 1)]);
            return is_array($rows) ? $rows : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function projectHasUser(int $projectId, int $agentId): bool
    {
        if ($agentId <= 0) return true;
        foreach (['ProjectTeam', 'Project_User', 'ProjectTaskTeam'] as $sub) {
            foreach ($this->safeSubitems('Project', $projectId, $sub) as $row) {
                if ($this->subitemBelongsToUser($row, $agentId)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function subitemBelongsToUser(array $row, int $userId): bool
    {
        if ($userId <= 0) return true;
        foreach (['users_id', 'users_id_tech', 'users_id_editor', 'users_id_recipient', 'users_id_validate', 'users_id_approval'] as $k) {
            if (isset($row[$k]) && (int)$row[$k] === $userId) {
                return true;
            }
        }
        if (isset($row['items_id']) && isset($row['itemtype']) && strtolower((string)$row['itemtype']) === 'user' && (int)$row['items_id'] === $userId) {
            return true;
        }
        return false;
    }

    private function subitemBelongsToAnyGroup(array $row, array $groupIds): bool
    {
        if (empty($groupIds)) return false;
        $map = array_flip(array_map('intval', $groupIds));
        foreach (['groups_id', 'groups_id_tech', 'groups_id_assign', 'groups_id_recipient'] as $k) {
            if (isset($row[$k]) && isset($map[(int)$row[$k]])) {
                return true;
            }
        }
        if (isset($row['items_id']) && isset($row['itemtype']) && strtolower((string)$row['itemtype']) === 'group' && isset($map[(int)$row['items_id']])) {
            return true;
        }
        return false;
    }

    private function addEntry(array &$entries, array &$seen, array $entry): void
    {
        if (count($entries) >= $this->maxItems) return;
        $key = implode('|', [
            $entry['source_type'] ?? '',
            $entry['source_itemtype'] ?? '',
            $entry['source_id'] ?? '',
            $entry['date'] ?? '',
            md5((string)($entry['title'] ?? '') . '|' . (string)($entry['activity_performed'] ?? ''))
        ]);
        if (isset($seen[$key])) {
            return;
        }
        $seen[$key] = true;
        $entries[] = $entry;
    }

    private function entry(array $data): array
    {
        $date = TextNormalizer::firstNonEmpty($data['date'] ?? '', date('Y-m-d'));
        $date = DateHelper::normalizeDate($date, date('Y-m-d'));
        return [
            'date' => $date,
            'source_type' => (string)($data['source_type'] ?? 'manual'),
            'source_itemtype' => (string)($data['source_itemtype'] ?? ''),
            'source_id' => (int)($data['source_id'] ?? 0),
            'source_reference' => TextNormalizer::clean($data['source_reference'] ?? '', $this->maskSensitive),
            'professional' => '',
            'title' => TextNormalizer::clean($data['title'] ?? 'Atividade', $this->maskSensitive),
            'status' => TextNormalizer::clean($data['status'] ?? '', $this->maskSensitive),
            'category' => TextNormalizer::clean($data['category'] ?? '', $this->maskSensitive),
            'activity_performed' => TextNormalizer::clean($data['activity_performed'] ?? '', $this->maskSensitive),
            'result' => TextNormalizer::clean($data['result'] ?? '', $this->maskSensitive),
            'next_steps' => TextNormalizer::clean($data['next_steps'] ?? '', $this->maskSensitive),
            'observations' => TextNormalizer::clean($data['observations'] ?? '', $this->maskSensitive),
            'include_in_report' => true
        ];
    }

    private function calculateMetrics(array $entries): array
    {
        $total = count($entries);
        $tickets = 0; $projects = 0; $tasks = 0; $closed = 0;
        foreach ($entries as $e) {
            $stype = (string)($e['source_type'] ?? '');
            if (strpos($stype, 'ticket') === 0) $tickets++;
            if (strpos($stype, 'project') === 0) $projects++;
            if (strpos($stype, 'task') !== false) $tasks++;
            $status = mb_strtolower((string)($e['status'] ?? ''), 'UTF-8');
            if (preg_match('/fech|soluc|conclu|closed|solved|done/', $status)) $closed++;
        }
        $rate = $total > 0 ? round(($closed / $total) * 100, 1) : 0;
        return [
            ['key' => 'entries', 'label' => 'Entradas do relatório', 'value' => $total],
            ['key' => 'tickets', 'label' => 'Entradas de chamados', 'value' => $tickets],
            ['key' => 'projects', 'label' => 'Entradas de projetos', 'value' => $projects],
            ['key' => 'closed_rate', 'label' => 'Taxa de encerramento/conclusão', 'value' => $rate . '%']
        ];
    }

    private function groupByDay(array $entries): array
    {
        $groups = [];
        foreach ($entries as $entry) {
            if (empty($entry['include_in_report'])) continue;
            $date = (string)($entry['date'] ?? '');
            if ($date === '') $date = date('Y-m-d');
            if (!isset($groups[$date])) {
                $groups[$date] = ['date' => $date, 'display_date' => DateHelper::displayDate($date), 'entries' => []];
            }
            $groups[$date]['entries'][] = $entry;
        }
        ksort($groups);
        return array_values($groups);
    }

    private function validateDraft(array $entries, array $contexts, string $start, string $end): array
    {
        $out = [];
        if (empty($entries)) {
            $out[] = ['level' => 'warning', 'message' => 'Nenhuma atividade foi retornada pela API para o período e contextos selecionados. Verifique credenciais, campos de pesquisa e escopo do agente.'];
        }
        if (count($entries) > 80) {
            $out[] = ['level' => 'warning', 'message' => 'O rascunho possui mais de 80 entradas. Considere usar o relatório gerencial resumido e anexar evidência completa separadamente.'];
        }
        foreach ($entries as $idx => $entry) {
            if (!DateHelper::within((string)($entry['date'] ?? ''), $start, $end)) {
                $out[] = ['level' => 'warning', 'message' => 'Entrada fora do período selecionado: ' . (($entry['title'] ?? 'Atividade') ?: 'Atividade')];
                break;
            }
            if (trim((string)($entry['activity_performed'] ?? '')) === '') {
                $out[] = ['level' => 'warning', 'message' => 'Há entradas sem descrição de atividade realizada. Complete a narrativa antes do DOCX final.'];
                break;
            }
        }
        if (in_array('manual_entries', $contexts, true)) {
            $out[] = ['level' => 'info', 'message' => 'Contexto manual habilitado. Use o editor para adicionar atividades que não estejam bem representadas em tickets ou projetos.'];
        }
        return $out;
    }

    private function defaultExecutiveSummary(array $entries, string $agentName, string $start, string $end): string
    {
        $total = count($entries);
        return 'No período de ' . DateHelper::displayDate($start) . ' a ' . DateHelper::displayDate($end) . ', foram consolidadas ' . $total . ' entradas de atividade relacionadas a ' . $agentName . '. O rascunho combina registros extraídos da API do GLPI com espaço para complementações narrativas, permitindo revisão técnica antes da exportação em DOCX.';
    }

    private function resultFromStatus(string $status): string
    {
        $s = mb_strtolower($status, 'UTF-8');
        if (preg_match('/fech|soluc|conclu|closed|solved|done/', $s)) {
            return 'Atividade registrada como concluída/solucionada no GLPI.';
        }
        if (preg_match('/pend|andamento|novo|process/', $s)) {
            return 'Atividade em acompanhamento, com continuidade conforme tratamento registrado.';
        }
        return '';
    }

    private function projectResult(array $item): string
    {
        $pct = TextNormalizer::firstNonEmpty($item['percent_done'] ?? '', $item['percent'] ?? '');
        if ($pct !== '') return 'Percentual de evolução registrado: ' . $pct . '.';
        return '';
    }

    private function projectTaskResult(array $task): string
    {
        $pct = TextNormalizer::firstNonEmpty($task['percent_done'] ?? '', $task['percent'] ?? '');
        if ($pct !== '') return 'Percentual de execução da tarefa: ' . $pct . '.';
        return '';
    }

    private function requiresAgent(array $contexts): bool
    {
        foreach ($contexts as $ctx) {
            if (strpos($ctx, '_user') !== false || strpos($ctx, '_by_user') !== false || strpos($ctx, '_member_user') !== false) {
                return true;
            }
        }
        return false;
    }

    private function hasAny(array $contexts, array $needles): bool
    {
        foreach ($needles as $n) {
            if (in_array($n, $contexts, true)) return true;
        }
        return false;
    }

    private function crit(int $field, string $searchtype, $value, string $link = ''): array
    {
        $c = ['field' => $field, 'searchtype' => $searchtype, 'value' => (string)$value];
        if ($link !== '') $c['link'] = $link;
        return $c;
    }

    private function rowId(array $row): int
    {
        foreach (['2', 2, 'id', 'ID'] as $k) {
            if (isset($row[$k]) && is_numeric($row[$k])) return (int)$row[$k];
        }
        foreach ($row as $v) {
            if (is_numeric($v) && (int)$v > 0) return (int)$v;
        }
        return 0;
    }

    private function rowVal(array $row, int $field)
    {
        if ($field <= 0) return '';
        foreach ([(string)$field, $field] as $k) {
            if (array_key_exists($k, $row)) return $row[$k];
        }
        return '';
    }

    private function parseIdList($raw): array
    {
        if (is_array($raw)) {
            $ids = [];
            foreach ($raw as $v) {
                $id = (int)$v;
                if ($id > 0) $ids[$id] = $id;
            }
            return array_values($ids);
        }
        $ids = [];
        foreach (preg_split('/[^0-9]+/', (string)$raw) as $p) {
            $id = (int)$p;
            if ($id > 0) $ids[$id] = $id;
        }
        return array_values($ids);
    }
}
