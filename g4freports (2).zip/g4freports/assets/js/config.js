(function () {
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]; }); }
  function postJson(path, payload) {
    return fetch(window.G4FREPORTS.root + path, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(payload || {}) })
      .then(function (res) { return res.text().then(function (txt) { var data; try { data = JSON.parse(txt); } catch (e) { data = { ok: false, error: txt || ('HTTP ' + res.status) }; } if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status)); return data; }); });
  }
  document.addEventListener('DOMContentLoaded', function () {
    var btn = $('g4fr-test-config');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var area = document.querySelector('textarea[name="api_profiles_json"]');
      var out = $('g4fr-test-config-result');
      out.textContent = 'Testando...';
      postJson('/ajax/test_profiles.php', { api_profiles_json: area.value }).then(function (data) {
        out.innerHTML = (data.results || []).map(function (r) { return '<span class="badge ' + (r.ok ? 'bg-success' : 'bg-danger') + '">' + esc(r.id || r.name || 'perfil') + ': ' + (r.ok ? 'OK' : esc(r.error)) + '</span>'; }).join(' ');
      }).catch(function (err) { out.innerHTML = '<span class="badge bg-danger">' + esc(err.message) + '</span>'; });
    });
  });
})();
