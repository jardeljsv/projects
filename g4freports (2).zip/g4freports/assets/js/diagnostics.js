(function () {
  function $(id) { return document.getElementById(id); }
  function postJson(path, payload) {
    return fetch(window.G4FREPORTS.root + path, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(payload || {}) })
      .then(function (res) { return res.text().then(function (txt) { var data; try { data = JSON.parse(txt); } catch (e) { data = { ok: false, error: txt || ('HTTP ' + res.status) }; } if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status)); return data; }); });
  }
  function print(x) { $('g4fr-diag-output').textContent = typeof x === 'string' ? x : JSON.stringify(x, null, 2); }
  document.addEventListener('DOMContentLoaded', function () {
    $('g4fr-diag-test').addEventListener('click', function () {
      print('Testando conexão...');
      postJson('/ajax/test_connection.php', { profile_id: $('g4fr-diag-profile').value }).then(print).catch(function (e) { print(e.message); });
    });
    $('g4fr-diag-options').addEventListener('click', function () {
      print('Listando Search Options...');
      postJson('/ajax/search_options.php', { profile_id: $('g4fr-diag-profile').value, itemtype: $('g4fr-diag-itemtype').value || 'Ticket' }).then(print).catch(function (e) { print(e.message); });
    });
  });
})();
