# Relatórios G4F para GLPI

Versão MVP 0.1.2: build alinhado ao padrão de endurecimento do GLPIBot, com configuração mais simples, sem tela baseada em JSON aberto e sem dependências externas de runtime.

## Objetivo

O plugin gera rascunhos de relatório a partir da API REST do GLPI, permitindo selecionar múltiplos contextos ao mesmo tempo:

- chamados atribuídos ao agente;
- chamados solicitados pelo agente;
- chamados atribuídos aos grupos do agente;
- tarefas de chamados feitas pelo agente;
- acompanhamentos feitos pelo agente;
- soluções registradas pelo agente;
- projetos gerenciados pelo agente;
- projetos gerenciados por grupos do agente;
- projetos em que o agente participa;
- tarefas de projeto do agente;
- tarefas de projeto dos grupos do agente;
- entradas narrativas manuais.

O agente principal é a âncora do relatório, não o único filtro possível.

## Instalação

```bash
cd /var/www/html/glpi/plugins
rm -rf g4freports
unzip /caminho/g4freports_mvp_api_docx_v0.1.2_ui_glpibot_style.zip
chown -R www-data:www-data /var/www/html/glpi/plugins/g4freports
```

O plugin não precisa de bibliotecas externas para executar. O `composer.json` existe apenas para compatibilidade com o fluxo que vocês já usam no GLPIBot. Se quiser manter o mesmo procedimento operacional, este comando é seguro:

```bash
apt-get update && apt-get install -y composer
cd /var/www/html/glpi/plugins/g4freports
composer install --no-dev --optimize-autoloader
chown -R www-data:www-data /var/www/html/glpi/plugins/g4freports
```

A pasta `vendor/autoload.php` do ZIP é intencionalmente vazia, como no GLPIBot. O plugin também possui um loader interno por `require_once`, então ele não depende do Composer para funcionar.

Depois, ative em:

```text
Configurar > Plugins > Relatórios G4F > Instalar > Habilitar
```

## Configuração

A configuração principal fica em:

```text
Configurar > Geral > Relatórios G4F
```

Também há link pelo menu:

```text
Ferramentas > Relatórios G4F > Configurações
```

A interface segue o padrão do GLPIBot:

- perfil API padrão com campos normais;
- busca/multiselect de grupos autorizados;
- busca/multiselect de perfis autorizados;
- tabela para perfis adicionais de API;
- tabela para roteamento por grupo;
- opções avançadas recolhidas em bloco expansível.

## Uso

```text
Ferramentas > Relatórios G4F > Gerar relatório
```

Fluxo recomendado:

1. selecionar conexão GLPI;
2. selecionar período;
3. buscar/selecionar agente principal;
4. escolher modelo;
5. marcar todos os contextos necessários;
6. gerar rascunho;
7. revisar entradas e adicionar narrativa manual;
8. exportar DOCX.

## Diagnóstico

Use:

```text
Ferramentas > Relatórios G4F > Diagnóstico
```

para testar conexão e listar Search Options por itemtype.

## Dependências

Obrigatório:

- GLPI 10+;
- PHP com acesso HTTP via cURL ou `allow_url_fopen`;
- API REST do GLPI habilitada;
- token/usuário de API com permissão de leitura para os dados desejados.

Não obrigatório:

- PHPWord;
- ZipArchive;
- pacotes Composer;
- CDN externo;
- tabela própria de negócio.

## Segurança

- Chamadas à API são server-side pelo PHP do plugin.
- Tokens não são usados diretamente no JavaScript do gerador de relatório.
- O exportador mascara CPF, e-mail e telefone por padrão.
- Use usuário de API de menor privilégio possível.
- Para produção, prefira variáveis de ambiente ou controle de acesso do servidor para segredos.
