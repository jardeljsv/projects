<?php

require_once __DIR__ . '/loader.php';

class PluginG4freportsConfig extends \GlpiPlugin\G4freports\Config
{
}
