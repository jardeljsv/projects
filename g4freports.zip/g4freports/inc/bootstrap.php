<?php
// Robust GLPI bootstrap used by all interactive plugin pages/endpoints.

require_once __DIR__ . '/common.php';

$autoload = dirname(__DIR__) . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

$g4fr_glpi_root = null;
if (!g4fr_bootstrap_glpi_runtime($g4fr_glpi_root)) {
    if (!headers_sent()) {
        header('Content-Type: text/plain; charset=UTF-8');
    }
    http_response_code(500);
    echo 'Relatórios G4F: não foi possível inicializar o GLPI. Verifique GLPI_ROOT ou a localização do plugin.';
    exit;
}

// Load plugin classes only after GLPI core classes are available. This mirrors
// the GLPIBot runtime pattern and avoids fatal errors in direct front/* calls.
if (is_file($autoload)) {
    require_once $autoload;
}
require_once __DIR__ . '/loader.php';

$menuClass = dirname(__DIR__) . '/inc/menu.class.php';
if (is_file($menuClass)) {
    require_once $menuClass;
}
$configClass = dirname(__DIR__) . '/inc/config.class.php';
if (is_file($configClass)) {
    require_once $configClass;
}
