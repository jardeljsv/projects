<?php

require_once __DIR__ . '/loader.php';

class PluginG4freportsMenu extends \GlpiPlugin\G4freports\Menu
{
}
