<?php
// Explicit class loader for Relatórios G4F.
// This keeps the plugin independent from Composer at runtime. If the team runs
// composer install, Composer's autoloader may also exist, but this file remains
// the safe GLPI-compatible fallback.

if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

$g4freports_files = [
    'src/Config.php',
    'src/Security.php',
    'src/Menu.php',
    'src/Util/DateHelper.php',
    'src/Util/TextNormalizer.php',
    'src/Util/Http.php',
    'src/Api/GlpiApiException.php',
    'src/Api/GlpiApiClient.php',
    'src/Api/SearchOptionResolver.php',
    'src/Builder/ReportDraftBuilder.php',
    'src/Export/DocxExporter.php',
];

foreach ($g4freports_files as $g4freports_file) {
    $g4freports_path = dirname(__DIR__) . '/' . $g4freports_file;
    if (is_file($g4freports_path)) {
        require_once $g4freports_path;
    }
}
