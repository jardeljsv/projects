(function () {
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]; }); }
  var apiUrl = (window.G4FREPORTS && window.G4FREPORTS.api_url) || 'api.php';
  function callApi(action, payload) {
    var url = new URL(apiUrl, window.location.href);
    url.searchParams.set('action', action);
    url.searchParams.set('payload', JSON.stringify(payload || {}));
    url.searchParams.set('_', String(Date.now()));
    return fetch(url.toString(), { method: 'GET', credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (res) { return res.text().then(function (txt) { var data; try { data = JSON.parse(txt); } catch (e) { data = { ok: false, error: txt || ('HTTP ' + res.status) }; } if (!res.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + res.status)); return data; }); });
  }
  document.addEventListener('DOMContentLoaded', function () {
    var btn = $('g4fr-test-config');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var out = $('g4fr-test-config-result');
      out.textContent = 'Testando perfis salvos...';
      callApi('test_profiles', {}).then(function (data) {
        out.innerHTML = (data.results || []).map(function (r) { return '<span class="badge ' + (r.ok ? 'bg-success' : 'bg-danger') + '">' + esc(r.id || r.name || 'perfil') + ': ' + (r.ok ? 'OK' : esc(r.error)) + '</span>'; }).join(' ');
      }).catch(function (err) { out.innerHTML = '<span class="badge bg-danger">' + esc(err.message) + '</span>'; });
    });
  });
})();
