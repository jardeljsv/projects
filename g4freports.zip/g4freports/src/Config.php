<?php

namespace GlpiPlugin\G4freports;

use CommonGLPI;
use Session;
use Glpi\Application\View\TemplateRenderer;

class Config extends \Config
{
    public static function getTypeName($nb = 0)
    {
        return __('Relatórios G4F', 'g4freports');
    }

    public static function getConfig(): array
    {
        $cfg = \Config::getConfigurationValues('plugin:g4freports');
        return is_array($cfg) ? $cfg : [];
    }

    public static function getDefaultConfig(): array
    {
        return [
            'enabled'                => 1,
            'default_profile_name'   => 'Default API',
            'api_base_url'           => '',
            'app_token'              => '',
            'user_token'             => '',
            'session_token'          => '',
            'verify_tls'             => 1,
            'default_entity_id'      => 0,
            'recursive_entities'     => 1,
            'request_timeout_ms'     => 60000,
            'allowed_groups'         => '',
            'allowed_profiles'       => '',
            'api_profiles_json'      => '',
            'group_routes_json'      => '',
            'default_profile_id'     => '__default__',
            'max_items'              => 200,
            'mask_sensitive_data'    => 1,
            'field_overrides_json'   => '{}',
            'default_footer'         => 'Brasília - DF, 70712-900 | SCN Q 2 BL A - Asa Norte, Corporate Financial Center | contato@g4f.com.br | www.g4f.com.br',
            'contract_label'         => 'SES-DF',
            'default_report_title'   => 'Relatório Gerencial de Atividades',
            'default_scope_text'     => 'Este relatório apresenta as atividades executadas no período selecionado, consolidando registros obtidos via GLPI e complementações narrativas inseridas pelo profissional responsável.',
            'default_objective_text' => 'Formalizar, padronizar e evidenciar as ações técnicas executadas, mantendo rastreabilidade por chamados, projetos, tarefas, acompanhamentos e registros manuais.'
        ];
    }

    public static function merged(): array
    {
        return array_replace(self::getDefaultConfig(), self::getConfig());
    }

    public static function save(array $values): void
    {
        \Config::setConfigurationValues('plugin:g4freports', $values);
    }

    public static function defaultProfileFromConfig(array $cfg): array
    {
        $timeout = self::intValue($cfg['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
        return [
            'id'                 => '__default__',
            'name'               => self::stringValue($cfg['default_profile_name'] ?? '', 'Default API'),
            'base_url'           => self::stringValue($cfg['api_base_url'] ?? '', ''),
            'app_token'          => self::stringValue($cfg['app_token'] ?? '', ''),
            'user_token'         => self::stringValue($cfg['user_token'] ?? '', ''),
            'session_token'      => self::stringValue($cfg['session_token'] ?? '', ''),
            'verify_tls'         => self::boolValue($cfg['verify_tls'] ?? true, true),
            'timeout_ms'         => $timeout,
            'default_entity_id'  => self::intValue($cfg['default_entity_id'] ?? 0, 0, 0, PHP_INT_MAX),
            'recursive_entities' => self::boolValue($cfg['recursive_entities'] ?? true, true),
            'enabled'            => true,
            'is_default'         => true,
        ];
    }

    public static function profiles(array $cfg = null, bool $includeDisabled = false): array
    {
        $cfg = $cfg ?? self::merged();
        $out = ['__default__' => self::defaultProfileFromConfig($cfg)];

        $raw = (string)($cfg['api_profiles_json'] ?? '');
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        foreach ($decoded as $profile) {
            if (!is_array($profile)) {
                continue;
            }

            $id = self::stringValue($profile['id'] ?? '', '');
            if ($id === '' || $id === '__default__') {
                $id = 'profile_' . (count($out) + 1);
            }

            $p = [
                'id'                 => $id,
                'name'               => self::stringValue($profile['name'] ?? '', $id),
                'base_url'           => self::stringValue($profile['base_url'] ?? ($profile['api_base_url'] ?? ''), ''),
                'app_token'          => self::stringValue($profile['app_token'] ?? '', ''),
                'user_token'         => self::stringValue($profile['user_token'] ?? '', ''),
                'session_token'      => self::stringValue($profile['session_token'] ?? '', ''),
                'app_token_env'      => self::stringValue($profile['app_token_env'] ?? '', ''),
                'user_token_env'     => self::stringValue($profile['user_token_env'] ?? '', ''),
                'session_token_env'  => self::stringValue($profile['session_token_env'] ?? '', ''),
                'verify_tls'         => self::boolValue($profile['verify_tls'] ?? true, true),
                'timeout_ms'         => self::intValue($profile['timeout_ms'] ?? ($profile['request_timeout_ms'] ?? 60000), 60000, 1000, 600000),
                'default_entity_id'  => self::intValue($profile['default_entity_id'] ?? 0, 0, 0, PHP_INT_MAX),
                'recursive_entities' => self::boolValue($profile['recursive_entities'] ?? true, true),
                'enabled'            => self::boolValue($profile['enabled'] ?? true, true),
                'is_default'         => false,
            ];

            if ($includeDisabled || !empty($p['enabled'])) {
                $out[$id] = $p;
            }
        }

        return $out;
    }

    public static function getProfile(string $id, array $cfg = null): ?array
    {
        $cfg = $cfg ?? self::merged();
        $profiles = self::profiles($cfg);
        if ($id !== '' && isset($profiles[$id])) {
            return $profiles[$id];
        }
        $defaultId = self::stringValue($cfg['default_profile_id'] ?? '__default__', '__default__');
        if (isset($profiles[$defaultId])) {
            return $profiles[$defaultId];
        }
        return $profiles['__default__'] ?? (empty($profiles) ? null : reset($profiles));
    }

    public static function parseRoutes($raw): array
    {
        $raw = is_string($raw) ? trim($raw) : '';
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }
        $out = [];
        foreach ($decoded as $row) {
            if (!is_array($row)) {
                continue;
            }
            $groupId = self::intValue($row['group_id'] ?? ($row['groups_id'] ?? 0), 0, 0, PHP_INT_MAX);
            if ($groupId <= 0) {
                continue;
            }
            $out[] = [
                'id' => self::stringValue($row['id'] ?? '', 'route_' . $groupId . '_' . count($out)),
                'group_id' => $groupId,
                'profile_id' => self::stringValue($row['profile_id'] ?? '__default__', '__default__'),
                'priority' => self::intValue($row['priority'] ?? 100, 100, 0, 999999),
                'include_children' => self::boolValue($row['include_children'] ?? true, true),
                'enabled' => self::boolValue($row['enabled'] ?? true, true),
            ];
        }
        return $out;
    }

    private static function fetchGroupsList(): array
    {
        $groups = [];
        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            return $groups;
        }

        try {
            if (method_exists($DB, 'request')) {
                $it = $DB->request([
                    'SELECT' => ['id', 'name'],
                    'FROM'   => 'glpi_groups',
                    'ORDER'  => ['name'],
                ]);
                foreach ($it as $row) {
                    if (!is_array($row)) continue;
                    $id = isset($row['id']) ? (int)$row['id'] : 0;
                    $name = isset($row['name']) ? (string)$row['name'] : '';
                    if ($id > 0) {
                        $groups[] = ['id' => $id, 'name' => $name];
                    }
                }
                return $groups;
            }
        } catch (\Throwable $e) {
            // fall back below
        }

        try {
            if (method_exists($DB, 'query')) {
                $res = @$DB->query('SELECT `id`, `name` FROM `glpi_groups` ORDER BY `name` ASC');
                if ($res) {
                    if (method_exists($DB, 'fetchAssoc')) {
                        while ($row = $DB->fetchAssoc($res)) {
                            $id = isset($row['id']) ? (int)$row['id'] : 0;
                            $name = isset($row['name']) ? (string)$row['name'] : '';
                            if ($id > 0) {
                                $groups[] = ['id' => $id, 'name' => $name];
                            }
                        }
                    } elseif (method_exists($DB, 'fetch_assoc')) {
                        while ($row = $DB->fetch_assoc($res)) {
                            $id = isset($row['id']) ? (int)$row['id'] : 0;
                            $name = isset($row['name']) ? (string)$row['name'] : '';
                            if ($id > 0) {
                                $groups[] = ['id' => $id, 'name' => $name];
                            }
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return $groups;
    }

    private static function fetchProfilesList(): array
    {
        $profiles = [];
        global $DB;
        if (!isset($DB) || !is_object($DB)) {
            return $profiles;
        }

        try {
            if (method_exists($DB, 'request')) {
                $it = $DB->request([
                    'SELECT' => ['id', 'name'],
                    'FROM' => 'glpi_profiles',
                    'ORDER' => ['name'],
                ]);
                foreach ($it as $row) {
                    if (!is_array($row)) continue;
                    $id = (int)($row['id'] ?? 0);
                    $name = (string)($row['name'] ?? '');
                    if ($id > 0) $profiles[] = ['id' => $id, 'name' => $name];
                }
                return $profiles;
            }
        } catch (\Throwable $e) {
            // fall back
        }

        try {
            if (method_exists($DB, 'query')) {
                $res = @$DB->query('SELECT `id`, `name` FROM `glpi_profiles` ORDER BY `name` ASC');
                if ($res && method_exists($DB, 'fetchAssoc')) {
                    while ($row = $DB->fetchAssoc($res)) {
                        $id = (int)($row['id'] ?? 0);
                        $name = (string)($row['name'] ?? '');
                        if ($id > 0) $profiles[] = ['id' => $id, 'name' => $name];
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return $profiles;
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case \Config::class:
                return self::createTabEntry(self::getTypeName());
        }
        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case \Config::class:
                return self::showForConfig($item, $withtemplate);
        }
        return true;
    }

    public static function showForConfig(\Config $config, $withtemplate = 0)
    {
        if (!self::canView()) {
            return false;
        }

        $current_config = self::merged();
        $canedit = Session::haveRight(self::$rightname, UPDATE);

        TemplateRenderer::getInstance()->display('@g4freports/config.html.twig', [
            'current_config' => $current_config,
            'can_edit'       => $canedit,
            'groups'         => self::fetchGroupsList(),
            'profiles'       => self::fetchProfilesList(),
            'plugin_key'     => 'g4freports',
            'root_doc'       => $GLOBALS['CFG_GLPI']['root_doc'] ?? ''
        ]);

        return true;
    }

    private static function stringValue($v, string $default = ''): string
    {
        if ($v === null) return $default;
        if (is_string($v)) return trim($v);
        if (is_scalar($v)) return trim((string)$v);
        return $default;
    }

    private static function boolValue($v, bool $default = false): bool
    {
        if (is_bool($v)) return $v;
        if (is_numeric($v)) return ((int)$v) !== 0;
        if (is_string($v)) {
            $s = strtolower(trim($v));
            if ($s === '') return $default;
            if (in_array($s, ['1','true','yes','y','on','sim'], true)) return true;
            if (in_array($s, ['0','false','no','n','off','nao','não'], true)) return false;
        }
        return $default;
    }

    private static function intValue($v, int $default = 0, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): int
    {
        if (!is_numeric($v)) return $default;
        $n = (int)$v;
        if ($n < $min) $n = $min;
        if ($n > $max) $n = $max;
        return $n;
    }
}
