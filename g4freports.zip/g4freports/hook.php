<?php

function plugin_g4freports_install(): bool
{
    \Config::setConfigurationValues('plugin:g4freports', [
        'enabled'                => 1,

        // Default API profile, shown as normal fields in the GLPI configuration tab.
        'default_profile_name'   => 'Default API',
        'api_base_url'           => '',
        'app_token'              => '',
        'user_token'             => '',
        'session_token'          => '',
        'verify_tls'             => 1,
        'default_entity_id'      => 0,
        'recursive_entities'     => 1,
        'request_timeout_ms'     => 60000,

        // Access control and optional routing, following the GLPIBot configuration style.
        'allowed_groups'         => '',
        'allowed_profiles'       => '',
        'api_profiles_json'      => '',
        'group_routes_json'      => '',
        'default_profile_id'     => '__default__',

        // Extraction/report behavior.
        'max_items'              => 200,
        'mask_sensitive_data'    => 1,
        'field_overrides_json'   => '{}',
        'default_footer'         => 'Brasília - DF, 70712-900 | SCN Q 2 BL A - Asa Norte, Corporate Financial Center | contato@g4f.com.br | www.g4f.com.br',
        'contract_label'         => 'SES-DF',
        'default_report_title'   => 'Relatório Gerencial de Atividades',
        'default_scope_text'     => 'Este relatório apresenta as atividades executadas no período selecionado, consolidando registros obtidos via GLPI e complementações narrativas inseridas pelo profissional responsável.',
        'default_objective_text' => 'Formalizar, padronizar e evidenciar as ações técnicas executadas, mantendo rastreabilidade por chamados, projetos, tarefas, acompanhamentos e registros manuais.'
    ]);

    return true;
}

function plugin_g4freports_uninstall(): bool
{
    $cfg = new \Config();
    $cfg->deleteByCriteria(['context' => 'plugin:g4freports']);
    return true;
}
