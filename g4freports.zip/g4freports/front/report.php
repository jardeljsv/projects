<?php

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;

if (class_exists('Session')) {
    Session::checkLoginUser();
}

$cfg = Config::merged();
if (!Security::canUse($cfg)) {
    if (class_exists('Html')) {
        Html::displayRightError();
    }
    http_response_code(403);
    exit;
}

$profiles = Config::profiles($cfg);
$defaultProfile = (string)($cfg['default_profile_id'] ?? '__default__');

if (class_exists('Html')) {
    Html::header(__('Relatórios G4F', 'g4freports'), $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu');
}
?>
<link rel="stylesheet" href="asset.php?name=g4freports.css&v=<?php echo rawurlencode(PLUGIN_G4FREPORTS_VERSION); ?>">
<div class="g4fr-wrap">
  <div class="g4fr-header">
    <div>
      <h1>Relatórios G4F</h1>
      <p>Gere um rascunho DOCX a partir da API do GLPI, revise as narrativas e exporte o relatório final.</p>
    </div>
    <div class="g4fr-header-actions">
      <a class="btn btn-outline-secondary" href="diagnostics.php">Diagnóstico</a>
      <?php if (Security::canConfigure()): ?>
      <a class="btn btn-outline-primary" href="config.php">Configurações</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="g4fr-card">
    <h2>Dados principais</h2>
    <form id="g4fr-form" class="g4fr-grid g4fr-grid-compact">
      <div class="g4fr-field">
        <label>Conexão GLPI</label>
        <select name="profile_id" id="g4fr-profile" class="form-select">
          <?php foreach ($profiles as $id => $profile): ?>
            <option value="<?php echo htmlspecialchars($id); ?>" <?php echo $id === $defaultProfile ? 'selected' : ''; ?>><?php echo htmlspecialchars((string)($profile['name'] ?? $id)); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="g4fr-field">
        <label>Período</label>
        <div class="input-group">
          <input type="date" name="period_start" id="g4fr-start" class="form-control" value="<?php echo date('Y-m-01'); ?>">
          <input type="date" name="period_end" id="g4fr-end" class="form-control" value="<?php echo date('Y-m-t'); ?>">
        </div>
      </div>

      <div class="g4fr-field">
        <label>Modelo</label>
        <select name="template" id="g4fr-template" class="form-select">
          <option value="operational">Operacional diário/mensal</option>
          <option value="formal_managerial">Gerencial formal</option>
          <option value="project_technical">Técnico/projeto</option>
          <option value="annex_full">Anexo evidencial completo</option>
        </select>
      </div>

      <div class="g4fr-field g4fr-field-inline">
        <label>Agente principal</label>
        <div class="input-group">
          <input type="number" name="agent_id" id="g4fr-agent-id" class="form-control" placeholder="ID" min="1">
          <input type="text" name="agent_name" id="g4fr-agent-name" class="form-control" placeholder="Nome/login">
        </div>
      </div>

      <div class="g4fr-field g4fr-field-inline">
        <label>Buscar agente na API</label>
        <div class="input-group">
          <input type="text" id="g4fr-agent-search-q" class="form-control" placeholder="Digite nome ou login">
          <button type="button" id="g4fr-agent-search-btn" class="btn btn-outline-secondary">Buscar</button>
        </div>
        <div id="g4fr-agent-results" class="g4fr-search-results"></div>
      </div>

      <div class="g4fr-field g4fr-full">
        <label>Título</label>
        <input type="text" name="report_title" id="g4fr-title" class="form-control" value="<?php echo htmlspecialchars((string)($cfg['default_report_title'] ?? 'Relatório Gerencial de Atividades')); ?>">
      </div>

      <details class="g4fr-full g4fr-details">
        <summary>Opções narrativas e escopo manual</summary>
        <div class="g4fr-grid mt-3">
          <div class="g4fr-field">
            <label>IDs de grupos adicionais</label>
            <input type="text" name="group_ids" id="g4fr-group-ids" class="form-control" placeholder="Ex.: 59, 24">
            <small>Opcional. O módulo tentará resolver os grupos do agente via API.</small>
          </div>
          <div class="g4fr-field g4fr-full">
            <label>Abrangência</label>
            <textarea name="scope_text" id="g4fr-scope" class="form-control" rows="3"><?php echo htmlspecialchars((string)($cfg['default_scope_text'] ?? '')); ?></textarea>
          </div>
          <div class="g4fr-field g4fr-full">
            <label>Objetivo</label>
            <textarea name="objective_text" id="g4fr-objective" class="form-control" rows="3"><?php echo htmlspecialchars((string)($cfg['default_objective_text'] ?? '')); ?></textarea>
          </div>
        </div>
      </details>
    </form>
  </div>

  <div class="g4fr-card">
    <div class="g4fr-card-title-row">
      <div>
        <h2>Contextos de extração</h2>
        <p>Marque todos os contextos que devem compor o mesmo rascunho.</p>
      </div>
      <div class="g4fr-actions g4fr-actions-tight">
        <button type="button" class="btn btn-outline-secondary btn-sm" id="g4fr-context-operational">Operacional</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" id="g4fr-context-project">Projeto</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" id="g4fr-context-all">Todos</button>
      </div>
    </div>

    <div class="g4fr-context-groups" id="g4fr-contexts">
      <fieldset>
        <legend>Chamados</legend>
        <label><input type="checkbox" value="tickets_assigned_user" checked> Atribuídos ao agente</label>
        <label><input type="checkbox" value="tickets_requested_by_user"> Solicitados pelo agente</label>
        <label><input type="checkbox" value="tickets_assigned_groups" checked> Atribuídos aos grupos do agente</label>
      </fieldset>
      <fieldset>
        <legend>Atividades em chamados</legend>
        <label><input type="checkbox" value="ticket_tasks_by_user" checked> Tarefas feitas pelo agente</label>
        <label><input type="checkbox" value="ticket_followups_by_user" checked> Acompanhamentos do agente</label>
        <label><input type="checkbox" value="ticket_solutions_by_user" checked> Soluções do agente</label>
      </fieldset>
      <fieldset>
        <legend>Projetos</legend>
        <label><input type="checkbox" value="projects_managed_by_user" checked> Gerenciados pelo agente</label>
        <label><input type="checkbox" value="projects_managed_by_groups" checked> Gerenciados pelos grupos</label>
        <label><input type="checkbox" value="projects_member_user" checked> Agente participante</label>
      </fieldset>
      <fieldset>
        <legend>Tarefas e narrativa</legend>
        <label><input type="checkbox" value="project_tasks_user" checked> Tarefas de projeto do agente</label>
        <label><input type="checkbox" value="project_tasks_groups"> Tarefas de projeto dos grupos</label>
        <label><input type="checkbox" value="manual_entries" checked> Entradas narrativas manuais</label>
      </fieldset>
    </div>

    <div class="g4fr-actions">
      <button type="button" id="g4fr-build" class="btn btn-primary">Gerar rascunho</button>
      <button type="button" id="g4fr-add-manual" class="btn btn-outline-secondary" disabled>Adicionar entrada manual</button>
      <button type="button" id="g4fr-download-json" class="btn btn-outline-secondary" disabled>Baixar JSON</button>
      <label class="btn btn-outline-secondary mb-0">
        Importar JSON <input type="file" id="g4fr-import-json" accept="application/json" hidden>
      </label>
      <button type="button" id="g4fr-export" class="btn btn-success" disabled>Exportar DOCX</button>
    </div>
  </div>

  <div id="g4fr-status" class="g4fr-status"></div>
  <div id="g4fr-preview"></div>
</div>
<script>
window.G4FREPORTS = { api_url: 'api.php', export_url: 'export.php', csrf: <?php echo json_encode((class_exists('Session') && method_exists('Session', 'getNewCSRFToken')) ? Session::getNewCSRFToken() : ''); ?> };
</script>
<script src="asset.php?name=report.js&v=<?php echo rawurlencode(PLUGIN_G4FREPORTS_VERSION); ?>"></script>
<?php
if (class_exists('Html')) {
    Html::footer();
}
