<?php
// Serve plugin assets through a PHP endpoint under front/ to avoid direct
// /plugins/*/assets static-path issues in public-root GLPI deployments.

$name = basename((string)($_GET['name'] ?? ''));
$map = [
    'g4freports.css' => ['path' => dirname(__DIR__) . '/assets/css/g4freports.css', 'type' => 'text/css; charset=UTF-8'],
    'report.js'      => ['path' => dirname(__DIR__) . '/assets/js/report.js', 'type' => 'application/javascript; charset=UTF-8'],
    'config.js'      => ['path' => dirname(__DIR__) . '/assets/js/config.js', 'type' => 'application/javascript; charset=UTF-8'],
    'diagnostics.js' => ['path' => dirname(__DIR__) . '/assets/js/diagnostics.js', 'type' => 'application/javascript; charset=UTF-8'],
];

if (!isset($map[$name]) || !is_file($map[$name]['path'])) {
    http_response_code(404);
    exit;
}

$path = $map[$name]['path'];
$mtime = (int)@filemtime($path);
header('Content-Type: ' . $map[$name]['type']);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if ($mtime > 0) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
}
readfile($path);
