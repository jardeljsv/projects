<?php
// /plugins/g4freports/front/test_connection.php
// Configuration-page connection test. Accepts ad-hoc values from the form so
// admins can test a profile before saving it.

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Security;
use GlpiPlugin\G4freports\Api\GlpiApiClient;

@ini_set('display_errors', '0');

if (class_exists('Session')) {
    Session::checkLoginUser();
}
if (!Security::canConfigure()) {
    g4fr_json_response(403, ['ok' => false, 'error' => 'Acesso negado']);
}

function g4fr_tc_bool($v, bool $default = true): bool {
    if (is_bool($v)) return $v;
    if (is_numeric($v)) return ((int)$v) !== 0;
    if (is_string($v)) {
        $s = strtolower(trim($v));
        if ($s === '') return $default;
        if (in_array($s, ['1','true','yes','y','on','sim'], true)) return true;
        if (in_array($s, ['0','false','no','n','off','nao','não'], true)) return false;
    }
    return $default;
}

$input = $_GET + $_POST;
$profile = [
    'id' => '__adhoc__',
    'name' => trim((string)($input['name'] ?? 'Teste')),
    'base_url' => trim((string)($input['base_url'] ?? ($input['api_base_url'] ?? ''))),
    'app_token' => trim((string)($input['app_token'] ?? '')),
    'user_token' => trim((string)($input['user_token'] ?? '')),
    'session_token' => trim((string)($input['session_token'] ?? '')),
    'verify_tls' => g4fr_tc_bool($input['verify_tls'] ?? true, true),
    'timeout_ms' => max(1000, min(600000, (int)($input['timeout_ms'] ?? ($input['request_timeout_ms'] ?? 60000)))),
];

if ($profile['base_url'] === '') {
    g4fr_json_response(200, ['ok' => false, 'reason' => 'not_configured', 'error' => 'URL base da API não informada.']);
}
if ($profile['session_token'] === '' && $profile['user_token'] === '') {
    g4fr_json_response(200, ['ok' => false, 'reason' => 'not_configured', 'error' => 'Informe User token ou Session token.']);
}

try {
    $client = new GlpiApiClient($profile);
    $client->initSession();
    try {
        $session = $client->request('GET', '/getFullSession');
    } catch (Throwable $e) {
        $session = ['warning' => $e->getMessage()];
    }
    $client->killSession();
    g4fr_json_response(200, ['ok' => true, 'reason' => 'connected', 'base_url' => $client->getBaseUrl(), 'session' => $session]);
} catch (Throwable $e) {
    g4fr_json_response(200, ['ok' => false, 'reason' => 'upstream_error', 'error' => $e->getMessage()]);
}
