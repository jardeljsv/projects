<?php
// Standalone configuration entry. The same form is also available as a tab in
// Configurar > Geral, matching the GLPIBot configuration pattern.

require_once dirname(__DIR__) . '/inc/bootstrap.php';

use GlpiPlugin\G4freports\Config;
use GlpiPlugin\G4freports\Security;
use Glpi\Application\View\TemplateRenderer;

if (class_exists('Session')) {
    Session::checkLoginUser();
}

if (!Security::canConfigure()) {
    if (class_exists('Html')) {
        Html::displayRightError();
    }
    http_response_code(403);
    exit;
}

if (class_exists('Html')) {
    Html::header(__('Configurações - Relatórios G4F', 'g4freports'), $_SERVER['PHP_SELF'], 'tools', 'PluginG4freportsMenu');
}

echo '<div class="m-3">';
Config::showForConfig(new \Config());
echo '</div>';

if (class_exists('Html')) {
    Html::footer();
}
