<?php
// /plugins/glpibot/front/chatproxy.php
// Browser -> this proxy -> FastAPI model.
//
// Important GLPI 11/proxy compatibility note:
// some GLPI deployments/WAF/proxy chains reject direct browser POSTs to
// /plugins/*/front/*.php with HTTP 403 before the plugin code can run.  The
// widget therefore calls this endpoint with GET by default, while this proxy
// still calls the real chat API /chat endpoint with POST.  POST is kept here
// for backward compatibility and for environments where it is allowed.

require_once dirname(__DIR__) . '/inc/bootstrapless.php';

@ini_set('display_errors', '0');

function respond_error(int $http, string $label, string $detail = '', $trace = ''): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
    http_response_code($http);
    $out = ['error' => $label, 'detail' => $detail];
    if ($trace !== '' && $trace !== null) {
        if (!is_string($trace)) {
            $trace = json_encode($trace, JSON_UNESCAPED_UNICODE);
        } elseif (strlen($trace) > 4096) {
            $trace = substr($trace, 0, 4096) . '...[truncated]';
        }
        $out['trace'] = $trace;
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}

function respond_ok(string $text): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
    http_response_code(200);
    echo json_encode(['text' => $text], JSON_UNESCAPED_UNICODE);
    exit;
}

function glpibot_chatproxy_read_input(): array {
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

    if ($method === 'GET') {
        return is_array($_GET) ? $_GET : [];
    }

    if ($method === 'POST') {
        $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
        if (strpos($ct, 'application/json') !== false) {
            $raw = file_get_contents('php://input');
            $decoded = json_decode((string)$raw, true);
            if (!is_array($decoded)) {
                respond_error(400, 'invalid_json', 'body must be valid JSON');
            }
            return $decoded;
        }

        // Backward-compatible form POST support.  This is useful when a reverse
        // proxy allows form posts but blocks application/json posts.
        if (!empty($_POST) && is_array($_POST)) {
            return $_POST;
        }

        respond_error(415, 'unsupported_media_type', 'need application/json, form POST, or GET query parameters');
    }

    respond_error(405, 'method_not_allowed', 'use GET or POST');
    return [];
}

$data = glpibot_chatproxy_read_input();

$sid            = (string)($data['sid'] ?? '');
$prompt         = trim((string)($data['prompt'] ?? ''));
$topP           = ($data['top_p'] ?? 0.85);
$temperature    = ($data['temperature'] ?? 0.35);
$maxNewTokens   = glpibot_int($data['max_new_tokens'] ?? ($data['max_len'] ?? 120), 120, 1, 2048);
$minLen         = glpibot_int($data['min_len'] ?? 4, 4, 0, 2048);

if ($prompt === '') {
    respond_error(400, 'empty_prompt', 'prompt is empty');
}
if (function_exists('mb_strlen') && mb_strlen($prompt, 'UTF-8') > 4000) {
    $prompt = mb_substr($prompt, 0, 4000, 'UTF-8');
} elseif (strlen($prompt) > 12000) {
    $prompt = substr($prompt, 0, 12000);
}

$glpiRoot = null;
if (!glpibot_bootstrap_glpi_runtime($glpiRoot)) {
    respond_error(500, 'internal_error', 'glpi_bootstrap_unavailable');
}

$cfg = glpibot_load_plugin_config_glpi();
$uid = glpibot_resolve_uid_glpi_runtime();
$runtime = glpibot_resolve_runtime_profile_glpi($cfg, $uid);

if (empty($runtime['ok']) || !is_array($runtime['profile'] ?? null)) {
    $reason = (string)($runtime['reason'] ?? 'profile_unavailable');
    $http = in_array($reason, ['not_in_allowed_groups', 'no_matching_route', 'uid_not_found_for_route_mode', 'uid_not_found', 'route_profile_missing_or_disabled'], true) ? 403 : 503;
    respond_error($http, 'profile_unavailable', $reason);
}

$profile = $runtime['profile'];
$chatUrl = (string)($profile['chat_url'] ?? '');
$apiKey = (string)($profile['api_key'] ?? '');
$timeoutMs = glpibot_int($profile['request_timeout_ms'] ?? 60000, 60000, 1000, 600000);
if ($chatUrl === '' || $apiKey === '') {
    respond_error(503, 'profile_not_configured', 'missing_chat_url_or_api_key');
}

$upPayload = [
    'sid' => $sid,
    'prompt' => $prompt,
    'top_p' => $topP,
    'temperature' => $temperature,
    'max_new_tokens' => $maxNewTokens,
    'max_len' => $maxNewTokens,
    'min_len' => $minLen,
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Bearer ' . $apiKey,
];

// The upstream model endpoint remains POST /chat.
$req = glpibot_http_json_request('POST', $chatUrl, $headers, $upPayload, $timeoutMs);
if (!$req['ok']) {
    respond_error(
        502,
        'upstream_error',
        'upstream_http_' . (int)$req['http_code'],
        $req['curl_error'] !== '' ? $req['curl_error'] : (string)$req['body_raw']
    );
}

$parsed = is_array($req['json']) ? $req['json'] : null;
if (!is_array($parsed)) {
    respond_error(502, 'invalid_upstream_json', (string)$req['body_raw']);
}
if (!array_key_exists('reply', $parsed)) {
    respond_error(502, 'no_reply_in_upstream', '', $parsed);
}

respond_ok((string)$parsed['reply']);
