<?php
// plugins/glpibot/setup.php

$autoload = __DIR__ . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}
require_once __DIR__ . '/inc/common.php';

define('PLUGIN_GLPIBOT_VERSION', '0.3.4');

function glpibot_injection_default_on_error(array $cfg = []): bool {
    $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
    if (!$enabled) {
        return false;
    }

    $hasRestrictions = glpibot_has_enabled_group_routes($cfg)
        || !empty(glpibot_parse_id_list($cfg['allowed_groups'] ?? ''));

    // If visibility is restricted and evaluation failed, fail closed.
    // If there are no restrictions, keep the legacy fail-open behavior.
    return !$hasRestrictions;
}

/**
 * Decide whether to inject widget assets for the current request.
 *
 * Legacy mode:
 *   - empty allowed_groups => inject for everyone
 *   - non-empty allowed_groups => inject only for users in those groups
 *
 * Route mode:
 *   - if at least one enabled route exists, inject only for users that match
 *     an enabled route pointing to an available profile
 */
function glpibot_should_inject_assets(): bool {
    $cfg = [];

    try {
        if (!class_exists('Config') || !method_exists('Config', 'getConfigurationValues')) {
            return true;
        }

        $cfg = Config::getConfigurationValues('plugin:glpibot');
        $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
        if (!$enabled) {
            return false;
        }

        $uid = glpibot_get_current_uid_glpi();

        if (glpibot_has_enabled_group_routes($cfg)) {
            if ($uid <= 0) {
                return false;
            }

            $userGroups = glpibot_resolve_current_user_groups_glpi($uid);
            if (empty($userGroups)) {
                return false;
            }

            $expanded = glpibot_expand_group_ancestors_glpi($userGroups);
            $routeProbe = glpibot_match_route_from_groups($cfg, $userGroups, $expanded);
            if (empty($routeProbe['matched']) || !is_array($routeProbe['match'] ?? null)) {
                return false;
            }

            $profileId = glpibot_string($routeProbe['match']['route']['profile_id'] ?? '__default__', '__default__');
            if ($profileId === '') {
                $profileId = '__default__';
            }

            $profiles = glpibot_profiles_with_default($cfg);
            $profile = $profiles[$profileId] ?? null;
            if (!is_array($profile)) {
                return false;
            }
            if (empty($profile['is_default']) && empty($profile['enabled'])) {
                return false;
            }

            return true;
        }

        $allowed = glpibot_parse_id_list($cfg['allowed_groups'] ?? '');
        if (empty($allowed)) {
            return true;
        }

        if ($uid <= 0) {
            return false;
        }

        $userGroups = glpibot_resolve_current_user_groups_glpi($uid);
        if (empty($userGroups)) {
            return false;
        }

        $expanded = glpibot_expand_group_ancestors_glpi($userGroups);
        $allowMap = [];
        foreach ($allowed as $gid) {
            $gid = (int)$gid;
            if ($gid > 0) {
                $allowMap[$gid] = true;
            }
        }

        foreach (array_keys($expanded) as $gid) {
            if (isset($allowMap[(int)$gid])) {
                return true;
            }
        }

        return false;
    } catch (Throwable $e) {
        return glpibot_injection_default_on_error($cfg);
    }
}

/**
 * Called by GLPI to initialize plugin hooks.
 */
function plugin_init_glpibot() {
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['glpibot'] = true;

    if (class_exists('Plugin')) {
        Plugin::registerClass(\GlpiPlugin\Glpibot\Config::class, [
            'addtabon' => \Config::class
        ]);
    }

    if (glpibot_should_inject_assets()) {
        // Serve widget assets through PHP endpoints to stay compatible with
        // GLPI 11/public-root setups where direct static plugin assets may 404.
        $PLUGIN_HOOKS['add_javascript']['glpibot'] = [
            'front/widgetjs.php'
        ];
        $PLUGIN_HOOKS['add_css']['glpibot'] = [
            'front/widgetcss.php'
        ];
    }
}

function plugin_version_glpibot() {
    return [
        'name'     => 'GLPIBot',
        'version'  => PLUGIN_GLPIBOT_VERSION,
        'author'   => 'Artur de Andrade Batista',
        'license'  => 'MIT',
        'homepage' => ''
    ];
}

function plugin_glpibot_check_config($verbose = false) {
    return true;
}
