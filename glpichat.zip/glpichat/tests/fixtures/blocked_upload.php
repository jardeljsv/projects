<?php

echo 'blocked upload fixture';
