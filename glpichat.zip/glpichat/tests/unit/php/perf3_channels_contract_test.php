<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/bootstrap/unit.php';

$plugin_root = dirname(__DIR__, 3);
$controller = file_get_contents($plugin_root . '/src/Controller/WidgetController.php');
$readstate = file_get_contents($plugin_root . '/src/db/readstate_db.php');
$diagnostics = file_get_contents($plugin_root . '/src/diagnostics.php');

if (!is_string($controller) || !is_string($readstate) || !is_string($diagnostics)) {
    glpichat_unit_fail('Unable to read perf3 Channels source contracts.');
}

$channels_start = strpos($controller, 'public function channels(Request $request): Response');
$channels_end = strpos($controller, "#[Route('/Widget/Poll'", $channels_start);
$channels = substr($controller, $channels_start, $channels_end - $channels_start);
$channels_csrf = strpos($channels, 'Session::getNewCSRFToken');
$channels_rights = strpos($channels, "Session::haveRight('plugin_glpichat_public', READ)");
$channels_groups = strpos($channels, "\$_SESSION['glpigroups']");
$channels_release = strpos($channels, '$session_released = glpichat_release_session_lock');
$channels_discovery = strpos($channels, 'glpichat_list_user_channels');
foreach ([$channels_csrf, $channels_rights, $channels_groups, $channels_release, $channels_discovery] as $position) {
    if ($position === false) {
        glpichat_unit_fail('Perf3 Channels session snapshot/release contract is incomplete.');
    }
}
if (!(
    $channels_csrf < $channels_release
    && $channels_rights < $channels_release
    && $channels_groups < $channels_release
    && $channels_release < $channels_discovery
)) {
    glpichat_unit_fail('Perf3 Channels must capture CSRF/rights/groups, release, then discover.');
}
glpichat_unit_pass('Perf3 Channels carries a request-local access snapshot across session release');

if (
    !str_contains($channels, "get('X-Glpichat-Diagnostic-Level') === 'phases'")
    || !str_contains($channels, '$channel_diagnostic_metrics = array_merge(')
    || !str_contains($channels, 'if ($detailed_diagnostics) {')
    || !str_contains($channels, "glpichat_diagnostic_log('widget_channels', 'complete'")
) {
    glpichat_unit_fail('Detailed Channels diagnostics must be exact-header gated while aggregate completion remains unconditional.');
}
glpichat_unit_pass('Periodic Channels metadata emits one aggregate record instead of every detailed phase');

$source_start = strpos($readstate, '$user_links = $DB->request([');
$merge = strpos($readstate, '$generic_candidates = $direct_links + $group_links_by_ticket;');
$merge_slice = strpos($readstate, 'array_slice($generic_candidates, 0, $source_limit, true)');
$focus = strpos($readstate, 'if ($focus_tickets_id > 0) {');
$authorization = strpos($readstate, 'foreach (array_keys($generic_candidates) as $tickets_id)');
$ticket_rows = strpos($readstate, '$ticket_rows = $DB->request([', $authorization);
$room_rows = strpos($readstate, '$room_rows = $DB->request([', $ticket_rows);
$room_cap = strpos($readstate, 'if (count($selected_channels) >= $channel_limit)');
foreach ([$source_start, $merge, $merge_slice, $focus, $authorization, $ticket_rows, $room_rows, $room_cap] as $position) {
    if ($position === false) {
        glpichat_unit_fail('Perf3 bounded Channels sequence is incomplete.');
    }
}
if (!(
    $source_start < $merge
    && $merge < $merge_slice
    && $merge_slice < $focus
    && $focus < $authorization
    && $authorization < $ticket_rows
    && $ticket_rows < $room_rows
    && $room_rows < $room_cap
)) {
    glpichat_unit_fail('Channels must bound/dedupe, reserve focus, authorize, then enrich selected rooms.');
}
glpichat_unit_pass('Perf3 performs no room/message/participant/read-state enrichment before authorization cap');

if (
    substr_count($readstate, "'LIMIT' => \$source_limit + 1") !== 2
    || substr_count($readstate, "'glpi_tickets.status' => \$active_statuses") !== 2
    || substr_count($readstate, "'INNER JOIN' => [") < 2
    || !str_contains($readstate, '$active_statuses = [1, 2, 3, 4];')
    || !str_contains($readstate, '$source_limit = 240;')
    || !str_contains($readstate, '$channel_limit = 80;')
) {
    glpichat_unit_fail('Direct/group candidates must be active, joined, deterministic and hard bounded.');
}
if (
    !str_contains($readstate, "'GROUPBY' => 'glpi_tickets_users.tickets_id'")
    || !str_contains($readstate, "'ORDER' => ['glpi_tickets_users.tickets_id DESC']")
    || !str_contains($readstate, "'GROUPBY' => 'glpi_groups_tickets.tickets_id'")
    || !str_contains($readstate, "'ORDER' => ['glpi_groups_tickets.tickets_id DESC']")
) {
    glpichat_unit_fail('Direct and group source queries must use qualified deterministic grouping/order.');
}
glpichat_unit_pass('Perf3 bounds each source and the merged generic candidate set');

foreach ([
    'direct_links',
    'group_links',
    'candidates',
    'authorization',
    'rooms',
    'message_heads',
    'participants',
    'readstates',
    'unread',
] as $phase) {
    if (!str_contains($diagnostics, "'{$phase}'")) {
        glpichat_unit_fail('Missing allowlisted Channels diagnostic phase: ' . $phase);
    }
}
if (!str_contains($diagnostics, "'widget_config'")) {
    glpichat_unit_fail('Widget Config must be a diagnostic operation.');
}
glpichat_unit_pass('Perf3 diagnostics has a closed allowlist for every Channels boundary and Config');

$config_start = strpos($controller, 'public function config(Request $request): Response');
$config_end = strpos($controller, "#[Route('/Widget/Leave'", $config_start);
$config = substr($controller, $config_start, $config_end - $config_start);
$config_csrf = strpos($config, 'Session::getNewCSRFToken');
$config_release = strpos($config, '$session_released = glpichat_release_session_lock');
$config_read = strpos($config, '\\Config::getConfigurationValue');
$config_trace = strpos($config, "'_glpichat_trace_id'");
$config_response = strpos($config, 'glpichat_diagnostic_response');
if (
    $config_csrf === false
    || $config_release === false
    || $config_read === false
    || $config_trace === false
    || $config_response === false
    || !($config_csrf < $config_release && $config_release < $config_read)
) {
    glpichat_unit_fail('Widget Config must capture CSRF, release, then read config with trace/timing response.');
}
glpichat_unit_pass('Widget Config is traceable and releases the session before configuration reads');

foreach (['set_time_limit(', 'ignore_user_abort(', 'ALTER TABLE', 'CREATE INDEX'] as $forbidden) {
    if (str_contains($channels . $readstate, $forbidden)) {
        glpichat_unit_fail('Perf3 Channels introduced a forbidden timeout/schema behavior: ' . $forbidden);
    }
}
glpichat_unit_pass('Perf3 adds no server timeout override or schema/index mutation');

fwrite(STDOUT, "[PASS] perf3 Channels contract tests completed\n");
