<?php

declare(strict_types=1);

use GlpiPlugin\Glpichat\HookHandler;

// This test intentionally loads the production HookHandler with only the
// narrow GLPI surface used by canDocument(). It therefore proves whether the
// production method reaches $DB->request(), rather than testing a copied helper.

if (!defined('READ')) {
    define('READ', 1);
}

final class Document
{
    /** @var array<string, mixed> */
    public array $fields = [];

    public mixed $right = null;
}

final class Session
{
    public static bool $has_internal_right = false;
    public static int $right_checks = 0;

    public static function haveRight(string $right, int $level): bool
    {
        self::$right_checks++;

        if ($right !== 'plugin_glpichat_internal' || $level !== READ) {
            throw new RuntimeException('Unexpected right check in canDocument test.');
        }

        return self::$has_internal_right;
    }
}

final class CanDocumentResult implements Countable
{
    public function __construct(private readonly int $count)
    {
    }

    public function count(): int
    {
        return $this->count;
    }
}

final class CanDocumentDb
{
    public int $request_count = 0;
    public bool $is_internal_document = false;

    /** @param array<string, mixed> $query */
    public function request(array $query): CanDocumentResult
    {
        $this->request_count++;

        if (($query['FROM'] ?? '') !== 'glpi_plugin_glpichat_messages') {
            throw new RuntimeException('canDocument queried an unexpected table.');
        }

        return new CanDocumentResult($this->is_internal_document ? 1 : 0);
    }
}

require_once dirname(__DIR__, 3) . '/src/HookHandler.php';

/** @return never */
function canDocumentFastPathFail(string $message): void
{
    fwrite(STDERR, "[FAIL] {$message}\n");
    exit(1);
}

function canDocumentFastPathAssert(bool $condition, string $message): void
{
    if (!$condition) {
        canDocumentFastPathFail($message);
    }

    fwrite(STDOUT, "[PASS] {$message}\n");
}

function canDocumentFastPathDocument(int $id, int $right): Document
{
    $document = new Document();
    $document->fields['id'] = $id;
    $document->right = $right;

    return $document;
}

$DB = new CanDocumentDb();
$GLOBALS['DB'] = $DB;

// Authorized profiles cannot be denied by this hook. The production method
// must return before issuing the document/message lookup.
Session::$has_internal_right = true;
Session::$right_checks = 0;
$DB->request_count = 0;
$DB->is_internal_document = true;
$document = canDocumentFastPathDocument(501, READ);
HookHandler::canDocument($document);

canDocumentFastPathAssert($document->right === READ, 'Authorized internal reader keeps READ');
canDocumentFastPathAssert(Session::$right_checks === 1, 'Authorized path checks the internal right once');
canDocumentFastPathAssert($DB->request_count === 0, 'Authorized path issues no database request');

// A normal user still takes the security lookup and is denied when the
// document is attached to an internal-room message.
Session::$has_internal_right = false;
Session::$right_checks = 0;
$DB->request_count = 0;
$DB->is_internal_document = true;
$document = canDocumentFastPathDocument(502, READ);
HookHandler::canDocument($document);

canDocumentFastPathAssert(Session::$right_checks === 1, 'Normal path checks the internal right once');
canDocumentFastPathAssert($DB->request_count === 1, 'Normal path still queries document linkage');
canDocumentFastPathAssert($document->right === null, 'Normal user is denied an internal-chat document');

// Negative authorization is deliberately not cached: a second document must
// perform its own lookup so unrelated/public documents remain accessible.
$DB->is_internal_document = false;
$document = canDocumentFastPathDocument(503, READ);
HookHandler::canDocument($document);

canDocumentFastPathAssert($DB->request_count === 2, 'Negative authorization is not persistently cached');
canDocumentFastPathAssert($document->right === READ, 'Unlinked document remains accessible to a normal user');

fwrite(STDOUT, "[PASS] canDocument fast-path unit tests completed\n");
