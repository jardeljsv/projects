<?php

declare(strict_types=1);

namespace Glpi\DBAL {
    final class QueryFunction
    {
        public static function max(string $field, string $alias): string
        {
            return sprintf('MAX(%s) AS %s', $field, $alias);
        }
    }
}

namespace {
    if (!defined('READ')) {
        define('READ', 1);
    }

    final class CommonITILActor
    {
        public const REQUESTER = 1;
        public const ASSIGN = 2;
        public const OBSERVER = 3;
    }

    final class CommonITILObject
    {
        public const SOLVED = 5;
        public const CLOSED = 6;
    }

    final class Session
    {
        /** @var array<string, bool> */
        public static array $rights = [];

        /** @var array<string, int> */
        public static array $right_checks = [];

        public static function haveRight(string $right, int $level): bool
        {
            if ($level !== READ) {
                throw new RuntimeException('Unexpected right level in channel discovery test.');
            }

            self::$right_checks[$right] = (self::$right_checks[$right] ?? 0) + 1;

            return self::$rights[$right] ?? false;
        }
    }

    final class ChannelDiscoveryTicket
    {
        public int $can_calls = 0;

        public function __construct(
            public readonly int $id,
            private readonly bool $readable
        ) {
        }

        public function can(int $id, int $right): bool
        {
            if ($id !== $this->id || $right !== READ) {
                throw new RuntimeException('Unexpected Ticket::can arguments.');
            }

            $this->can_calls++;

            return $this->readable;
        }
    }

    final class ChannelDiscoveryResult implements \IteratorAggregate
    {
        /** @param list<array<string, mixed>> $rows */
        public function __construct(private readonly array $rows)
        {
        }

        public function getIterator(): \Traversable
        {
            return new \ArrayIterator($this->rows);
        }

        /** @return array<string, mixed>|false */
        public function current(): array|false
        {
            return $this->rows[0] ?? false;
        }
    }

    final class ChannelDiscoveryDb
    {
        /** @var list<array<string, mixed>> */
        public array $queries = [];

        /**
         * @param list<array{tickets_id:int}> $user_links
         * @param list<array{tickets_id:int}> $group_links
         * @param list<array{id:int,status:int}> $ticket_rows
         * @param list<array{id:int,tickets_id:int,room_type:string}> $room_rows
         * @param list<array{rooms_id:int,last_id:int}> $message_rows
         * @param list<array<string, mixed>> $participant_rows
         * @param list<array{participants_id:int,last_read_messages_id:int}> $readstate_rows
         * @param array<int, int> $unread_by_room
         */
        public function __construct(
            private readonly array $user_links,
            private readonly array $group_links,
            private readonly array $ticket_rows,
            private readonly array $room_rows,
            private readonly array $message_rows = [],
            private readonly array $participant_rows = [],
            private readonly array $readstate_rows = [],
            private readonly array $unread_by_room = []
        ) {
        }

        /** @param array<string, mixed> $query */
        public function request(array $query): ChannelDiscoveryResult
        {
            $this->queries[] = $query;
            $table = (string) ($query['FROM'] ?? '');

            if ($table === 'glpi_tickets_users') {
                return new ChannelDiscoveryResult($this->boundedActiveLinks($this->user_links, $query));
            }
            if ($table === 'glpi_groups_tickets') {
                return new ChannelDiscoveryResult($this->boundedActiveLinks($this->group_links, $query));
            }
            if ($table === 'glpi_tickets') {
                $ids = array_map('intval', (array) ($query['WHERE']['id'] ?? []));
                return new ChannelDiscoveryResult(array_values(array_filter(
                    $this->ticket_rows,
                    static fn (array $row): bool => in_array((int) $row['id'], $ids, true)
                )));
            }
            if ($table === 'glpi_plugin_glpichat_rooms') {
                $ids = array_map('intval', (array) ($query['WHERE']['tickets_id'] ?? []));
                $room_types = array_map('strval', (array) ($query['WHERE']['room_type'] ?? []));
                return new ChannelDiscoveryResult(array_values(array_filter(
                    $this->room_rows,
                    static fn (array $row): bool => in_array((int) $row['tickets_id'], $ids, true)
                        && in_array((string) $row['room_type'], $room_types, true)
                )));
            }
            if ($table === 'glpi_plugin_glpichat_participants') {
                $ids = array_map('intval', (array) ($query['WHERE']['rooms_id'] ?? []));
                return new ChannelDiscoveryResult(array_values(array_filter(
                    $this->participant_rows,
                    static fn (array $row): bool => in_array((int) $row['rooms_id'], $ids, true)
                )));
            }
            if ($table === 'glpi_plugin_glpichat_readstates') {
                $ids = array_map('intval', (array) ($query['WHERE']['participants_id'] ?? []));
                return new ChannelDiscoveryResult(array_values(array_filter(
                    $this->readstate_rows,
                    static fn (array $row): bool => in_array((int) $row['participants_id'], $ids, true)
                )));
            }
            if ($table === 'glpi_plugin_glpichat_messages' && isset($query['COUNT'])) {
                $rooms_id = (int) ($query['WHERE']['rooms_id'] ?? 0);
                return new ChannelDiscoveryResult([['cpt' => $this->unread_by_room[$rooms_id] ?? 0]]);
            }
            if ($table === 'glpi_plugin_glpichat_messages') {
                $ids = array_map('intval', (array) ($query['WHERE']['rooms_id'] ?? []));
                return new ChannelDiscoveryResult(array_values(array_filter(
                    $this->message_rows,
                    static fn (array $row): bool => in_array((int) $row['rooms_id'], $ids, true)
                )));
            }

            throw new RuntimeException('Unexpected table in channel discovery test: ' . $table);
        }

        /**
         * Emulate the joined active-status, grouped, descending and limited
         * source query used by production discovery.
         *
         * @param list<array{tickets_id:int}> $links
         * @param array<string, mixed> $query
         * @return list<array{tickets_id:int}>
         */
        private function boundedActiveLinks(array $links, array $query): array
        {
            $statuses_by_id = [];
            foreach ($this->ticket_rows as $ticket) {
                $statuses_by_id[(int) $ticket['id']] = (int) $ticket['status'];
            }
            $active_statuses = array_map('intval', (array) ($query['WHERE']['glpi_tickets.status'] ?? []));
            $unique = [];
            foreach ($links as $link) {
                $tickets_id = (int) $link['tickets_id'];
                if (!in_array($statuses_by_id[$tickets_id] ?? 0, $active_statuses, true)) {
                    continue;
                }
                $unique[$tickets_id] = ['tickets_id' => $tickets_id];
            }
            krsort($unique, SORT_NUMERIC);

            return array_slice(array_values($unique), 0, (int) ($query['LIMIT'] ?? count($unique)));
        }
    }

    /** @var array<int, ChannelDiscoveryTicket> */
    $channel_discovery_tickets = [];

    /** @var array<string, int> */
    $channel_discovery_room_ids = [];

    /** @var list<string> */
    $channel_discovery_room_creations = [];

    function glpichat_ticket_or_fail(int $tickets_id): ChannelDiscoveryTicket
    {
        global $channel_discovery_tickets;

        if (!isset($channel_discovery_tickets[$tickets_id])) {
            throw new RuntimeException('Missing ticket fixture #' . $tickets_id);
        }

        return $channel_discovery_tickets[$tickets_id];
    }

    function glpichat_room_id(int $tickets_id, string $room_type): int
    {
        global $channel_discovery_room_ids, $channel_discovery_room_creations;

        $key = $tickets_id . ':' . $room_type;
        $channel_discovery_room_creations[] = $key;

        if (!isset($channel_discovery_room_ids[$key])) {
            $channel_discovery_room_ids[$key] = ($tickets_id * 100) + ($room_type === 'internal' ? 2 : 1);
        }

        return $channel_discovery_room_ids[$key];
    }

    require_once dirname(__DIR__, 3) . '/src/domain/domain.php';
    require_once dirname(__DIR__, 3) . '/src/domain/access.php';
    require_once dirname(__DIR__, 3) . '/src/domain/readstate.php';
    require_once dirname(__DIR__, 3) . '/src/views/channel_view.php';
    require_once dirname(__DIR__, 3) . '/src/db/readstate_db.php';

    /** @return never */
    function channelDiscoveryFail(string $message): void
    {
        fwrite(STDERR, "[FAIL] {$message}\n");
        exit(1);
    }

    function channelDiscoveryAssert(bool $condition, string $message): void
    {
        if (!$condition) {
            channelDiscoveryFail($message);
        }

        fwrite(STDOUT, "[PASS] {$message}\n");
    }

    /** @param mixed $expected @param mixed $actual */
    function channelDiscoveryAssertSame(mixed $expected, mixed $actual, string $message): void
    {
        if ($expected !== $actual) {
            channelDiscoveryFail(
                $message
                . ' expected=' . var_export($expected, true)
                . ' actual=' . var_export($actual, true)
            );
        }

        fwrite(STDOUT, "[PASS] {$message}\n");
    }

    // Mixed focus/user/group candidates, including a duplicate and one ticket
    // denied by GLPI. Both room types are enabled to prove that room iteration
    // does not repeat Ticket::can().
    $_SESSION['glpigroups'] = [70];
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => true,
    ];
    Session::$right_checks = [];

    $channel_discovery_tickets = [
        10 => new ChannelDiscoveryTicket(10, true),
        20 => new ChannelDiscoveryTicket(20, false),
        30 => new ChannelDiscoveryTicket(30, true),
        40 => new ChannelDiscoveryTicket(40, true),
    ];
    $channel_discovery_room_ids = ['40:internal' => 4002];
    $channel_discovery_room_creations = [];

    $first_db = new ChannelDiscoveryDb(
        [['tickets_id' => 10], ['tickets_id' => 20]],
        [['tickets_id' => 20], ['tickets_id' => 30]],
        [
            ['id' => 10, 'status' => 1],
            ['id' => 20, 'status' => 2],
            ['id' => 30, 'status' => 3],
            ['id' => 40, 'status' => 4],
        ],
        [
            ['id' => 101, 'tickets_id' => 10, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 102, 'tickets_id' => 10, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 201, 'tickets_id' => 20, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 202, 'tickets_id' => 20, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 301, 'tickets_id' => 30, 'room_type' => GLPICHAT_ROOM_PUBLIC],
            ['id' => 302, 'tickets_id' => 30, 'room_type' => GLPICHAT_ROOM_INTERNAL],
            ['id' => 401, 'tickets_id' => 40, 'room_type' => GLPICHAT_ROOM_PUBLIC],
        ],
        [
            ['rooms_id' => 101, 'last_id' => 1001],
            ['rooms_id' => 302, 'last_id' => 3002],
            ['rooms_id' => 401, 'last_id' => 4001],
        ],
        [
            [
                'id' => 9101,
                'rooms_id' => 101,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => null,
            ],
            [
                'id' => 9302,
                'rooms_id' => 302,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => '2026-08-23 10:00:00',
            ],
            [
                'id' => 9401,
                'rooms_id' => 401,
                'participant_type' => GLPICHAT_ACTOR_USER,
                'users_id' => 7,
                'left_at' => null,
            ],
        ],
        [
            ['participants_id' => 9101, 'last_read_messages_id' => 900],
            ['participants_id' => 9302, 'last_read_messages_id' => 2900],
            ['participants_id' => 9401, 'last_read_messages_id' => 3900],
        ],
        [101 => 1, 302 => 2, 401 => 4]
    );
    $GLOBALS['DB'] = $first_db;

    $channel_phases = [];
    $channels = glpichat_list_user_channels(
        7,
        40,
        [
            'can_read_public_room' => true,
            'can_read_internal_room' => true,
            'groups_ids' => [70],
        ],
        static function (string $phase, array $metrics) use (&$channel_phases): void {
            $channel_phases[$phase] = $metrics;
        }
    );

    $expected = [
        [
            'rooms_id' => 401,
            'tickets_id' => 40,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 9401,
            'unread_count' => 4,
            'last_message_id' => 4001,
            'ticket_status' => 4,
        ],
        [
            'rooms_id' => 4002,
            'tickets_id' => 40,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 4,
        ],
        [
            'rooms_id' => 301,
            'tickets_id' => 30,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 3,
        ],
        [
            'rooms_id' => 302,
            'tickets_id' => 30,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 2,
            'last_message_id' => 3002,
            'ticket_status' => 3,
        ],
        [
            'rooms_id' => 101,
            'tickets_id' => 10,
            'room_type' => GLPICHAT_ROOM_PUBLIC,
            'participants_id' => 9101,
            'unread_count' => 1,
            'last_message_id' => 1001,
            'ticket_status' => 1,
        ],
        [
            'rooms_id' => 102,
            'tickets_id' => 10,
            'room_type' => GLPICHAT_ROOM_INTERNAL,
            'participants_id' => 0,
            'unread_count' => 0,
            'last_message_id' => 0,
            'ticket_status' => 1,
        ],
    ];

    channelDiscoveryAssertSame($expected, $channels, 'Channel output, order, rooms, unread state and status remain unchanged');
    channelDiscoveryAssertSame(['40:internal'], $channel_discovery_room_creations, 'Missing allowed room still uses existing room creation path');
    channelDiscoveryAssertSame(0, Session::$right_checks['plugin_glpichat_public'] ?? 0, 'Supplied public right snapshot is reused after session release');
    channelDiscoveryAssertSame(0, Session::$right_checks['plugin_glpichat_internal'] ?? 0, 'Supplied internal right snapshot is reused after session release');

    channelDiscoveryAssertSame(
        ['direct_links', 'group_links', 'candidates', 'authorization', 'rooms', 'message_heads', 'participants', 'readstates', 'unread'],
        array_keys($channel_phases),
        'Channel discovery reports every privacy-safe performance phase in order'
    );
    channelDiscoveryAssertSame(3, $channel_phases['authorization']['authorized_tickets'] ?? 0, 'Authorization diagnostics count only readable bounded tickets');
    channelDiscoveryAssertSame(1, $channel_phases['authorization']['denied_tickets'] ?? 0, 'Authorization diagnostics count denied candidates without identity data');
    channelDiscoveryAssertSame(1, $channel_phases['rooms']['rooms_created'] ?? 0, 'Room diagnostics count selected room creation');
    channelDiscoveryAssertSame(3, $channel_phases['unread']['unread_queries'] ?? 0, 'Unread diagnostics count only bounded participant queries');

    $queries_by_table = [];
    foreach ($first_db->queries as $query) {
        $queries_by_table[(string) ($query['FROM'] ?? '')][] = $query;
    }
    $direct_query = $queries_by_table['glpi_tickets_users'][0] ?? [];
    $group_query = $queries_by_table['glpi_groups_tickets'][0] ?? [];
    channelDiscoveryAssertSame(['glpi_tickets_users.tickets_id AS tickets_id'], $direct_query['SELECT'] ?? [], 'Direct source aliases the qualified result to tickets_id');
    channelDiscoveryAssertSame(
        [
            'ON' => [
                'glpi_tickets_users' => 'tickets_id',
                'glpi_tickets' => 'id',
            ],
        ],
        $direct_query['INNER JOIN']['glpi_tickets'] ?? [],
        'Direct source joins the ticket table before applying active status'
    );
    channelDiscoveryAssertSame(241, $direct_query['LIMIT'] ?? 0, 'Direct actor source query is hard bounded with one truncation sentinel');
    channelDiscoveryAssertSame('glpi_tickets_users.tickets_id', $direct_query['GROUPBY'] ?? '', 'Direct actor source query deduplicates tickets in SQL');
    channelDiscoveryAssertSame(['glpi_tickets_users.tickets_id DESC'], $direct_query['ORDER'] ?? [], 'Direct actor source query is deterministic descending');
    channelDiscoveryAssertSame(7, $direct_query['WHERE']['glpi_tickets_users.users_id'] ?? 0, 'Direct source remains scoped to the current user');
    channelDiscoveryAssertSame(
        [CommonITILActor::REQUESTER, CommonITILActor::ASSIGN, CommonITILActor::OBSERVER],
        $direct_query['WHERE']['glpi_tickets_users.type'] ?? [],
        'Direct source preserves requester, assignee and observer roles'
    );
    channelDiscoveryAssertSame([1, 2, 3, 4], $direct_query['WHERE']['glpi_tickets.status'] ?? [], 'Direct generic discovery filters active statuses in SQL');
    channelDiscoveryAssertSame(241, $group_query['LIMIT'] ?? 0, 'Group actor source query uses the same hard bound');
    channelDiscoveryAssertSame(['glpi_groups_tickets.tickets_id AS tickets_id'], $group_query['SELECT'] ?? [], 'Group source aliases the qualified result to tickets_id');
    channelDiscoveryAssertSame(
        [
            'ON' => [
                'glpi_groups_tickets' => 'tickets_id',
                'glpi_tickets' => 'id',
            ],
        ],
        $group_query['INNER JOIN']['glpi_tickets'] ?? [],
        'Group source joins the ticket table before applying active status'
    );
    channelDiscoveryAssertSame('glpi_groups_tickets.tickets_id', $group_query['GROUPBY'] ?? '', 'Group actor source query deduplicates tickets in SQL');
    channelDiscoveryAssertSame(['glpi_groups_tickets.tickets_id DESC'], $group_query['ORDER'] ?? [], 'Group actor source query is deterministic descending');
    channelDiscoveryAssertSame([70], $group_query['WHERE']['glpi_groups_tickets.groups_id'] ?? [], 'Group source remains scoped to snapshotted groups');
    channelDiscoveryAssertSame(
        [CommonITILActor::REQUESTER, CommonITILActor::ASSIGN, CommonITILActor::OBSERVER],
        $group_query['WHERE']['glpi_groups_tickets.type'] ?? [],
        'Group source preserves requester, assignee and observer roles'
    );
    channelDiscoveryAssertSame([1, 2, 3, 4], $group_query['WHERE']['glpi_tickets.status'] ?? [], 'Group generic discovery filters active statuses in SQL');

    $room_query = $queries_by_table['glpi_plugin_glpichat_rooms'][0] ?? [];
    $message_query = $queries_by_table['glpi_plugin_glpichat_messages'][0] ?? [];
    $participant_query = $queries_by_table['glpi_plugin_glpichat_participants'][0] ?? [];
    channelDiscoveryAssertSame([40, 30, 10], $room_query['WHERE']['tickets_id'] ?? [], 'Room enrichment receives only bounded authorized ticket IDs');
    channelDiscoveryAssertSame([401, 4002, 301, 302, 101, 102], $message_query['WHERE']['rooms_id'] ?? [], 'Message-head enrichment receives only selected room IDs');
    channelDiscoveryAssertSame([401, 4002, 301, 302, 101, 102], $participant_query['WHERE']['rooms_id'] ?? [], 'Participant enrichment receives only selected room IDs');

    foreach ($channel_discovery_tickets as $tickets_id => $ticket) {
        channelDiscoveryAssertSame(1, $ticket->can_calls, 'Ticket #' . $tickets_id . ' receives one Ticket::can decision');
    }

    channelDiscoveryAssert(
        !in_array(20, array_column($channels, 'tickets_id'), true),
        'Ticket denied by GLPI remains absent from channel output'
    );

    // Generic discovery excludes terminal tickets, but an explicit ticket-page
    // focus remains eligible and is reserved ahead of the generic output cap.
    $_SESSION['glpigroups'] = [];
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => false,
    ];
    Session::$right_checks = [];
    $channel_discovery_tickets = [
        90 => new ChannelDiscoveryTicket(90, true),
        100 => new ChannelDiscoveryTicket(100, true),
    ];
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $GLOBALS['DB'] = new ChannelDiscoveryDb(
        [['tickets_id' => 90], ['tickets_id' => 100]],
        [],
        [
            ['id' => 90, 'status' => 2],
            ['id' => 100, 'status' => CommonITILObject::SOLVED],
        ],
        []
    );

    $generic_active_only = glpichat_list_user_channels(7, 0);
    channelDiscoveryAssertSame([90], array_column($generic_active_only, 'tickets_id'), 'Generic Channels discovery excludes solved/closed tickets');

    $focused_terminal = glpichat_list_user_channels(7, 100);
    channelDiscoveryAssertSame([100, 90], array_column($focused_terminal, 'tickets_id'), 'Focused terminal ticket remains available ahead of active generic tickets');
    channelDiscoveryAssertSame(CommonITILObject::SOLVED, $focused_terminal[0]['ticket_status'] ?? 0, 'Focused terminal ticket preserves its actual status');

    // Preserve the historical 80-output cap and descending candidate order.
    $_SESSION['glpigroups'] = [];
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => false,
    ];
    Session::$right_checks = [];
    $channel_discovery_tickets = [];
    $user_links = [];
    $ticket_rows = [];
    for ($id = 1; $id <= 85; $id++) {
        $channel_discovery_tickets[$id] = new ChannelDiscoveryTicket($id, true);
        $user_links[] = ['tickets_id' => $id];
        $ticket_rows[] = ['id' => $id, 'status' => 1];
    }
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $GLOBALS['DB'] = new ChannelDiscoveryDb($user_links, [], $ticket_rows, []);

    $capped_channels = glpichat_list_user_channels(7, 0);

    channelDiscoveryAssertSame(80, count($capped_channels), 'Channel discovery preserves the 80-output cap');
    channelDiscoveryAssertSame([GLPICHAT_ROOM_PUBLIC], array_values(array_unique(array_column($capped_channels, 'room_type'))), 'One-room public right can fill all 80 outputs without exposing internal rooms');
    channelDiscoveryAssertSame(85, $capped_channels[0]['tickets_id'] ?? 0, 'Candidate order remains descending at the first result');
    channelDiscoveryAssertSame(6, $capped_channels[79]['tickets_id'] ?? 0, 'Candidate order remains descending at the cap boundary');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_public'] ?? 0, 'Capped discovery snapshots public right once');
    channelDiscoveryAssertSame(1, Session::$right_checks['plugin_glpichat_internal'] ?? 0, 'Capped discovery snapshots internal right once');

    for ($id = 6; $id <= 85; $id++) {
        channelDiscoveryAssertSame(1, $channel_discovery_tickets[$id]->can_calls, 'Evaluated ticket #' . $id . ' is authorized once');
    }
    for ($id = 1; $id <= 5; $id++) {
        channelDiscoveryAssertSame(0, $channel_discovery_tickets[$id]->can_calls, 'Ticket #' . $id . ' remains beyond the unchanged cap');
    }

    // Prove the link-source sentinel and authorization stop operate before any
    // enrichment when the actor has a much larger active history.
    $channel_discovery_tickets = [];
    $large_links = [];
    $large_ticket_rows = [];
    for ($id = 1; $id <= 300; $id++) {
        $channel_discovery_tickets[$id] = new ChannelDiscoveryTicket($id, true);
        $large_links[] = ['tickets_id' => $id];
        $large_ticket_rows[] = ['id' => $id, 'status' => 1];
    }
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $large_db = new ChannelDiscoveryDb($large_links, [], $large_ticket_rows, []);
    $GLOBALS['DB'] = $large_db;
    $large_phases = [];
    $large_channels = glpichat_list_user_channels(
        7,
        0,
        [
            'can_read_public_room' => true,
            'can_read_internal_room' => false,
            'groups_ids' => [],
        ],
        static function (string $phase, array $metrics) use (&$large_phases): void {
            $large_phases[$phase] = $metrics;
        }
    );
    channelDiscoveryAssertSame(80, count($large_channels), 'Large discovery still emits exactly 80 channels');
    channelDiscoveryAssertSame(300, $large_channels[0]['tickets_id'] ?? 0, 'Large discovery begins with newest deterministic candidate');
    channelDiscoveryAssertSame(221, $large_channels[79]['tickets_id'] ?? 0, 'Large discovery stops at exact authorized output boundary');
    channelDiscoveryAssertSame(240, $large_phases['direct_links']['direct_links'] ?? 0, 'Direct source materialization is bounded to 240 unique tickets');
    channelDiscoveryAssertSame(true, $large_phases['direct_links']['source_truncated'] ?? false, 'Direct source reports the truncation sentinel');
    channelDiscoveryAssertSame(80, $large_phases['authorization']['authorized_tickets'] ?? 0, 'Authorization stops as soon as output budget is satisfied');

    $large_rooms_query = [];
    foreach ($large_db->queries as $query) {
        if (($query['FROM'] ?? '') === 'glpi_plugin_glpichat_rooms') {
            $large_rooms_query = $query;
            break;
        }
    }
    channelDiscoveryAssertSame(
        range(300, 221),
        $large_rooms_query['WHERE']['tickets_id'] ?? [],
        'Large room enrichment is constrained to the exact authorized cap'
    );
    $evaluated_calls = array_sum(array_map(
        static fn (ChannelDiscoveryTicket $ticket): int => $ticket->can_calls,
        $channel_discovery_tickets
    ));
    channelDiscoveryAssertSame(80, $evaluated_calls, 'Ticket::can is never called for candidates beyond the satisfied budget');

    $channel_discovery_tickets = [];
    $merged_direct_links = [];
    $merged_group_links = [];
    $merged_ticket_rows = [];
    for ($id = 1; $id <= 400; $id++) {
        $channel_discovery_tickets[$id] = new ChannelDiscoveryTicket($id, false);
        $merged_ticket_rows[] = ['id' => $id, 'status' => 1];
        if ($id <= 200) {
            $merged_group_links[] = ['tickets_id' => $id];
        } else {
            $merged_direct_links[] = ['tickets_id' => $id];
        }
    }
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $merged_db = new ChannelDiscoveryDb(
        $merged_direct_links,
        $merged_group_links,
        $merged_ticket_rows,
        []
    );
    $GLOBALS['DB'] = $merged_db;
    $merged_phases = [];
    $merged_channels = glpichat_list_user_channels(
        7,
        0,
        [
            'can_read_public_room' => true,
            'can_read_internal_room' => false,
            'groups_ids' => [70],
        ],
        static function (string $phase, array $metrics) use (&$merged_phases): void {
            $merged_phases[$phase] = $metrics;
        }
    );
    channelDiscoveryAssertSame([], $merged_channels, 'Denied merged candidates produce no channel output');
    channelDiscoveryAssertSame(240, $merged_phases['candidates']['candidates'] ?? 0, 'Merged direct/group candidate set has one total 240-ticket bound');
    channelDiscoveryAssertSame(true, $merged_phases['candidates']['source_truncated'] ?? false, 'Merged-source truncation is reported independently of each source query');
    $merged_evaluated_calls = array_sum(array_map(
        static fn (ChannelDiscoveryTicket $ticket): int => $ticket->can_calls,
        $channel_discovery_tickets
    ));
    channelDiscoveryAssertSame(240, $merged_evaluated_calls, 'Merged direct/group history cannot trigger more than 240 Ticket::can calls');
    $merged_enrichment_tables = array_values(array_filter(
        array_map(static fn (array $query): string => (string) ($query['FROM'] ?? ''), $merged_db->queries),
        static fn (string $table): bool => in_array($table, [
            'glpi_plugin_glpichat_rooms',
            'glpi_plugin_glpichat_messages',
            'glpi_plugin_glpichat_participants',
            'glpi_plugin_glpichat_readstates',
        ], true)
    ));
    channelDiscoveryAssertSame([], $merged_enrichment_tables, 'Denied bounded candidates trigger no room/message/participant/read-state query');

    // The active-ticket join excludes stale actor links before Ticket::can or
    // enrichment. A deleted ticket association must not fail the whole widget.
    Session::$rights = [
        'plugin_glpichat_public' => true,
        'plugin_glpichat_internal' => true,
    ];
    Session::$right_checks = [];
    $channel_discovery_tickets = [];
    $channel_discovery_room_ids = [];
    $channel_discovery_room_creations = [];
    $GLOBALS['DB'] = new ChannelDiscoveryDb(
        [['tickets_id' => 999]],
        [],
        [],
        []
    );

    $stale_channels = glpichat_list_user_channels(7, 0);
    channelDiscoveryAssertSame([], $stale_channels, 'Stale/nonexistent actor links are removed by active-ticket source discovery');

    fwrite(STDOUT, "[PASS] Channel discovery authorization unit tests completed\n");
}
