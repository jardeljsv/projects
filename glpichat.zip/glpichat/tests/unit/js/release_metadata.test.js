import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "../../..");
const readText = (relativePath) => readFileSync(resolve(root, relativePath), "utf8");

describe("perf4 release metadata", () => {
  it("keeps plugin, catalogue, package and manifest versions aligned", () => {
    const setup = readText("setup.php");
    const pluginXml = readText("plugin.xml");
    const packageJson = JSON.parse(readText("package.json"));
    const packageLock = JSON.parse(readText("package-lock.json"));
    const manifest = JSON.parse(readText("release-manifest.json"));
    const runbook = readText("docs/releases/1.0.5-perf4.md");

    expect(setup).toContain("define('PLUGIN_GLPICHAT_VERSION', '1.0.5');");
    expect(setup).toContain("define('PLUGIN_GLPICHAT_BUILD', 'perf4');");
    expect(pluginXml).toContain("<num>1.0.5</num>");
    expect(pluginXml).toContain("/refs/tags/v1.0.5.zip");
    expect(packageJson.version).toBe("1.0.5");
    expect(packageLock.version).toBe("1.0.5");
    expect(packageLock.packages[""].version).toBe("1.0.5");
    expect(manifest).toMatchObject({
      plugin: "glpichat",
      version: "1.0.5",
      build: "perf4",
      package_kind: "laboratory_candidate",
      build_date: "2026-08-26",
      baseline: {
        version: "1.0.0",
        source_archive_sha256: "ec341b0a00206d43581af54cafba7b60a8a735ee51fa7aa5888b85b3f7eaf4d1",
      },
      parent_candidate: {
        version: "1.0.4",
        build: "perf3",
        package_sha256: "2c714fad5281e974aa28ca766cb14b6c0c76ff73d7df9f2a4e875974db9d2076",
      },
      browser_surface_default_enabled: false,
      external_desktop_api_included: false,
      runtime_dependencies_added: [],
    });
    expect(runbook).toContain("# GLPI Chat 1.0.5-perf4");
    expect(runbook).toContain("frozen recovery baseline");
  });
});
