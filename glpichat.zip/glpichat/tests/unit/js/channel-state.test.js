import { describe, expect, it } from "vitest";
import { mergeChannelMetadata } from "../../../src/js/modules/channel-state.js";

describe("Channel metadata merge", () => {
  it("creates a safe unhydrated channel for first discovery", () => {
    const channel = mergeChannelMetadata(null, {
      tickets_id: 42,
      room_type: "public",
      rooms_id: 7,
      last_message_id: 99,
      unread_count: 3,
    });

    expect(channel).toMatchObject({
      tickets_id: 42,
      room_type: "public",
      rooms_id: 7,
      messages_loaded: false,
      history_loading: false,
      history_failed: false,
      last_message_id: 0,
      unread_count: 3,
    });
    expect(channel.messages).toEqual([]);
    expect(channel.events).toEqual([]);
  });

  it("preserves object identity and in-flight History state during metadata refresh", () => {
    const messages = [{ id: 15, content: "preserved" }];
    const events = [{ id: "2026-08-26 12:00:00.000000|E|1" }];
    const renderedMessageIds = new Set([15]);
    const existing = {
      tickets_id: 42,
      room_type: "public",
      rooms_id: 7,
      messages,
      events,
      messages_loaded: false,
      history_loading: true,
      history_slow: true,
      history_failed: false,
      history_error: { kind: "pending" },
      history_trace_id: "trace1234",
      history_attempt: 2,
      older_loading: true,
      renderedMessageIds,
      renderedMessageIdsOrder: [15],
      last_message_id: 15,
      last_event_id: "2026-08-26 12:00:00.000000|E|1",
      unread_count: 1,
    };

    const merged = mergeChannelMetadata(existing, {
      tickets_id: 42,
      room_type: "public",
      rooms_id: 7,
      ticket_status: 2,
      last_message_id: 200,
      last_event_id: "2026-08-26 12:05:00.000000|E|2",
      unread_count: 4,
    });

    expect(merged).toBe(existing);
    expect(merged.messages).toBe(messages);
    expect(merged.events).toBe(events);
    expect(merged.renderedMessageIds).toBe(renderedMessageIds);
    expect(merged).toMatchObject({
      history_loading: true,
      history_slow: true,
      history_failed: false,
      history_trace_id: "trace1234",
      history_attempt: 2,
      older_loading: true,
      last_message_id: 15,
      last_event_id: "2026-08-26 12:05:00.000000|E|2",
      unread_count: 4,
      ticket_status: 2,
    });
  });

  it("does not erase a stable failure diagnostic", () => {
    const existing = {
      tickets_id: 9,
      room_type: "internal",
      messages: [],
      events: [],
      history_failed: true,
      history_error: { kind: "http_error", status: 500 },
      history_trace_id: "deadbeef12345678",
    };

    const merged = mergeChannelMetadata(existing, {
      tickets_id: 9,
      room_type: "internal",
      rooms_id: 12,
      unread_count: 0,
    });

    expect(merged).toBe(existing);
    expect(merged.history_failed).toBe(true);
    expect(merged.history_error).toEqual({ kind: "http_error", status: 500 });
    expect(merged.history_trace_id).toBe("deadbeef12345678");
  });
});
