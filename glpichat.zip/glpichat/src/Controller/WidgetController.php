<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpichat\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use RuntimeException;
use Session;
use Throwable;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use function glpichat_assert_can_read_room;
use function glpichat_config_bool;
use function glpichat_config_int;
use function glpichat_current_user_id;
use function glpichat_diagnostic_elapsed_ms;
use function glpichat_diagnostic_log;
use function glpichat_diagnostic_response;
use function glpichat_diagnostic_started_at;
use function glpichat_diagnostic_trace_id;
use function glpichat_events;
use function glpichat_get_typing_participants;
use function glpichat_list_user_channels;
use function glpichat_mark_read;
use function glpichat_room_last_message_id;
use function glpichat_messages;
use function glpichat_messages_before;
use function glpichat_participant_id_for_user;
use function glpichat_require_logged_csrf;
use function glpichat_release_session_lock;
use function glpichat_room_id;
use function glpichat_ticket_status;
use function glpichat_unread_count;
use function glpichat_update_participant_activity;
use function glpichat_disconnect_user_participant;

require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/flows/widget_access_flow.php';

final class WidgetController extends AbstractController
{
    #[Route('/Widget/Channels', name: 'glpichat_widget_channels', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function channels(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));
        $detailed_diagnostics = $request->headers->get('X-Glpichat-Diagnostic-Level') === 'phases';
        $channel_diagnostic_metrics = [];
        $last_completed_phase = 'start';
        try {
            Session::checkLoginUser();
            $users_id = glpichat_current_user_id();
            $tickets_id = $request->query->getInt('tickets_id');
            $csrf_token = Session::getNewCSRFToken();
            $raw_groups_ids = $_SESSION['glpigroups'] ?? [];
            $access_snapshot = [
                'can_read_public_room' => (bool) Session::haveRight('plugin_glpichat_public', READ),
                'can_read_internal_room' => (bool) Session::haveRight('plugin_glpichat_internal', READ),
                'groups_ids' => array_values(array_unique(array_filter(
                    array_map(
                        static fn ($id): int => (int) $id,
                        is_array($raw_groups_ids) ? $raw_groups_ids : []
                    ),
                    static fn (int $id): bool => $id > 0
                ))),
            ];
            // Channel discovery is read-only with respect to PHP session state,
            // but can traverse a large historical ticket set. Keep the request's
            // authenticated rights/entity snapshot and release the session lock
            // before the database work so unrelated GLPI pages are not convoyed.
            $session_released = glpichat_release_session_lock();
            if ($detailed_diagnostics) {
                glpichat_diagnostic_log('widget_channels', 'session_released', $trace_id, $started_at, [
                    'session_released' => $session_released,
                ]);
            }
            $channels = glpichat_list_user_channels(
                $users_id,
                $tickets_id,
                $access_snapshot,
                static function (string $phase, array $metrics) use (
                    $trace_id,
                    $started_at,
                    $detailed_diagnostics,
                    &$channel_diagnostic_metrics,
                    &$last_completed_phase
                ): void {
                    $channel_diagnostic_metrics = array_merge($channel_diagnostic_metrics, $metrics);
                    $last_completed_phase = $phase;
                    if ($detailed_diagnostics) {
                        glpichat_diagnostic_log(
                            'widget_channels',
                            $phase,
                            $trace_id,
                            $started_at,
                            $metrics
                        );
                    }
                }
            );

            $response = new JsonResponse([
                'channels' => $channels,
                'current_user_id' => $users_id,
                '_glpi_csrf_token' => $csrf_token,
                '_glpichat_trace_id' => $trace_id,
            ]);
            glpichat_diagnostic_log('widget_channels', 'complete', $trace_id, $started_at, array_merge(
                $channel_diagnostic_metrics,
                [
                    'channels' => count($channels),
                    'http_status' => 200,
                    'outcome' => 'ok',
                    'session_released' => $session_released,
                    'last_phase' => $last_completed_phase,
                ]
            ));

            return glpichat_diagnostic_response($response, $trace_id, $started_at);
        } catch (RuntimeException $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_channels', 'runtime_error', $trace_id, $started_at, array_merge(
                $channel_diagnostic_metrics,
                [
                    'http_status' => 400,
                    'outcome' => 'rejected',
                    'exception_class' => $e::class,
                    'exception_code' => $e->getCode(),
                    'last_phase' => $last_completed_phase,
                ]
            ));

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], 400), $trace_id, $started_at);
        } catch (Throwable $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_channels', 'runtime_error', $trace_id, $started_at, array_merge(
                $channel_diagnostic_metrics,
                [
                    'http_status' => 500,
                    'outcome' => 'runtime_error',
                    'exception_class' => $e::class,
                    'exception_code' => $e->getCode(),
                    'last_phase' => $last_completed_phase,
                ]
            ));

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => 'Falha interna ao carregar os canais do chat.',
                '_glpichat_trace_id' => $trace_id,
            ], 500), $trace_id, $started_at);
        }
    }

    #[Route('/Widget/Poll', name: 'glpichat_widget_poll', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function poll(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));
        $requested_channels = 0;
        $channel_errors = 0;
        $status = 500;
        $outcome = 'runtime_error';
        $session_released = false;

        try {
            $input = $request->request->all();
            glpichat_require_logged_csrf($input);
            $users_id = glpichat_current_user_id();
            $submitted_channels = $request->request->all('channels');
            $requested_channels = count($submitted_channels);
            $max_channels = max(1, min(50, glpichat_config_int('poll_max_channels', 20)));
            $channels = array_slice($submitted_channels, 0, $max_channels);

            // Complete every session-dependent ACL decision before release.
            // The much larger message/event/read-state hydration phase then runs
            // without serializing other requests from this authenticated user.
            $authorized_channels = [];
            foreach ($channels as $channel) {
                try {
                    $tickets_id = (int) ($channel['tickets_id'] ?? 0);
                    $room_type = (string) ($channel['room_type'] ?? '');
                    $after_id = (int) ($channel['after_id'] ?? 0);
                    $after_event_id = (string) ($channel['after_event_id'] ?? '');
                    $is_typing = (bool) ($channel['is_typing'] ?? false);
                    if ($tickets_id <= 0 || !in_array($room_type, ['public', 'internal'], true)) {
                        continue;
                    }

                    glpichat_assert_can_read_room($tickets_id, $room_type);
                    $authorized_channels[] = [
                        'tickets_id' => $tickets_id,
                        'room_type' => $room_type,
                        'after_id' => $after_id,
                        'after_event_id' => $after_event_id,
                        'is_typing' => $is_typing,
                    ];
                } catch (RuntimeException $channel_error) {
                    $channel_errors++;
                    continue;
                }
            }

            $csrf_token = Session::getNewCSRFToken();
            $session_released = glpichat_release_session_lock();

            $result = [];
            foreach ($authorized_channels as $channel) {
                try {
                    $tickets_id = (int) $channel['tickets_id'];
                    $room_type = (string) $channel['room_type'];
                    $after_id = (int) $channel['after_id'];
                    $after_event_id = (string) $channel['after_event_id'];
                    $is_typing = (bool) $channel['is_typing'];
                    $rooms_id = glpichat_room_id($tickets_id, $room_type);
                    $participants_id = glpichat_participant_id_for_user($rooms_id, $users_id, false);
                    if ($participants_id > 0) {
                        glpichat_update_participant_activity($participants_id, $is_typing);
                    }
                    $messages = glpichat_messages($rooms_id, $after_id);
                    $events = glpichat_events($rooms_id, $after_event_id);
                    $typing_names = glpichat_get_typing_participants($rooms_id, $participants_id);

                    $last_event_id = count($events) > 0
                        ? (string) ($events[count($events) - 1]['id'] ?? '')
                        : $after_event_id;

                    $key = $tickets_id . ':' . $room_type;
                    $result[$key] = [
                        'rooms_id' => $rooms_id,
                        'tickets_id' => $tickets_id,
                        'room_type' => $room_type,
                        'messages' => $messages,
                        'events' => $events,
                        'ticket_status' => glpichat_ticket_status($tickets_id),
                        'last_message_id' => glpichat_room_last_message_id($rooms_id),
                        'last_event_id' => $last_event_id,
                        'participants_id' => $participants_id,
                        'unread_count' => glpichat_unread_count($rooms_id, $participants_id),
                        'typing_names' => $typing_names,
                    ];
                } catch (RuntimeException $channel_error) {
                    $channel_errors++;
                    continue;
                }
            }

            $status = 200;
            $outcome = 'ok';
            $response = new JsonResponse([
                'channels' => $result,
                'server_time' => date('Y-m-d H:i:s'),
                '_glpi_csrf_token' => $csrf_token,
                '_glpichat_trace_id' => $trace_id,
            ]);
        } catch (RuntimeException $e) {
            $status = 400;
            $outcome = 'rejected';
            $response = new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], $status);
        } catch (Throwable $e) {
            $status = 500;
            $outcome = 'runtime_error';
            $response = new JsonResponse([
                'error' => 'Falha interna durante a atualização do chat.',
                '_glpichat_trace_id' => $trace_id,
            ], $status);
        }

        glpichat_release_session_lock();

        if (
            glpichat_diagnostic_elapsed_ms($started_at) >= 250.0
            || $status >= 400
            || $channel_errors > 0
        ) {
            $metrics = [
                'requested_channels' => $requested_channels,
                'returned_channels' => isset($result) ? count($result) : 0,
                'channel_errors' => $channel_errors,
                'http_status' => $status,
                'outcome' => $outcome,
                'session_released' => $session_released,
            ];
            if (isset($e)) {
                $metrics['exception_class'] = $e::class;
                $metrics['exception_code'] = $e->getCode();
            }
            glpichat_diagnostic_log(
                'widget_poll',
                $status >= 400 ? 'runtime_error' : 'complete',
                $trace_id,
                $started_at,
                $metrics
            );
        }

        return glpichat_diagnostic_response($response, $trace_id, $started_at);
    }

    #[Route('/Widget/History', name: 'glpichat_widget_history', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function history(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));
        try {
            Session::checkLoginUser();
            $rooms_id = $request->query->getInt('rooms_id');
            $before_id = $request->query->getInt('before_id');
            $history_default = max(1, min(100, glpichat_config_int('history_page_default', 30)));
            $history_max = max(1, min(200, glpichat_config_int('history_page_max', 50)));
            $limit = max(1, min($history_max, $request->query->getInt('limit') ?: $history_default));
            if ($rooms_id <= 0) {
                throw new RuntimeException('Parâmetros de histórico inválidos.');
            }

            $users_id = glpichat_current_user_id();
            glpichat_widget_readable_room_or_fail(
                $rooms_id,
                'glpichat_room_by_id',
                'glpichat_assert_can_read_room'
            );
            $session_released = glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_history', 'session_released', $trace_id, $started_at, [
                'session_released' => $session_released,
            ]);

            $participants_id = glpichat_participant_id_for_user($rooms_id, $users_id, false);
            if ($participants_id > 0) {
                glpichat_update_participant_activity($participants_id, false);
            }
            glpichat_diagnostic_log('widget_history', 'participant_ready', $trace_id, $started_at);

            $messages = glpichat_messages_before($rooms_id, $before_id, $limit);
            glpichat_diagnostic_log('widget_history', 'messages_ready', $trace_id, $started_at, [
                'messages' => count($messages),
            ]);

            $events = [];
            if ($before_id === 0) {
                $events = glpichat_events($rooms_id, '');
            }
            glpichat_diagnostic_log('widget_history', 'events_ready', $trace_id, $started_at, [
                'events' => count($events),
            ]);

            $response = new JsonResponse([
                'messages' => $messages,
                'events'   => $events,
                '_glpichat_trace_id' => $trace_id,
            ]);
            glpichat_diagnostic_log('widget_history', 'complete', $trace_id, $started_at, [
                'messages' => count($messages),
                'events' => count($events),
                'http_status' => 200,
                'outcome' => 'ok',
            ]);

            return glpichat_diagnostic_response($response, $trace_id, $started_at);
        } catch (RuntimeException $e) {
            $status = $e->getCode() === 403 ? 403 : 400;
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_history', 'runtime_error', $trace_id, $started_at, [
                'http_status' => $status,
                'outcome' => 'rejected',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], $status), $trace_id, $started_at);
        } catch (Throwable $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_history', 'runtime_error', $trace_id, $started_at, [
                'http_status' => 500,
                'outcome' => 'runtime_error',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => 'Falha interna ao carregar o histórico do chat.',
                '_glpichat_trace_id' => $trace_id,
            ], 500), $trace_id, $started_at);
        }
    }

    #[Route('/Widget/MarkRead', name: 'glpichat_widget_mark_read', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function markRead(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));

        try {
            $input = $request->request->all();
            glpichat_require_logged_csrf($input);
            $users_id = glpichat_current_user_id();

            $rooms_id = $request->request->getInt('rooms_id');
            $last_read_message_id = $request->request->getInt('last_read_message_id');
            if ($rooms_id <= 0 || $last_read_message_id < 0) {
                throw new RuntimeException('Parâmetros de leitura inválidos.');
            }

            glpichat_widget_readable_room_or_fail(
                $rooms_id,
                'glpichat_room_by_id',
                'glpichat_assert_can_read_room'
            );
            $csrf_token = Session::getNewCSRFToken();
            glpichat_release_session_lock();

            $participants_id = glpichat_participant_id_for_user($rooms_id, $users_id, false);
            $persisted_last_read_message_id = glpichat_mark_read($rooms_id, $participants_id, $last_read_message_id);
            $unread_count = glpichat_unread_count($rooms_id, $participants_id);

            $response = new JsonResponse([
                'ok' => true,
                'last_read_message_id' => $persisted_last_read_message_id,
                'unread_count' => $unread_count,
                '_glpi_csrf_token' => $csrf_token,
                '_glpichat_trace_id' => $trace_id,
            ]);

            if (glpichat_diagnostic_elapsed_ms($started_at) >= 250.0) {
                glpichat_diagnostic_log('widget_mark_read', 'complete', $trace_id, $started_at, [
                    'http_status' => 200,
                    'outcome' => 'ok',
                ]);
            }

            return glpichat_diagnostic_response($response, $trace_id, $started_at);
        } catch (RuntimeException $e) {
            $status = $e->getCode() === 403 ? 403 : 400;
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_mark_read', 'runtime_error', $trace_id, $started_at, [
                'http_status' => $status,
                'outcome' => 'rejected',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], $status), $trace_id, $started_at);
        } catch (Throwable $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_mark_read', 'runtime_error', $trace_id, $started_at, [
                'http_status' => 500,
                'outcome' => 'runtime_error',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => 'Falha interna ao atualizar a leitura do chat.',
                '_glpichat_trace_id' => $trace_id,
            ], 500), $trace_id, $started_at);
        }
    }

    #[Route('/Widget/Config', name: 'glpichat_widget_config', methods: ['GET'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function config(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));
        $session_released = false;

        try {
            Session::checkLoginUser();
            $csrf_token = Session::getNewCSRFToken();
            $session_released = glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_config', 'session_released', $trace_id, $started_at, [
                'session_released' => $session_released,
            ]);

            $valid_positions = ['bottom-right', 'bottom-left', 'top-left', 'top-right'];
            $raw_position = (string) \Config::getConfigurationValue('plugin:glpichat', 'widget_default_position');
            $widget_default_position = in_array($raw_position, $valid_positions, true) ? $raw_position : 'bottom-right';

            $response = new JsonResponse([
                'poll_focused_ms'            => glpichat_config_int('poll_focused_ms', 2500),
                'poll_idle_ms'               => glpichat_config_int('poll_idle_ms', 9000),
                'poll_bg_ms'                 => glpichat_config_int('poll_bg_ms', 18000),
                'meta_sync_ms'               => glpichat_config_int('meta_sync_ms', 15000),
                'invite_poll_ms'             => glpichat_config_int('invite_poll_ms', 10000),
                'desktop_max_open'           => glpichat_config_int('desktop_max_open', 3),
                'widget_default_position'    => $widget_default_position,
                'typing_indicator_timeout_ms' => glpichat_config_int('typing_indicator_timeout_ms', 3000),
                'auto_open_ticket_chat'      => glpichat_config_bool('auto_open_ticket_chat', true),
                'auto_scroll_threshold_px'   => glpichat_config_int('auto_scroll_threshold_px', 160),
                'history_page_default'       => glpichat_config_int('history_page_default', 30),
                'history_page_max'           => glpichat_config_int('history_page_max', 50),
                '_glpi_csrf_token'           => $csrf_token,
                '_glpichat_trace_id'         => $trace_id,
            ]);
            glpichat_diagnostic_log('widget_config', 'config_ready', $trace_id, $started_at);
            glpichat_diagnostic_log('widget_config', 'complete', $trace_id, $started_at, [
                'http_status' => 200,
                'outcome' => 'ok',
                'session_released' => $session_released,
            ]);

            return glpichat_diagnostic_response($response, $trace_id, $started_at);
        } catch (RuntimeException $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_config', 'runtime_error', $trace_id, $started_at, [
                'http_status' => 400,
                'outcome' => 'rejected',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
                'session_released' => $session_released,
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], 400), $trace_id, $started_at);
        } catch (Throwable $e) {
            glpichat_release_session_lock();
            glpichat_diagnostic_log('widget_config', 'runtime_error', $trace_id, $started_at, [
                'http_status' => 500,
                'outcome' => 'runtime_error',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
                'session_released' => $session_released,
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => 'Falha interna ao carregar a configuração do chat.',
                '_glpichat_trace_id' => $trace_id,
            ], 500), $trace_id, $started_at);
        }
    }

    #[Route('/Widget/Leave', name: 'glpichat_widget_leave', methods: ['POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    public function leave(Request $request): Response
    {
        $started_at = glpichat_diagnostic_started_at();
        $trace_id = glpichat_diagnostic_trace_id($request->headers->get('X-Glpichat-Trace-Id'));
        $session_released = false;
        $last_phase = 'start';
        glpichat_diagnostic_log('widget_leave', 'start', $trace_id, $started_at);

        try {
            $input = $request->request->all();
            glpichat_require_logged_csrf($input);
            $users_id = glpichat_current_user_id();

            $rooms_id = $request->request->getInt('rooms_id');
            if ($rooms_id <= 0) {
                throw new RuntimeException('Parâmetro de sala inválido.');
            }

            glpichat_widget_readable_room_or_fail(
                $rooms_id,
                'glpichat_room_by_id',
                'glpichat_assert_can_read_room'
            );

            // Session-backed authentication, ACL and response-token work must
            // be complete before releasing the write lock. The disconnect
            // path can synchronously raise GLPI events/notifications and must
            // never convoy an unrelated page request from the same user.
            $csrf_token = Session::getNewCSRFToken();
            $last_phase = 'authorized';
            glpichat_diagnostic_log('widget_leave', 'authorized', $trace_id, $started_at);

            $session_released = glpichat_release_session_lock();
            $last_phase = 'session_released';
            glpichat_diagnostic_log('widget_leave', 'session_released', $trace_id, $started_at, [
                'session_released' => $session_released,
            ]);

            $last_phase = 'disconnect_started';
            glpichat_diagnostic_log('widget_leave', 'disconnect_started', $trace_id, $started_at, [
                'session_released' => $session_released,
            ]);
            glpichat_disconnect_user_participant(
                $rooms_id,
                $users_id,
                static function (string $phase) use (
                    $trace_id,
                    $started_at,
                    $session_released,
                    &$last_phase
                ): void {
                    $last_phase = $phase;
                    glpichat_diagnostic_log('widget_leave', $phase, $trace_id, $started_at, [
                        'session_released' => $session_released,
                    ]);
                }
            );

            $last_phase = 'disconnect_complete';
            glpichat_diagnostic_log('widget_leave', 'disconnect_complete', $trace_id, $started_at, [
                'session_released' => $session_released,
            ]);

            $response = new JsonResponse([
                'ok' => true,
                '_glpi_csrf_token' => $csrf_token,
                '_glpichat_trace_id' => $trace_id,
            ]);
            glpichat_diagnostic_log('widget_leave', 'complete', $trace_id, $started_at, [
                'http_status' => 200,
                'outcome' => 'ok',
                'session_released' => $session_released,
                'last_phase' => $last_phase,
            ]);

            return glpichat_diagnostic_response($response, $trace_id, $started_at);
        } catch (RuntimeException $e) {
            $released_on_error = glpichat_release_session_lock();
            $session_released = $session_released || $released_on_error;
            $status = $e->getCode() === 403 ? 403 : 400;
            glpichat_diagnostic_log('widget_leave', 'runtime_error', $trace_id, $started_at, [
                'http_status' => $status,
                'outcome' => 'rejected',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
                'session_released' => $session_released,
                'last_phase' => $last_phase,
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => $e->getMessage(),
                '_glpichat_trace_id' => $trace_id,
            ], $status), $trace_id, $started_at);
        } catch (Throwable $e) {
            $released_on_error = glpichat_release_session_lock();
            $session_released = $session_released || $released_on_error;
            glpichat_diagnostic_log('widget_leave', 'runtime_error', $trace_id, $started_at, [
                'http_status' => 500,
                'outcome' => 'runtime_error',
                'exception_class' => $e::class,
                'exception_code' => $e->getCode(),
                'session_released' => $session_released,
                'last_phase' => $last_phase,
            ]);

            return glpichat_diagnostic_response(new JsonResponse([
                'error' => 'Falha interna ao encerrar a presença no chat.',
                '_glpichat_trace_id' => $trace_id,
            ], 500), $trace_id, $started_at);
        }
    }
}
