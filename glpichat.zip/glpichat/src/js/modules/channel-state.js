import { normalizeEventCursor } from "./shared.js";

const latestEventCursor = (currentValue, nextValue) => {
  const currentCursor = normalizeEventCursor(currentValue);
  const nextCursor = normalizeEventCursor(nextValue);

  if (currentCursor === "") {
    return nextCursor;
  }
  if (nextCursor === "") {
    return currentCursor;
  }

  return currentCursor.localeCompare(nextCursor) >= 0
    ? currentCursor
    : nextCursor;
};

/**
 * Merge server-owned channel metadata without replacing the canonical object
 * or erasing transient hydration state.
 *
 * History loaders retain references across awaits. Replacing the object while
 * a request is queued or active detaches the eventual History response from
 * the object rendered by the widget. This helper deliberately mutates an
 * existing object so those references remain canonical.
 */
export const mergeChannelMetadata = (existing, payload) => {
  const channel = existing && typeof existing === "object" ? existing : {};
  const isNew = !existing || typeof existing !== "object";

  const messages = Array.isArray(channel.messages) ? channel.messages : [];
  const events = Array.isArray(channel.events) ? channel.events : [];
  const lastMessageId = messages.length > 0
    ? Number(messages.at(-1)?.id || channel.last_message_id || 0)
    : Number(channel.last_message_id || 0);
  const lastEventId = latestEventCursor(
    channel.last_event_id,
    payload?.last_event_id
  );
  const unreadCount = Object.prototype.hasOwnProperty.call(payload || {}, "unread_count")
    ? Number(payload.unread_count || 0)
    : Number(channel.unread_count || 0);

  const localState = {
    messages,
    events,
    messages_loaded: Boolean(channel.messages_loaded || false),
    history_loading: Boolean(channel.history_loading || false),
    history_slow: Boolean(channel.history_slow || false),
    history_failed: Boolean(channel.history_failed || false),
    history_error: channel.history_error || null,
    history_trace_id: String(channel.history_trace_id || ""),
    history_attempt: Number(channel.history_attempt || 0),
    older_loading: Boolean(channel.older_loading || false),
    renderedMessageIds: channel.renderedMessageIds,
    renderedMessageIdsOrder: channel.renderedMessageIdsOrder,
  };

  Object.assign(channel, payload || {});
  Object.assign(channel, localState, {
    last_message_id: isNew ? 0 : lastMessageId,
    last_event_id: lastEventId,
    unread_count: unreadCount,
  });

  return channel;
};
