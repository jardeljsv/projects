/**
 * Return whether the browser currently has at least one open Chat ticket.
 *
 * Kept as a small pure helper so the idle-poll admission rule can be tested
 * without bootstrapping the complete GLPI widget DOM.
 */
export const hasOpenChatTickets = (openTicketIds) => (
  Array.isArray(openTicketIds) && openTicketIds.length > 0
);

/**
 * Run an asynchronous operation with one active execution and at most one
 * coalesced successor. Calls made while work is active share the same promise;
 * they request a single follow-up pass instead of creating an unbounded queue.
 *
 * This deliberately does not add deadlines, cancellation or request priority.
 * The caller retains the baseline error and ordering semantics.
 */
export const createCoalescedSingleFlight = (operation) => {
  if (typeof operation !== "function") {
    throw new TypeError("A single-flight operation function is required.");
  }

  let activePromise = null;
  let successorRequested = false;
  let successorCommitted = false;

  return () => {
    if (activePromise !== null) {
      // One call arriving during the first run requests one successor. Calls
      // arriving after that successor has been committed (including while it
      // is running) are represented by the same successor and cannot extend
      // this promise into an unbounded chain.
      if (!successorCommitted) {
        successorRequested = true;
      }
      return activePromise;
    }

    activePromise = (async () => {
      try {
        let result = await operation();

        if (successorRequested) {
          successorRequested = false;
          successorCommitted = true;
          result = await operation();
        }

        return result;
      } finally {
        activePromise = null;
        successorRequested = false;
        successorCommitted = false;
      }
    })();

    return activePromise;
  };
};

/**
 * Run exactly one copy of an asynchronous operation at a time.
 *
 * Unlike createCoalescedSingleFlight(), calls received while the operation is
 * active do not request a successor. Every concurrent caller receives the
 * exact active Promise. This is used by Channels discovery so a click, a
 * metadata tick and an automatic retry cannot build a second expensive scan
 * behind one that is already running.
 */
export const createExactSingleFlight = (operation) => {
  if (typeof operation !== "function") {
    throw new TypeError("An exact single-flight operation function is required.");
  }

  let activePromise = null;

  const run = (...args) => {
    if (activePromise !== null) {
      return activePromise;
    }

    let currentPromise;
    try {
      currentPromise = Promise.resolve(operation(...args));
    } catch (error) {
      currentPromise = Promise.reject(error);
    }
    activePromise = currentPromise;

    // Observe settlement without replacing the Promise returned to callers;
    // exact object identity is part of the single-flight contract.
    currentPromise.finally(() => {
      if (activePromise === currentPromise) {
        activePromise = null;
      }
    }).catch(() => {});

    return currentPromise;
  };

  run.hasActive = () => activePromise !== null;

  return run;
};

/**
 * Channels may retry only failures which can reasonably recover without a
 * user/session change. Protocol, authentication and authorization failures
 * intentionally return false.
 */
export const isTransientChannelsError = (error) => {
  const status = Number(error?.status || 0);
  const kind = String(error?.kind || "");

  return kind === "network_error" || status === 502 || status === 503 || status === 504;
};

/**
 * Deterministic exponential retry delay. The first retry waits 30 seconds and
 * subsequent failures back off to a five-minute ceiling.
 */
export const channelsRetryDelayMs = (
  attempt,
  baseDelayMs = 30000,
  maximumDelayMs = 300000
) => {
  const safeAttempt = Math.max(1, Math.floor(Number(attempt) || 1));
  const safeBase = Math.max(1, Math.floor(Number(baseDelayMs) || 30000));
  const safeMaximum = Math.max(safeBase, Math.floor(Number(maximumDelayMs) || 300000));
  const multiplier = 2 ** Math.min(10, safeAttempt - 1);

  return Math.min(safeMaximum, safeBase * multiplier);
};

/**
 * Run at most one asynchronous operation for each key. Concurrent callers for
 * the same key receive the exact same promise; different keys remain
 * independent. Settled entries are removed so a later explicit retry is
 * possible.
 */
export const createKeyedSingleFlight = (operation) => {
  if (typeof operation !== "function") {
    throw new TypeError("A keyed single-flight operation function is required.");
  }

  const activeByKey = new Map();

  const run = (key, ...args) => {
    const normalizedKey = String(key || "");
    if (normalizedKey === "") {
      return Promise.reject(new TypeError("A non-empty operation key is required."));
    }

    if (activeByKey.has(normalizedKey)) {
      return activeByKey.get(normalizedKey);
    }

    let activePromise;
    activePromise = Promise.resolve()
      .then(() => operation(normalizedKey, ...args))
      .finally(() => {
        if (activeByKey.get(normalizedKey) === activePromise) {
          activeByKey.delete(normalizedKey);
        }
      });

    activeByKey.set(normalizedKey, activePromise);
    return activePromise;
  };

  run.has = (key) => activeByKey.has(String(key || ""));
  run.size = () => activeByKey.size;

  return run;
};
