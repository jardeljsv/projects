# Frontend — Widget de Chat

> **Audiência:** Desenvolvedor
> **Relacionado:** [Índice de Documentação Técnica](../../README.md)

## O que é

Implementação do widget de chat flutuante do GLPI Chat, construído em JavaScript ES6 modular (sem framework), injetado dinamicamente no `<body>` do GLPI e integrado visualmente às variáveis CSS nativas do Tabler.

## Estrutura

### Arquivos principais

| Arquivo | Responsabilidade |
|---------|-----------------|
| `public/js/glpichat-widget.js` | Bundle para usuários autenticados — polling, múltiplos chatboxes, dock |
| `public/js/glpichat-guest.js` | Bundle para convidados externos — fluxo simplificado, canal único |
| `public/css/glpichat.css` | Estilos do widget — usa variáveis CSS do Tabler |

### Módulos ES6 compartilhados (`src/js/modules/`)

| Módulo | Responsabilidade |
|--------|-----------------|
| `constants.js` | Constantes de tempo (intervalos de polling), limites de canais, chaves de localStorage |
| `state.js` | Estado global centralizado (`Map` de canais, `Set` de tickets fechados, CSRF, IDs ativos) |
| `dom.js` | Criação e manipulação do DOM do widget — `createShell()`, `createChatbox()`, `renderMessage()` |
| `sanitize.js` | Sanitização de conteúdo exibido no DOM — usa `textContent` em vez de `innerHTML` onde possível |
| `http.js` | Pipeline HTTP preservado para o bundle Guest |
| `widget-http.js` | Fila serializada do widget autenticado, correlação opaca, aviso de lentidão e expiração apenas antes do despacho |
| `channel-state.js` | Merge de metadados sem trocar a identidade do objeto canônico durante a hidratação |
| `scheduler.js` | Single-flight/coalescimento de History, Poll e Channels |
| `format.js` | Formatação de datas, nomes, previews de mensagem e badges de contagem |

### Estrutura DOM do widget

```
div.glpichat-widget
├── div.glpichat-dock [data-role="dock"]
│   ├── div.glpichat-chatbox (uma por chamado aberto)
│   │   ├── div.glpichat-chatbox-panel
│   │   │   ├── div.glpichat-dropzone-overlay
│   │   │   ├── div.glpichat-window-head
│   │   │   ├── div.glpichat-tabs
│   │   │   ├── div.glpichat-messages
│   │   │   └── form.glpichat-send
│   │   └── button.glpichat-chatbox-tab
│   └── div.glpichat-chatbox.glpichat-launcher [data-role="launcher"]
│       ├── div.glpichat-chatbox-panel [data-role="launcher-panel"]
│       └── button.glpichat-chatbox-tab [data-role="launcher-tab"]
└── div.glpichat-lightbox [data-role="lightbox"]
    └── img.glpichat-lightbox-img
```

### Estado centralizado (`state.js`)

| Campo | Tipo | O que armazena |
|-------|------|---------------|
| `csrf` | `string` | Token CSRF ativo — atualizado a cada resposta de polling |
| `currentUserId` | `number` | ID do usuário logado no GLPI |
| `activeTicketId` | `number` | ID do chamado aberto na página atual do GLPI |
| `channels` | `Map` | Metadados por sala: mensagens carregadas, last_id, unread_count, estados de loading |
| `tickets` | `Map` | Lista de chamados conhecidos pelo widget |
| `openTicketIds` | `Array` | IDs dos chatboxes abertos no dock |
| `closedTicketIds` | `Set` | Chamados fechados manualmente pelo usuário nesta sessão |
| `manualTicketIds` | `Set` | Chamados abertos via clique explícito do usuário |
| `transientTicketIds` | `Set` | Chamados abertos automaticamente pela página atual |
| `pollTimer` | `number` | Timer ID do loop de polling de mensagens |
| `metaTimer` | `number` | Timer ID do loop de sincronização de metadados |
| `launcherOpen` | `boolean` | Se o drawer de lista de chamados está expandido |

## Comunicação com o backend

O protocolo de polling está documentado em detalhes em [flows/polling.md](../flows/polling.md). Em resumo:

- `GET /Widget/Channels` — metadados da lista de conversas (a cada 15s)
- `GET /Widget/History` — carga inicial/paginada de mensagens e eventos
- `POST /Widget/Poll` — delta de mensagens e eventos dos chatboxes abertos (2,5s / 9s / 18s)
- `POST /Widget/MarkRead` — persistência do cursor de leitura
- `POST /Widget/Leave` — saída voluntária de uma sala
- `GET /Guest/Sync` — polling simplificado para convidados

As respostas que renovam CSRF retornam `_glpi_csrf_token`, armazenado em `state.csrf`. O pipeline HTTP injeta o token em cada POST automaticamente. No widget autenticado, cada requisição recebe `X-Glpichat-Trace-Id`; History, Channels, Poll e MarkRead também devolvem a referência e `Server-Timing` quando processados pelo candidato perf2.

Falhas intermitentes de Poll continuam sem modal. A hidratação inicial é diferente: após 8s ela mostra estado de lentidão; falhas HTTP/rede/protocolo exibem uma referência e botão de retry. O composer fica bloqueado até a sala terminar de carregar. Uma requisição History ativa não é abortada; somente uma History ainda parada na fila pode expirar antes de alcançar o servidor.

### Otimistic updates

Ao enviar uma mensagem, o widget injeta o elemento na tela imediatamente com classe `is-optimistic` e opacidade reduzida antes da resposta do servidor. Se a requisição falhar, o elemento é removido e o conteúdo devolvido ao textarea.

### Persistência via localStorage

O estado de quais chatboxes estão abertos é salvo em `localStorage` na chave `glpichat_widget_ui`. Ao recarregar a página, o widget restaura os chatboxes que estavam abertos como `manualTicketIds`.

## Restrições do GLPI

- **Não usar cores hardcodadas.** Usar exclusivamente variáveis CSS do Tabler: `--tblr-bg-surface`, `--tblr-border-color`, `--tblr-border-color-translucent`, `--tblr-body-color`. O widget deve mudar de tema (Claro/Escuro) automaticamente.
- **Não importar Bootstrap, jQuery ou Tabler CSS.** O GLPI 11.x já carrega essas bibliotecas globalmente. Duplicar causa conflitos de versão e aumenta o tempo de carregamento.
- **Não usar `innerHTML` com dados externos.** O módulo `sanitize.js` existe exatamente para isso — usar `textContent` ou a função de sanitização antes de qualquer inserção de conteúdo de mensagem no DOM.
- **Não usar `document.cookie` no JavaScript do widget.** Cookies de sessão do convidado têm flag `HttpOnly` e não são acessíveis via JS — o backend gerencia a sessão via cookie.

### Cálculo de margem de rodapé (`safe-bottom`)

O algoritmo `detectBottomObstruction()` escaneia elementos `fixed`/`sticky` na parte inferior do viewport (largura mínima 220px) e define `--glpichat-safe-bottom` no `:root`. O CSS do dock usa essa variável como `bottom`. Isso evita sobreposição com barras de outros plugins.

### Responsividade

- **Desktop:** máximo de 3 chatboxes simultâneos no dock.
- **Mobile (≤ 980px):** máximo de 1 chatbox. Chatboxes excedentes são ocultados sem serem fechados.

## Riscos e pontos de atenção

**localStorage pode ser limpo pelo usuário.** Se o usuário limpar dados do navegador, `glpichat_widget_ui` é perdido e os chatboxes não são restaurados ao recarregar. O widget abre vazio — comportamento esperado, não um bug.

**Limite de 3 chatboxes não é enforçado no backend.** O limite é apenas visual e de estado no cliente. Poll usa `poll_max_channels` (padrão 20) e um teto absoluto de 50 entradas brutas por requisição. Um usuário com JS modificado pode abrir mais de 3.

**Mobile: o chatbox único oculta os demais, não os fecha.** Os chatboxes excedentes permanecem em `openTicketIds` — apenas são ocultados via CSS. Se o usuário girar o dispositivo para landscape e a largura ultrapassar 980px, os chatboxes ocultos reaparecem.

**Animações CSS dependem da classe `.is-new`.** Se o polling retornar mensagens antigas (ex: após reconexão com `after_id` muito baixo), todas elas receberão `.is-new` e dispararão a animação de entrada. Isso pode acontecer se o estado local for perdido (ex: `localStorage` limpo entre sessões).

**Uma History ativa não tem deadline destrutivo.** Após 8s o skeleton ganha diagnóstico e as atualizações automáticas são pausadas, mas a chamada continua ativa para evitar que o navegador libere a fila enquanto o PHP ainda trabalha. A tela muda para erro/retry apenas quando há falha observável ou quando a solicitação expira antes do despacho.

**A referência não contém identidade.** O trace é aleatório e não inclui usuário, chamado, sala, conteúdo, email, IP, token ou mensagem bruta de exceção. O log físico pode receber prefixos próprios do logger do GLPI e deve ser inspecionado no laboratório.

<br>

<p align="center">
  <sub>━━━━━━━━━━━━━━━━━━━━━━━</sub><br>
  <sub>Curtiu o plugin? Deixe uma ⭐ no repositório para ajudar outros administradores a encontrá-lo.</sub><br>
  <sub>Desenvolvido e mantido com apoio de <a href="https://www.forq.com.br/">Forq</a></sub>
</p>
