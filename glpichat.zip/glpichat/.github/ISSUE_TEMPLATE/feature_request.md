---
name: 💡 Sugerir uma funcionalidade
about: Proponha uma melhoria ou nova funcionalidade para o GLPI Chat
title: "[Feature] "
labels: enhancement
assignees: ''
---

## O problema que você quer resolver

Uma descrição clara do problema ou limitação atual. Ex.: "Fico frustrado quando [...]" — foque no problema, não apenas na solução que você já tem em mente.

## Solução proposta

Uma descrição clara do que você gostaria que acontecesse.

## Alternativas consideradas

Outras soluções ou funcionalidades que você considerou, e por que a proposta acima é preferível.

## Área impactada

<!-- Marque as que se aplicam -->

- [ ] Widget de chat (frontend)
- [ ] Gestão de convidados (invites)
- [ ] Notificações
- [ ] Histórico / Auditoria
- [ ] Permissões (Profile Rights)
- [ ] Instalação / configuração
- [ ] Outra: <!-- descreva -->

## Contexto adicional

Qualquer outra informação, screenshot, mockup ou referência que ajude a entender a proposta.

## Checklist

- [ ] Verifiquei que não existe uma issue já aberta com a mesma sugestão.
- [ ] Esta sugestão está relacionada ao comportamento do plugin GLPI Chat (não ao core do GLPI).
