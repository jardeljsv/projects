---
name: 🐛 Reportar um bug
about: Relate um comportamento incorreto ou inesperado do GLPI Chat
title: "[Bug] "
labels: bug
assignees: ''
---

## Descrição do problema

Uma descrição clara e objetiva do que está acontecendo.

## Passos para reproduzir

1. Vá em '...'
2. Clique em '...'
3. Faça '...'
4. Veja o erro

## Comportamento esperado

O que deveria acontecer.

## Comportamento observado

O que de fato acontece (inclua screenshots ou gravações, se ajudar).

## Ambiente

* **Versão do GLPI Chat**: <!-- ver plugin.xml -> <version><num> ou Configurar > Plugins -->
* **Versão do GLPI**: <!-- ex.: 11.0.7 -->
* **Versão do PHP**: <!-- ex.: 8.2 -->
* **Banco de dados**: <!-- MySQL / MariaDB + versão -->
* **Navegador** (se aplicável): <!-- ex.: Chrome 128, Firefox 130 -->
* **Ambiente**: <!-- local / docker / produção -->

## Logs relevantes

<!--
Cole aqui trechos relevantes de log (GLPI, PHP, console do navegador).
IMPORTANTE: remova ou mascare qualquer dado sensível antes de colar
(tokens, senhas, cookies de sessão, e-mails reais, IDs de tickets internos
sensíveis).
-->

```
cole os logs aqui
```

## Contexto adicional

Qualquer outra informação relevante sobre o problema (ex.: só acontece com convidados, só em sala interna, começou após atualizar de X para Y, etc).

## Checklist

- [ ] Verifiquei que não existe uma issue já aberta reportando o mesmo problema.
- [ ] Removi/mascarei dados sensíveis dos logs e screenshots anexados.
