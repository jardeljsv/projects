# GLPIBot

Floating chatbot widget for GLPI with robust offline fallback.

## What it does
- Adds a bottom-right floating chat launcher on every GLPI page.
- Uses an external chatbot API when configured.
- If credentials are missing or a request fails, switches to **no-API mode** and replies **“API desconectada”**, while preserving the in-page chat history (cleared on refresh).
- No database tables; configuration is stored in GLPI’s built-in config (`plugin:glpibot`).

## Configuration (Setup → General)
Fields under the GLPIBot tab:
- `enable_widget` (yes/no)
- `api_base_url` (string)
- `api_key` (string)
- `request_timeout_ms` (integer; default 20000)

## Endpoints
- Health: `/plugins/glpibot/front/health.php`
- Proxy:  `/plugins/glpibot/front/chatproxy.php`

## Deploy (Docker example)
```bash
# From host, copy the folder into the container:
docker cp -r glpibot glpi:/var/www/html/glpi/plugins/

# Then in GLPI → Setup → Plugins, install and enable "GLPIBot".
