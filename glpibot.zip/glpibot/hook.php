<?php

use Config;

function plugin_glpibot_install() {
   Config::setConfigurationValues('plugin:glpibot', [
      'enable_widget'       => 1,
      'api_base_url'        => '',
      'api_key'             => '',
      'request_timeout_ms'  => 20000,
      'allowed_groups'      => ''   // empty = all users
   ]);

   return true;
}

function plugin_glpibot_uninstall() {
   $cfg = new Config();
   $cfg->deleteByCriteria(['context' => 'plugin:glpibot']);
   return true;
}
