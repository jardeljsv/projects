(function () {
  "use strict";

  // ---------- Derive plugin root from this script URL (no hardcoded GLPI base) ----------
  function findThisScriptSrc() {
    if (document.currentScript && document.currentScript.src) {
      return document.currentScript.src;
    }
    var scripts = document.getElementsByTagName("script");
    for (var i = scripts.length - 1; i >= 0; i--) {
      var s = scripts[i];
      if (s && s.src && s.src.indexOf("glpibot/assets/js/widget.js") !== -1) {
        return s.src;
      }
    }
    return "";
  }

  function getPluginRoot() {
    try {
      var src = findThisScriptSrc();
      if (!src) return null;

      src = src.split("#")[0].split("?")[0];
      var u = new URL(src, window.location.href);

      // Stable suffix inside plugin
      var suffix = "/assets/js/widget.js";
      if (u.pathname && u.pathname.slice(-suffix.length) === suffix) {
        var rootPath = u.pathname.slice(0, -suffix.length);
        return u.origin + rootPath;
      }

      // Fallback: trim to ".../glpibot"
      var idx = u.pathname.indexOf("/glpibot/");
      if (idx !== -1) {
        return u.origin + u.pathname.slice(0, idx) + "/glpibot";
      }

      return null;
    } catch (e) {
      return null;
    }
  }

  function join(base, rel) {
    if (!base) return rel;
    return base.replace(/\/+$/, "") + "/" + String(rel).replace(/^\/+/, "");
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  var PLUGIN_ROOT = getPluginRoot();

  var ENDPOINT_HEALTH  = join(PLUGIN_ROOT, "front/health.php");
  var ENDPOINT_PROXY   = join(PLUGIN_ROOT, "front/chatproxy.php");
  var ENDPOINT_ALLOWED = join(PLUGIN_ROOT, "front/allowed.php");

  // ---------- Constants ----------
  var ID_LAUNCHER     = "glpibot-launcher";
  var ID_PANEL        = "glpibot-panel";
  var ID_HEADER       = "glpibot-header";
  var ID_STATUS       = "glpibot-status";
  var ID_BTN_MIN      = "glpibot-minimize";
  var ID_BTN_CLOSE    = "glpibot-closeclear";
  var ID_BTN_ERASE    = "glpibot-erase";
  var ID_MESSAGES     = "glpibot-messages";
  var ID_INPUT        = "glpibot-input";
  var ID_SEND         = "glpibot-send";
  var GLPIBOT_SID_KEY = "glpibot_sid";

  function glpibotGetSid() {
    var s = sessionStorage.getItem(GLPIBOT_SID_KEY);
    if (!s) {
      if (window.crypto && crypto.randomUUID) {
        s = crypto.randomUUID();
      } else {
        s = (Date.now().toString(36) + Math.random().toString(36).slice(2, 10));
      }
      sessionStorage.setItem(GLPIBOT_SID_KEY, s);
    }
    return s;
  }

  function glpibotResetSid() {
    sessionStorage.removeItem(GLPIBOT_SID_KEY);
  }

  var state = {
    isOpen: false,
    isBusy: false,
    mode: "unknown",
    hasHistory: false,
    didHealthCheck: false,
    messages: []
  };

  function getCsrfToken() {
    var input = document.querySelector('input[name="_glpi_csrf_token"]');
    if (input && input.value) return input.value;

    var m = document.cookie.match(/(?:^|;\s*)_glpi_csrf_token=([^;]+)/);
    if (m) return decodeURIComponent(m[1]);

    return null;
  }

  function qs(id) {
    return document.getElementById(id);
  }

  function ensureOnce(id, createFn) {
    var el = qs(id);
    if (!el) {
      el = createFn();
      el.id = id;
      document.body.appendChild(el);
    }
    return el;
  }

  function setStatus(mode) {
    state.mode = mode === "api" ? "api" : "noapi";
    var pill = qs(ID_STATUS);
    if (!pill) return;
    pill.textContent = state.mode === "api" ? "Conectado" : "Offline";
    pill.setAttribute("data-mode", state.mode);
  }

  function setBusy(b) {
    state.isBusy = !!b;
    var input = qs(ID_INPUT);
    var send  = qs(ID_SEND);
    if (input) input.disabled = state.isBusy;
    if (send)  send.disabled  = state.isBusy;
  }

  function markHistoryBadge() {
    state.hasHistory = state.messages.length > 0;
    var launcher = qs(ID_LAUNCHER);
    if (!launcher) return;
    if (state.hasHistory) launcher.setAttribute("data-has-history", "1");
    else launcher.removeAttribute("data-has-history");
  }

  function scrollToBottom() {
    var list = qs(ID_MESSAGES);
    if (list) list.scrollTop = list.scrollHeight;
  }

  function appendMessage(role, text) {
    var list = qs(ID_MESSAGES);
    if (!list) return;

    var item = document.createElement("div");
    item.className = "glpibot-msg " + (role === "user" ? "from-user" : "from-assistant");
    item.textContent = text;

    list.appendChild(item);
    state.messages.push({ role: role, text: text });
    markHistoryBadge();
    scrollToBottom();
  }

  function clearMessages() {
    var list = qs(ID_MESSAGES);
    if (list) list.innerHTML = "";
    state.messages = [];
    markHistoryBadge();
  }

  async function healthCheck() {
    if (state.didHealthCheck) return;
    state.didHealthCheck = true;
    try {
      var res = await fetch(ENDPOINT_HEALTH, {
        method: "GET",
        credentials: "same-origin",
        cache: "no-cache"
      });
      if (!res.ok) throw new Error("health HTTP " + res.status);
      var data = await res.json();
      setStatus(data && data.mode === "api" ? "api" : "noapi");
    } catch (e) {
      setStatus("noapi");
    }
  }

  function destroyWidget() {
    try {
      var panel = qs(ID_PANEL);
      if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
      var launcher = qs(ID_LAUNCHER);
      if (launcher && launcher.parentNode) launcher.parentNode.removeChild(launcher);
    } catch (e) {}
    state.isOpen = false;
    state.isBusy = false;
    state.mode = "unknown";
    state.hasHistory = false;
    state.didHealthCheck = false;
    state.messages = [];
    glpibotResetSid();
  }

  function setGated(gated) {
    var launcher = qs(ID_LAUNCHER);
    var panel = qs(ID_PANEL);
    if (launcher) {
      if (gated) launcher.classList.add("glpibot-gated");
      else launcher.classList.remove("glpibot-gated");
    }
    if (panel) {
      if (gated) panel.classList.add("glpibot-gated");
      else panel.classList.remove("glpibot-gated");
    }
  }

  async function fetchAllowed() {
    if (!PLUGIN_ROOT) return { ok: false };

    var url = ENDPOINT_ALLOWED + (ENDPOINT_ALLOWED.indexOf("?") === -1 ? "?" : "&") + "ts=" + Date.now();

    var res = await fetch(url, {
      method: "GET",
      credentials: "same-origin",
      cache: "no-store"
    });
    if (!res.ok) return { ok: false };

    var data = await res.json();
    return {
      ok: true,
      enabled: !(data && data.enabled === false),
      restricted: !!(data && data.restricted),
      allowed: !!(data && data.allowed),
      uncertain: !!(data && data.uncertain)
    };
  }

  // Permission enforcement:
  // - Hide only on DEFINITIVE deny (restricted=true, allowed=false, uncertain=false).
  // - If uncertain (session/user resolution not reliable), FAIL OPEN (do not hide).
  async function enforceVisibility() {
    setGated(true);

    try {
      var r = await fetchAllowed();

      if (!r.ok) {
        setGated(false); // fail-open
        return;
      }

      if (r.enabled === false) {
        destroyWidget();
        return;
      }

      // Definitive deny => retry once then hide
      if (r.restricted && !r.allowed && !r.uncertain) {
        await sleep(800);
        var r2 = await fetchAllowed();
        if (r2.ok && r2.restricted && !r2.allowed && !r2.uncertain) {
          destroyWidget();
          return;
        }
      }

      // Allowed OR unrestricted OR uncertain => show widget
      setGated(false);
    } catch (e) {
      setGated(false); // fail-open
    }
  }

  async function sendMessage() {
    var input = qs(ID_INPUT);
    if (!input) return;

    var userText = (input.value || "").trim();
    if (!userText || state.isBusy) return;

    appendMessage("user", userText);
    input.value = "";

    if (state.mode !== "api") {
      appendMessage("assistant", "API desconectada");
      return;
    }

    setBusy(true);

    try {
      var payload = {
        sid: glpibotGetSid(),
        prompt: userText,
        top_p: 0.92,
        temperature: 0.85,
        max_len: 128,
        min_len: 4
      };

      var headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
      };

      var token = getCsrfToken();
      if (token) headers["X-Glpi-Csrf-Token"] = token;

      var res = await fetch(ENDPOINT_PROXY, {
        method: "POST",
        headers: headers,
        credentials: "same-origin",
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error("proxy HTTP " + res.status);

      var data = await res.json();
      var reply = (data && typeof data.text === "string") ? data.text : "API desconectada";
      appendMessage("assistant", reply);
    } catch (err) {
      setStatus("noapi");
      appendMessage("assistant", "API desconectada");
    } finally {
      setBusy(false);
    }
  }

  function buildLauncher() {
    return ensureOnce(ID_LAUNCHER, function () {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "glpibot-launcher glpibot-gated";
      btn.title = "Chat";

      var dot = document.createElement("span");
      dot.className = "glpibot-badge";
      btn.appendChild(dot);

      btn.addEventListener("click", togglePanel);
      return btn;
    });
  }

  function buildPanel() {
    return ensureOnce(ID_PANEL, function () {
      var panel = document.createElement("div");
      panel.className = "glpibot-panel glpibot-hidden glpibot-gated";

      // Header
      var header = document.createElement("div");
      header.id = ID_HEADER;
      header.className = "glpibot-header";

      var title = document.createElement("div");
      title.className = "glpibot-title";
      title.textContent = "Chat";

      var status = document.createElement("div");
      status.id = ID_STATUS;
      status.className = "glpibot-status";
      status.textContent = "Offline";
      status.setAttribute("data-mode", "noapi");

      var controls = document.createElement("div");
      controls.className = "glpibot-controls";

      var btnMin = document.createElement("button");
      btnMin.id = ID_BTN_MIN;
      btnMin.className = "glpibot-btn";
      btnMin.type = "button";
      btnMin.setAttribute("aria-label", "Minimizar");
      btnMin.textContent = "–";

      var btnErase = document.createElement("button");
      btnErase.id = ID_BTN_ERASE;
      btnErase.className = "glpibot-btn";
      btnErase.type = "button";
      btnErase.setAttribute("aria-label", "Limpar conversa");
      btnErase.textContent = "E";

      var btnClose = document.createElement("button");
      btnClose.id = ID_BTN_CLOSE;
      btnClose.className = "glpibot-btn";
      btnClose.type = "button";
      btnClose.setAttribute("aria-label", "Fechar e limpar");
      btnClose.textContent = "x";

      controls.appendChild(btnMin);
      controls.appendChild(btnErase);
      controls.appendChild(btnClose);

      header.appendChild(title);
      header.appendChild(status);
      header.appendChild(controls);

      // Messages
      var messages = document.createElement("div");
      messages.id = ID_MESSAGES;
      messages.className = "glpibot-messages";

      // Composer
      var composer = document.createElement("div");
      composer.className = "glpibot-composer";

      var input = document.createElement("input");
      input.id = ID_INPUT;
      input.className = "glpibot-input";
      input.type = "text";
      input.placeholder = "Diga algo…";

      var send = document.createElement("button");
      send.id = ID_SEND;
      send.className = "glpibot-send";
      send.type = "button";
      send.setAttribute("aria-label", "Enviar");
      send.textContent = "→";

      composer.appendChild(input);
      composer.appendChild(send);

      panel.appendChild(header);
      panel.appendChild(messages);
      panel.appendChild(composer);

      // Wire events
      btnMin.addEventListener("click", minimizePanel);
      btnErase.addEventListener("click", function () {
        clearMessages();
        glpibotResetSid();
        input.focus();
      });
      btnClose.addEventListener("click", function () {
        clearMessages();
        glpibotResetSid();
        minimizePanel();
      });
      send.addEventListener("click", sendMessage);
      input.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });

      // ESC to minimize when focused inside
      panel.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
          minimizePanel();
        }
      });

      return panel;
    });
  }

  async function openPanel() {
    var panel = buildPanel();
    var launcher = buildLauncher();

    panel.classList.remove("glpibot-hidden");
    launcher.setAttribute("data-open", "1");
    state.isOpen = true;

    if (!state.didHealthCheck) {
      await healthCheck();
    }

    var input = qs(ID_INPUT);
    if (input) input.focus();
  }

  function minimizePanel() {
    var panel = buildPanel();
    var launcher = buildLauncher();

    panel.classList.add("glpibot-hidden");
    launcher.removeAttribute("data-open");
    state.isOpen = false;
  }

  function togglePanel() {
    if (state.isOpen) minimizePanel();
    else openPanel();
  }

  function boot() {
    if (qs(ID_LAUNCHER)) return;

    buildLauncher();
    buildPanel();

    // Decide visibility after initial render
    enforceVisibility();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
