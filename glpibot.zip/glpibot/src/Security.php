<?php

namespace GlpiPlugin\Glpibot;

use Session;

/**
 * Small, centralized helpers for request safety and input limits.
 * (Kept minimal and side-effect free; use as needed.)
 */
class Security
{
    /**
     * True if the current GLPI session is authenticated.
     */
    public static function isLoggedIn(): bool
    {
        return Session::isLoggedIn();
    }

    /**
     * Ensure a method matches (case-sensitive). Returns bool.
     */
    public static function isMethod(string $method): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? '') === $method;
    }

    /**
     * Basic content-type check for JSON POSTs.
     */
    public static function isJsonRequest(): bool
    {
        $ct = strtolower($_SERVER['CONTENT_TYPE'] ?? '');
        return (strpos($ct, 'application/json') !== false);
    }

    /**
     * Trim and clamp a UTF-8 string to a maximum length (safe for prompts).
     */
    public static function clampUtf8(string $s, int $max): string
    {
        $s = trim($s);
        if ($max > 0 && mb_strlen($s, 'UTF-8') > $max) {
            $s = mb_substr($s, 0, $max, 'UTF-8');
        }
        return $s;
    }
}
