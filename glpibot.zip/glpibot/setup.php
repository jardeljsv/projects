<?php
// plugins/glpibot/setup.php

$autoload = __DIR__ . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

define('PLUGIN_GLPIBOT_VERSION', '0.2.0');

/**
 * Parse allowed_groups stored as:
 *   - JSON: "[1,2,3]"
 *   - CSV:  "1,2,3"
 *   - single: "4"
 * Returns array<int>.
 */
function glpibot_parse_id_list($raw): array {
    $raw = is_string($raw) ? trim($raw) : '';
    if ($raw === '') {
        return [];
    }

    $j = json_decode($raw, true);
    if (is_array($j)) {
        $out = [];
        foreach ($j as $v) {
            $id = (int)$v;
            if ($id > 0) $out[$id] = $id;
        }
        return array_values($out);
    }

    if (preg_match('/^\d+$/', $raw)) {
        $id = (int)$raw;
        return $id > 0 ? [$id] : [];
    }

    $parts = preg_split('/[,\s]+/', $raw);
    if (!is_array($parts)) return [];

    $out = [];
    foreach ($parts as $p) {
        $id = (int)$p;
        if ($id > 0) $out[$id] = $id;
    }
    return array_values($out);
}

/**
 * Try to read group ids from session (fast, no DB, very compatible).
 * Handles different shapes: [1=>...,2=>...] OR [1,2,3] OR ['1'=>'name'] etc.
 */
function glpibot_get_groups_from_session(): array {
    $ids = [];

    if (isset($_SESSION) && is_array($_SESSION) && isset($_SESSION['glpigroups']) && is_array($_SESSION['glpigroups'])) {
        foreach ($_SESSION['glpigroups'] as $k => $v) {
            if (is_numeric($k)) {
                $gid = (int)$k;
                if ($gid > 0) $ids[$gid] = true;
            }
            if (is_numeric($v)) {
                $gid = (int)$v;
                if ($gid > 0) $ids[$gid] = true;
            }
        }
    }

    return array_keys($ids);
}

/**
 * DB fallback for group ids if session doesn't provide them.
 * Uses $DB->request(array) first (GLPI-supported), then query fallback.
 */
function glpibot_get_groups_from_db(int $uid): array {
    $ids = [];

    global $DB;
    if (!isset($DB) || !is_object($DB) || $uid <= 0) {
        return [];
    }

    // Preferred: request(array) (more compatible than request("SQL string"))
    try {
        if (method_exists($DB, 'request')) {
            $it = $DB->request([
                'SELECT' => ['groups_id'],
                'FROM'   => 'glpi_groups_users',
                'WHERE'  => ['users_id' => $uid],
            ]);
            foreach ($it as $row) {
                if (!is_array($row)) continue;
                $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                if ($gid > 0) $ids[$gid] = true;
            }
            return array_keys($ids);
        }
    } catch (Throwable $e) {
        // ignore, fallback below
    }

    // Fallback: raw query if available (older DB wrappers)
    try {
        if (method_exists($DB, 'query')) {
            $res = @$DB->query("SELECT `groups_id` FROM `glpi_groups_users` WHERE `users_id` = " . (int)$uid);
            if ($res) {
                if (method_exists($DB, 'fetchAssoc')) {
                    while ($row = $DB->fetchAssoc($res)) {
                        $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                        if ($gid > 0) $ids[$gid] = true;
                    }
                } elseif (method_exists($DB, 'fetch_assoc')) {
                    while ($row = $DB->fetch_assoc($res)) {
                        $gid = isset($row['groups_id']) ? (int)$row['groups_id'] : 0;
                        if ($gid > 0) $ids[$gid] = true;
                    }
                }
            }
        }
    } catch (Throwable $e) {
        // ignore
    }

    return array_keys($ids);
}

/**
 * Decide whether to inject widget assets for the current request.
 * Fail-open: any exception => inject (prevents bricking GLPI).
 */
function glpibot_should_inject_assets(): bool {
    // Default behavior = inject everywhere (original plugin behavior)
    $inject = true;

    try {
        if (!class_exists('Config') || !method_exists('Config', 'getConfigurationValues')) {
            return true;
        }

        $cfg = Config::getConfigurationValues('plugin:glpibot');

        $enabled = (int)($cfg['enable_widget'] ?? 0);
        if ($enabled !== 1) {
            return false;
        }

        $allowed = glpibot_parse_id_list((string)($cfg['allowed_groups'] ?? ''));
        if (empty($allowed)) {
            return true; // empty = all users
        }

        // Must be logged in
        $uid = 0;
        if (class_exists('Session') && method_exists('Session', 'getLoginUserID')) {
            $uid = (int)Session::getLoginUserID();
        } elseif (isset($_SESSION['glpiID'])) {
            $uid = (int)$_SESSION['glpiID'];
        }

        if ($uid <= 0) {
            return false;
        }

        // Prefer session groups; fallback to DB
        $user_groups = glpibot_get_groups_from_session();
        if (empty($user_groups)) {
            $user_groups = glpibot_get_groups_from_db($uid);
        }

        if (empty($user_groups)) {
            return false;
        }

        $allowmap = [];
        foreach ($allowed as $g) $allowmap[(int)$g] = true;

        foreach ($user_groups as $g) {
            $g = (int)$g;
            if ($g > 0 && isset($allowmap[$g])) {
                return true;
            }
        }

        return false;
    } catch (Throwable $e) {
        // Fail-open to avoid breaking GLPI pages
        $inject = true;
    }

    return $inject;
}

/**
 * Called by GLPI to initialize plugin hooks.
 */
function plugin_init_glpibot() {
    global $PLUGIN_HOOKS;

    // CSRF compliant
    $PLUGIN_HOOKS['csrf_compliant']['glpibot'] = true;

    // Register config tab (original behavior)
    if (class_exists('Plugin')) {
        Plugin::registerClass(\GlpiPlugin\Glpibot\Config::class, [
            'addtabon' => \Config::class
        ]);
    }

    // Conditionally inject assets (group restriction enforced here)
    $inject = glpibot_should_inject_assets();

    if ($inject) {
        $PLUGIN_HOOKS['add_javascript']['glpibot'] = [
            'assets/js/widget.js'
        ];
        $PLUGIN_HOOKS['add_css']['glpibot'] = [
            'assets/css/widget.css'
        ];
    }
}

function plugin_version_glpibot() {
    return [
        'name'     => 'GLPIBot',
        'version'  => PLUGIN_GLPIBOT_VERSION,
        'author'   => 'Artur de Andrade Batista',
        'license'  => 'MIT',
        'homepage' => ''
    ];
}

function plugin_glpibot_check_config($verbose = false) {
    return true;
}
