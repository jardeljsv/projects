<?php
// /plugins/glpibot/front/test_connection.php
// Used by the GLPIBot config page "Test connection" button.
// Does NOT need user session; just checks that the stored credentials
// can successfully call FastAPI /health with Bearer.

header('Content-Type: application/json; charset=UTF-8');

function tc_respond($http, $arr) {
    http_response_code($http);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

// ----- locate GLPI root and db config -----

$root_candidates = [
    dirname(__FILE__, 4),
    dirname(__FILE__, 3)
];
$GLPI_ROOT_DIR = null;
foreach ($root_candidates as $cand) {
    if ($cand
        && is_dir($cand)
        && is_file($cand . '/config/config_db.php')) {
        $GLPI_ROOT_DIR = $cand;
        break;
    }
}
if ($GLPI_ROOT_DIR === null) {
    tc_respond(500, ['ok' => false, 'reason' => 'no_glpi_root']);
}

$config_path = $GLPI_ROOT_DIR . '/config/config_db.php';

// ----- lightweight DB class shim -----

if (!class_exists('DBmysql')) {
    class DBmysql {}
}

try {
    require_once $config_path;
} catch (Throwable $e) {
    tc_respond(500, ['ok' => false, 'reason' => 'cannot_include_db_config']);
}

if (!class_exists('DB')) {
    tc_respond(500, ['ok' => false, 'reason' => 'no_db_class']);
}

try {
    $dbobj = new DB();
} catch (Throwable $e) {
    tc_respond(500, ['ok' => false, 'reason' => 'cannot_instantiate_db']);
}

$db_host = property_exists($dbobj, 'dbhost')     ? $dbobj->dbhost     : 'localhost';
$db_user = property_exists($dbobj, 'dbuser')     ? $dbobj->dbuser     : '';
$db_pass = property_exists($dbobj, 'dbpassword') ? $dbobj->dbpassword : '';
$db_name = property_exists($dbobj, 'dbdefault')  ? $dbobj->dbdefault  : '';
$db_port = property_exists($dbobj, 'dbport')     ? $dbobj->dbport     : 3306;

if ($db_user === '' || $db_name === '') {
    tc_respond(500, ['ok' => false, 'reason' => 'incomplete_db_credentials']);
}

// ----- read plugin config -----

$mysqli = @mysqli_connect($db_host, $db_user, $db_pass, $db_name, (int)$db_port);
if (!$mysqli) {
    tc_respond(500, ['ok' => false, 'reason' => 'db_connect_failed']);
}

$sql = "SELECT name, value
        FROM glpi_configs
        WHERE context = 'plugin:glpibot'";
$res = @mysqli_query($mysqli, $sql);
if (!$res) {
    $err = mysqli_error($mysqli);
    @mysqli_close($mysqli);
    tc_respond(500, ['ok' => false, 'reason' => 'db_query_failed', 'detail' => $err]);
}

$cfg = [];
while ($row = mysqli_fetch_assoc($res)) {
    $cfg[$row['name']] = $row['value'];
}
mysqli_free_result($res);
mysqli_close($mysqli);

$base_url   = trim((string)($cfg['api_base_url'] ?? ''));       // expect e.g. http://host.docker.internal:8080
$api_key    = trim((string)($cfg['api_key']      ?? ''));
$timeout_ms = (int)($cfg['request_timeout_ms']   ?? 20000);

if ($base_url === '' || $api_key === '') {
    tc_respond(200, ['ok' => false, 'reason' => 'not_configured']);
}

// Build /health URL
$health_url = rtrim($base_url, '/') . '/health';

$headers = [
    'Accept: application/json',
    'Authorization: Bearer ' . $api_key
];

$ch = curl_init();
if ($ch === false) {
    tc_respond(500, ['ok' => false, 'reason' => 'curl_init_failed']);
}

curl_setopt($ch, CURLOPT_URL, $health_url);
curl_setopt($ch, CURLOPT_HTTPGET, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

$ms = max(1000, $timeout_ms);
if (defined('CURLOPT_TIMEOUT_MS')) {
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, $ms);
} else {
    curl_setopt($ch, CURLOPT_TIMEOUT, (int)ceil($ms/1000));
}

$body     = curl_exec($ch);
$curlErr  = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Evaluate upstream
if ($body === false || $curlErr !== '' || $httpCode < 200 || $httpCode >= 300) {
    tc_respond(200, [
        'ok'        => false,
        'reason'    => 'upstream_error',
        'http_code' => $httpCode,
        'detail'    => ($curlErr !== '' ? $curlErr : $body)
    ]);
}

// Try parse JSON
$j = json_decode($body, true);
if (!is_array($j)) {
    tc_respond(200, ['ok' => false, 'reason' => 'invalid_upstream_json', 'body' => $body]);
}

// Success if upstream said ok:true OR just 2xx
if (isset($j['ok']) && !$j['ok']) {
    tc_respond(200, ['ok' => false, 'reason' => 'health_not_ok', 'body' => $j]);
}

tc_respond(200, ['ok' => true, 'reason' => 'healthy', 'up' => $j]);
