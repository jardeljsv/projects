<?php
// /plugins/glpibot/front/chatproxy.php
// Browser -> this proxy -> FastAPI model.
// Reads config from glpi_configs (context 'plugin:glpibot'), no GLPI bootstrap.
// Auth is enforced at the FastAPI layer (Bearer). We intentionally allow
// anonymous web calls here because environment is internal/trusted.

header('Content-Type: application/json; charset=UTF-8');

// ---------- helpers ----------

function respond_error(int $http, string $label, string $detail = '', $trace = ''): void {
    http_response_code($http);
    $out = ['error' => $label, 'detail' => $detail];
    if ($trace !== '' && $trace !== null) {
        if (!is_string($trace)) {
            $trace = json_encode($trace, JSON_UNESCAPED_UNICODE);
        } elseif (strlen($trace) > 4096) {
            $trace = substr($trace, 0, 4096) . "...[truncated]";
        }
        $out['trace'] = $trace;
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}

function respond_ok(string $text): void {
    http_response_code(200);
    echo json_encode(['text' => $text], JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- validate incoming request ----------

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    respond_error(405, 'method_not_allowed', 'use POST');
}

$ct = strtolower($_SERVER['CONTENT_TYPE'] ?? '');
if (strpos($ct, 'application/json') === false) {
    respond_error(415, 'unsupported_media_type', 'need application/json');
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    respond_error(400, 'invalid_json', 'body must be valid JSON');
}

$sid         = (string)($data['sid']         ?? '');
$prompt      = (string)($data['prompt']      ?? '');
$top_p       =        ($data['top_p']       ?? 0.92);
$temperature =        ($data['temperature'] ?? 0.85);
$max_len     = (int)  ($data['max_len']     ?? 128);
$min_len     = (int)  ($data['min_len']     ?? 4);

$prompt = trim($prompt);
if ($prompt === '') {
    respond_error(400, 'empty_prompt', 'prompt is empty');
}
if (mb_strlen($prompt, 'UTF-8') > 4000) {
    $prompt = mb_substr($prompt, 0, 4000, 'UTF-8');
}

// ---------- locate GLPI root and db config ----------

$root_candidates = [
    dirname(__FILE__, 4), // /var/www/html/glpi in docker
    dirname(__FILE__, 3)
];
$GLPI_ROOT_DIR = null;
foreach ($root_candidates as $cand) {
    if ($cand
        && is_dir($cand)
        && is_file($cand . '/config/config_db.php')) {
        $GLPI_ROOT_DIR = $cand;
        break;
    }
}
if ($GLPI_ROOT_DIR === null) {
    respond_error(500, 'internal_error', 'cannot_find_glpi_root_or_db_config');
}

$config_path = $GLPI_ROOT_DIR . '/config/config_db.php';

// ---------- minimal DB shim and read creds ----------

if (!class_exists('DBmysql')) {
    class DBmysql {}
}

try {
    require_once $config_path;
} catch (Throwable $e) {
    respond_error(500, 'internal_error', 'cannot_include_db_config', $e->getMessage());
}

if (!class_exists('DB')) {
    respond_error(500, 'internal_error', 'db_class_not_loaded');
}

try {
    $dbobj = new DB();
} catch (Throwable $e) {
    respond_error(500, 'internal_error', 'cannot_instantiate_db', $e->getMessage());
}

$db_host = property_exists($dbobj, 'dbhost')     ? $dbobj->dbhost     : 'localhost';
$db_user = property_exists($dbobj, 'dbuser')     ? $dbobj->dbuser     : '';
$db_pass = property_exists($dbobj, 'dbpassword') ? $dbobj->dbpassword : '';
$db_name = property_exists($dbobj, 'dbdefault')  ? $dbobj->dbdefault  : '';
$db_port = property_exists($dbobj, 'dbport')     ? $dbobj->dbport     : 3306;

if ($db_user === '' || $db_name === '') {
    respond_error(
        500,
        'internal_error',
        'db_credentials_incomplete_after_reflection',
        ['dbhost' => $db_host, 'dbuser' => $db_user, 'dbdefault' => $db_name]
    );
}

// ---------- read plugin config from glpi_configs ----------

$mysqli = @mysqli_connect($db_host, $db_user, $db_pass, $db_name, (int)$db_port);
if (!$mysqli) {
    respond_error(500, 'internal_error', 'db_connect_failed', mysqli_connect_error());
}

$sql = "SELECT name, value
        FROM glpi_configs
        WHERE context = 'plugin:glpibot'";
$res = @mysqli_query($mysqli, $sql);
if (!$res) {
    $err = mysqli_error($mysqli);
    mysqli_close($mysqli);
    respond_error(500, 'internal_error', 'db_query_failed', $err);
}

$cfg = [];
while ($row = mysqli_fetch_assoc($res)) {
    $cfg[$row['name']] = $row['value'];
}
mysqli_free_result($res);
mysqli_close($mysqli);

// config normalize
$enabled    = (int)($cfg['enable_widget']       ?? 0);
$api_base   = trim((string)($cfg['api_base_url'] ?? '')); // expected like http://host.docker.internal:8080
$api_key    = trim((string)($cfg['api_key']      ?? ''));
$timeout_ms = (int)($cfg['request_timeout_ms']   ?? 20000);

if ($enabled !== 1) {
    respond_error(503, 'disabled', 'widget_not_enabled');
}
if ($api_base === '') {
    respond_error(500, 'internal_error', 'missing_api_base_url');
}

// ---------- call FastAPI /chat ----------

$chat_url = rtrim($api_base, '/') . '/chat';

$up_payload = [
    'sid'         => $sid,
    'prompt'      => $prompt,
    'top_p'       => $top_p,
    'temperature' => $temperature,
    'max_len'     => $max_len,
    'min_len'     => $min_len
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json'
];
if ($api_key !== '') {
    $headers[] = 'Authorization: Bearer ' . $api_key;
}

$ch = curl_init();
if ($ch === false) {
    respond_error(500, 'internal_error', 'curl_init_failed');
}

curl_setopt($ch, CURLOPT_URL, $chat_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($up_payload, JSON_UNESCAPED_UNICODE));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

// timeout
$ms = max(1000, $timeout_ms);
if (defined('CURLOPT_TIMEOUT_MS')) {
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, $ms);
} else {
    curl_setopt($ch, CURLOPT_TIMEOUT, (int)ceil($ms/1000));
}

$respBody = curl_exec($ch);
$curlErr  = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($respBody === false || $curlErr !== '' || $httpCode < 200 || $httpCode >= 300) {
    respond_error(
        502,
        'upstream_error',
        'upstream_http_' . $httpCode,
        $curlErr !== '' ? $curlErr : (string)$respBody
    );
}

$parsed = json_decode($respBody, true);
if (!is_array($parsed)) {
    respond_error(502, 'invalid_upstream_json', $respBody);
}
if (!array_key_exists('reply', $parsed)) {
    respond_error(502, 'no_reply_in_upstream', $parsed);
}

// success
respond_ok((string)$parsed['reply']);
