<?php
// /plugins/glpibot/front/health.php
// Lightweight status check for the widget header pill.
// No GLPI bootstrap. Just read DB config and decide if we're "api" or "noapi".

header('Content-Type: application/json; charset=UTF-8');

function health_error($reason) {
    http_response_code(200);
    echo json_encode([
        'mode'   => 'noapi',
        'reason' => $reason
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ----- locate GLPI root and db config -----

$root_candidates = [
    dirname(__FILE__, 4),
    dirname(__FILE__, 3)
];
$GLPI_ROOT_DIR = null;
foreach ($root_candidates as $cand) {
    if ($cand
        && is_dir($cand)
        && is_file($cand . '/config/config_db.php')) {
        $GLPI_ROOT_DIR = $cand;
        break;
    }
}
if ($GLPI_ROOT_DIR === null) {
    health_error('no_glpi_root');
}

$config_path = $GLPI_ROOT_DIR . '/config/config_db.php';

// ----- lightweight DB class shim -----

if (!class_exists('DBmysql')) {
    class DBmysql {}
}

try {
    require_once $config_path;
} catch (Throwable $e) {
    health_error('cannot_include_db_config');
}

if (!class_exists('DB')) {
    health_error('no_db_class');
}

try {
    $dbobj = new DB();
} catch (Throwable $e) {
    health_error('cannot_instantiate_db');
}

$db_host = property_exists($dbobj, 'dbhost')     ? $dbobj->dbhost     : 'localhost';
$db_user = property_exists($dbobj, 'dbuser')     ? $dbobj->dbuser     : '';
$db_pass = property_exists($dbobj, 'dbpassword') ? $dbobj->dbpassword : '';
$db_name = property_exists($dbobj, 'dbdefault')  ? $dbobj->dbdefault  : '';
$db_port = property_exists($dbobj, 'dbport')     ? $dbobj->dbport     : 3306;

if ($db_user === '' || $db_name === '') {
    health_error('incomplete_db_credentials');
}

// ----- read plugin config from glpi_configs -----

$mysqli = @mysqli_connect($db_host, $db_user, $db_pass, $db_name, (int)$db_port);
if (!$mysqli) {
    health_error('db_connect_failed');
}

$sql = "SELECT name, value
        FROM glpi_configs
        WHERE context = 'plugin:glpibot'";
$res = @mysqli_query($mysqli, $sql);
if (!$res) {
    @mysqli_close($mysqli);
    health_error('db_query_failed');
}

$cfg = [];
while ($row = mysqli_fetch_assoc($res)) {
    $cfg[$row['name']] = $row['value'];
}
mysqli_free_result($res);
mysqli_close($mysqli);

// normalize
$enabled  = (int)($cfg['enable_widget']       ?? 0);
$api_base = trim((string)($cfg['api_base_url'] ?? ''));
$api_key  = trim((string)($cfg['api_key']      ?? ''));

// Decide mode
if ($enabled === 1 && $api_base !== '' && $api_key !== '') {
    http_response_code(200);
    echo json_encode([
        'mode' => 'api'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// fallback
health_error('not_configured');
