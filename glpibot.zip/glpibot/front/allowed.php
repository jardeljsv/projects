<?php
// /plugins/glpibot/front/allowed.php
// NO GLPI bootstrap.
// Reads plugin config from glpi_configs and enforces allowed_groups.
// Resolves current users_id by opening the SAME PHP session GLPI uses (session cookie name is glpi_<hash>).
//
// Returns JSON always with HTTP 200:
// { enabled, restricted, allowed, uncertain, reason }
//
// Hardened: no 500, logs to files/_log/glpibot-allowed.log (or /tmp if not writable).

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Vary: Cookie');

@ini_set('display_errors', '0');
http_response_code(200);

// Disable mysqli exceptions (GLPI may enable strict globally)
if (function_exists('mysqli_report')) {
    @mysqli_report(MYSQLI_REPORT_OFF);
}

// ---- logging setup ----
$__glpibot_log_file = '/tmp/glpibot-allowed.log';
$__glpibot_glpi_root = null;

$root_candidates = [
    dirname(__FILE__, 4),
    dirname(__FILE__, 3),
];

foreach ($root_candidates as $cand) {
    if ($cand && is_dir($cand) && is_file($cand . '/config/config_db.php')) {
        $__glpibot_glpi_root = $cand;
        $__glpibot_log_file = rtrim($cand, '/\\') . '/files/_log/glpibot-allowed.log';
        break;
    }
}

function glpibot_log_line(string $msg): void {
    global $__glpibot_log_file;
    $ts = date('Y-m-d H:i:s');
    @file_put_contents($__glpibot_log_file, "[$ts] $msg\n", FILE_APPEND);
}

function glpibot_send(array $payload): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
    }
    http_response_code(200);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

// ---- fatal/exception safety ----
register_shutdown_function(function () {
    $err = error_get_last();
    if (!$err) return;

    $fatal = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array((int)$err['type'], $fatal, true)) return;

    glpibot_log_line("FATAL type={$err['type']} msg={$err['message']} file={$err['file']} line={$err['line']}");
    glpibot_send([
        'enabled'    => true,
        'restricted' => true,
        'allowed'    => true,
        'uncertain'  => true,
        'reason'     => 'fatal_fail_open'
    ]);
});

set_exception_handler(function ($e) {
    glpibot_log_line("EXCEPTION " . get_class($e) . ": " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    glpibot_send([
        'enabled'    => true,
        'restricted' => true,
        'allowed'    => true,
        'uncertain'  => true,
        'reason'     => 'exception_fail_open'
    ]);
});

// ---- helpers ----
function glpibot_parse_allowed_groups(string $raw): array {
    $s = trim($raw);
    if ($s === '') return [];

    $j = json_decode($s, true);
    if (is_array($j)) {
        $out = [];
        foreach ($j as $v) {
            $id = (int)$v;
            if ($id > 0) $out[$id] = $id;
        }
        return array_values($out);
    }

    $parts = preg_split('/[,\s]+/', $s);
    if (!is_array($parts)) return [];

    $out = [];
    foreach ($parts as $p) {
        $id = (int)$p;
        if ($id > 0) $out[$id] = $id;
    }
    return array_values($out);
}

function glpibot_pick_glpi_session_cookie_name(): ?string {
    $names = array_keys($_COOKIE);

    // Prefer glpi_* (not rememberme)
    $best = null;
    foreach ($names as $n) {
        if (!is_string($n)) continue;
        if (substr($n, -11) === '_rememberme') continue;
        if (stripos($n, 'glpi_') === 0) {
            // choose the longest (most specific)
            if ($best === null || strlen($n) > strlen($best)) $best = $n;
        }
    }
    if ($best !== null) return $best;

    // Fallback: some installs may use 'glpi' as session name
    foreach ($names as $n) {
        if (!is_string($n)) continue;
        if (substr($n, -11) === '_rememberme') continue;
        if (stripos($n, 'glpi') === 0) return $n;
    }

    // Fallback: PHP default
    if (isset($_COOKIE['PHPSESSID'])) return 'PHPSESSID';

    return null;
}

function glpibot_try_uid_from_php_session(array &$debug): int {
    // Only attempt if save_handler is files (or default) OR if unknown.
    $save_handler = (string)ini_get('session.save_handler');
    $save_path    = (string)ini_get('session.save_path');
    $serialize     = (string)ini_get('session.serialize_handler');

    $debug['session_save_handler'] = $save_handler;
    $debug['session_save_path'] = $save_path;
    $debug['session_serialize_handler'] = $serialize;

    $cookie_name = glpibot_pick_glpi_session_cookie_name();
    $debug['picked_cookie_name'] = $cookie_name;

    if ($cookie_name === null) {
        return 0;
    }

    $sid = $_COOKIE[$cookie_name] ?? '';
    if (!is_string($sid)) return 0;

    $sid = trim(urldecode($sid));
    $debug['picked_cookie_value_len'] = strlen($sid);

    if ($sid === '' || strlen($sid) < 6 || strlen($sid) > 256) {
        return 0;
    }

    // Set session name to GLPI's cookie name and force that id
    // Avoid warnings if session is already active (shouldn't be in this endpoint)
    if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
        @session_write_close();
    }

    // session_name accepts underscores in practice (GLPI uses it this way in many installs)
    @session_name($cookie_name);
    @session_id($sid);

    // Read-only open if supported
    if (PHP_VERSION_ID >= 70000) {
        @session_start(['read_and_close' => true]);
    } else {
        @session_start();
        @session_write_close();
    }

    $uid = 0;

    if (isset($_SESSION) && is_array($_SESSION)) {
        // Primary expected key
        if (isset($_SESSION['glpiID'])) {
            $uid = (int)$_SESSION['glpiID'];
        } else {
            // Defensive: sometimes nested or different casing in edge cases
            foreach (['glpiID', 'glpiId', 'GLPI_ID'] as $k) {
                if (isset($_SESSION[$k])) {
                    $uid = (int)$_SESSION[$k];
                    break;
                }
            }
        }
    }

    $debug['uid_from_session'] = $uid;

    return $uid > 0 ? $uid : 0;
}

function glpibot_get_user_groups(mysqli $mysqli, int $uid): array {
    $ids = [];
    $sql = "SELECT `groups_id` FROM `glpi_groups_users` WHERE `users_id` = " . (int)$uid;
    $res = @mysqli_query($mysqli, $sql);
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $gid = (int)($row['groups_id'] ?? 0);
            if ($gid > 0) $ids[$gid] = true;
        }
        mysqli_free_result($res);
    }
    return array_keys($ids);
}

function glpibot_expand_group_ancestors(mysqli $mysqli, array $group_ids): array {
    // Include parent groups via glpi_groups.groups_id (if present)
    $all = [];
    foreach ($group_ids as $g) {
        $g = (int)$g;
        if ($g > 0) $all[$g] = true;
    }

    $frontier = array_keys($all);
    $depth = 0;

    while (!empty($frontier) && $depth < 20) {
        $depth++;
        $in = implode(',', array_map('intval', $frontier));
        $frontier = [];

        $sql = "SELECT `id`, `groups_id` FROM `glpi_groups` WHERE `id` IN ($in)";
        $res = @mysqli_query($mysqli, $sql);
        if (!$res) break; // schema differs; stop expanding

        while ($row = mysqli_fetch_assoc($res)) {
            $pid = (int)($row['groups_id'] ?? 0);
            if ($pid > 0 && !isset($all[$pid])) {
                $all[$pid] = true;
                $frontier[] = $pid;
            }
        }
        mysqli_free_result($res);
    }

    return array_keys($all);
}

// ---- main ----
try {
    glpibot_log_line(
        "START uri=" . (string)($_SERVER['REQUEST_URI'] ?? '')
        . " cookie_names=[" . implode(',', array_keys($_COOKIE)) . "]"
    );

    if ($__glpibot_glpi_root === null) {
        glpibot_log_line("NO_GLPI_ROOT");
        glpibot_send([
            'enabled'    => true,
            'restricted' => false,
            'allowed'    => true,
            'uncertain'  => true,
            'reason'     => 'fail_open_no_glpi_root'
        ]);
    }

    $config_path = rtrim($__glpibot_glpi_root, '/\\') . '/config/config_db.php';
    if (!is_file($config_path)) {
        glpibot_log_line("NO_CONFIG_DB path={$config_path}");
        glpibot_send([
            'enabled'    => true,
            'restricted' => false,
            'allowed'    => true,
            'uncertain'  => true,
            'reason'     => 'fail_open_no_config_db'
        ]);
    }

    // DB shim (needed by config_db.php)
    if (!class_exists('DBmysql')) {
        class DBmysql {}
    }

    require_once $config_path;

    if (!class_exists('DB')) {
        glpibot_log_line("NO_DB_CLASS after include config_db.php");
        glpibot_send([
            'enabled'    => true,
            'restricted' => true,
            'allowed'    => true,
            'uncertain'  => true,
            'reason'     => 'fail_open_db_class_missing'
        ]);
    }

    $dbobj = new DB();

    $db_host = property_exists($dbobj, 'dbhost')     ? $dbobj->dbhost     : 'localhost';
    $db_user = property_exists($dbobj, 'dbuser')     ? $dbobj->dbuser     : '';
    $db_pass = property_exists($dbobj, 'dbpassword') ? $dbobj->dbpassword : '';
    $db_name = property_exists($dbobj, 'dbdefault')  ? $dbobj->dbdefault  : '';
    $db_port = property_exists($dbobj, 'dbport')     ? $dbobj->dbport     : 3306;

    glpibot_log_line("DBCFG host={$db_host} db={$db_name} user=" . ($db_user !== '' ? 'set' : 'empty') . " port={$db_port}");

    $mysqli = @mysqli_connect($db_host, $db_user, $db_pass, $db_name, (int)$db_port);
    if (!$mysqli) {
        glpibot_log_line("DB_CONNECT_FAILED " . (string)mysqli_connect_error());
        glpibot_send([
            'enabled'    => true,
            'restricted' => true,
            'allowed'    => true,
            'uncertain'  => true,
            'reason'     => 'fail_open_db_connect_failed'
        ]);
    }

    // Read config
    $sql = "SELECT name, value
            FROM glpi_configs
            WHERE context = 'plugin:glpibot'
              AND name IN ('enable_widget','allowed_groups')";
    $res = @mysqli_query($mysqli, $sql);

    $cfg = [];
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $cfg[(string)$row['name']] = (string)$row['value'];
        }
        mysqli_free_result($res);
    } else {
        glpibot_log_line("DB_QUERY_FAILED " . (string)mysqli_error($mysqli));
    }

    $enabled = ((int)($cfg['enable_widget'] ?? 0)) === 1;
    $raw_allowed = (string)($cfg['allowed_groups'] ?? '');
    $allowed_groups = glpibot_parse_allowed_groups($raw_allowed);

    if (!$enabled) {
        @mysqli_close($mysqli);
        glpibot_send([
            'enabled'    => false,
            'restricted' => false,
            'allowed'    => false,
            'uncertain'  => false,
            'reason'     => 'disabled'
        ]);
    }

    if (empty($allowed_groups)) {
        @mysqli_close($mysqli);
        glpibot_send([
            'enabled'    => true,
            'restricted' => false,
            'allowed'    => true,
            'uncertain'  => false,
            'reason'     => 'all_users'
        ]);
    }

    // Resolve uid by opening the PHP session GLPI uses
    $debug = [];
    $uid = glpibot_try_uid_from_php_session($debug);

    if ($uid <= 0) {
        glpibot_log_line(
            "UNCERTAIN uid_not_found allowed_groups=[" . implode(',', $allowed_groups) . "] raw='{$raw_allowed}'"
            . " save_handler='" . (string)($debug['session_save_handler'] ?? '') . "'"
            . " save_path='" . (string)($debug['session_save_path'] ?? '') . "'"
            . " serialize='" . (string)($debug['session_serialize_handler'] ?? '') . "'"
            . " picked_cookie='" . (string)($debug['picked_cookie_name'] ?? '') . "'"
            . " picked_cookie_len=" . (string)($debug['picked_cookie_value_len'] ?? '')
        );

        @mysqli_close($mysqli);

        // Fail-open but mark uncertain (client must NOT hide in this case)
        glpibot_send([
            'enabled'    => true,
            'restricted' => true,
            'allowed'    => true,
            'uncertain'  => true,
            'reason'     => 'uncertain_uid_not_found'
        ]);
    }

    // Membership + ancestor support
    $user_groups = glpibot_get_user_groups($mysqli, $uid);
    $expanded = glpibot_expand_group_ancestors($mysqli, $user_groups);

    $allowmap = [];
    foreach ($allowed_groups as $g) $allowmap[(int)$g] = true;

    $hit = false;
    foreach ($expanded as $g) {
        $g = (int)$g;
        if ($g > 0 && isset($allowmap[$g])) {
            $hit = true;
            break;
        }
    }

    glpibot_log_line(
        ($hit ? "ALLOW" : "DENY")
        . " uid={$uid}"
        . " allowed_groups=[" . implode(',', $allowed_groups) . "]"
        . " user_groups=[" . implode(',', $user_groups) . "]"
        . " expanded_groups=[" . implode(',', $expanded) . "]"
        . " raw='{$raw_allowed}'"
        . " picked_cookie='" . (string)($debug['picked_cookie_name'] ?? '') . "'"
    );

    @mysqli_close($mysqli);

    glpibot_send([
        'enabled'    => true,
        'restricted' => true,
        'allowed'    => $hit,
        'uncertain'  => false,
        'reason'     => $hit ? 'in_allowed_group' : 'not_in_allowed_groups'
    ]);

} catch (Throwable $e) {
    glpibot_log_line("CATCH " . get_class($e) . ": " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    glpibot_send([
        'enabled'    => true,
        'restricted' => true,
        'allowed'    => true,
        'uncertain'  => true,
        'reason'     => 'catch_fail_open'
    ]);
}
